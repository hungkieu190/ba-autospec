<?php

namespace LearnPress\Interactive\Filters;

use LearnPress\Filters\FilterBase;

defined( 'ABSPATH' ) || exit;

class InteractiveFilter extends FilterBase {
	const COL_ID         = 'ID';
	const COL_TITLE      = 'title';
	const COL_TYPE       = 'type';
	const COL_STATUS     = 'status';
	const COL_EXTRA_DATA = 'extra_data';
	const COL_CREATED_AT = 'created_at';
	const COL_UPDATED_AT = 'updated_at';
	const COL_AUTHOR     = 'author';

	/**
	 * @var string[]
	 */
	public $all_fields = [
		self::COL_ID,
		self::COL_TITLE,
		self::COL_TYPE,
		self::COL_STATUS,
		self::COL_EXTRA_DATA,
		self::COL_CREATED_AT,
		self::COL_UPDATED_AT,
		self::COL_AUTHOR,
	];

	/**
	 * @var int
	 */
	public $ID;
	/**
	 * @var string
	 */
	public $title;
	/**
	 * @var string
	 */
	public $type;
	/**
	 * @var string
	 */
	public $status;
	/**
	 * Whitelist of statuses (used when single $status is empty). Default in
	 * the admin manager: ['publish', 'draft'] — excludes trash from "All".
	 *
	 * @var string[]
	 */
	public $status_in = [];
	/**
	 * @var string
	 */
	public $extra_data;
	/**
	 * @var string
	 */
	public $created_at;
	/**
	 * @var string
	 */
	public $updated_at;
	/**
	 * @var int
	 */
	public $author;

	public function __construct() {
		global $wpdb;
		$this->collection       = $wpdb->prefix . 'learnpress_interactive';
		$this->collection_alias = 'i';
	}
}
