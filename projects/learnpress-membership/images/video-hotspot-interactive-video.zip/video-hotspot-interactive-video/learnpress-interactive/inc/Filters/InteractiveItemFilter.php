<?php

namespace LearnPress\Interactive\Filters;

use LearnPress\Filters\FilterBase;

defined( 'ABSPATH' ) || exit;

class InteractiveItemFilter extends FilterBase {
	const COL_ID             = 'ID';
	const COL_INTERACTIVE_ID = 'interactive_id';
	const COL_CONTENT        = 'content';
	const COL_SORT_ORDER     = 'sort_order';
	const COL_EXTRA_DATA     = 'extra_data';

	/**
	 * @var string[]
	 */
	public $all_fields = [
		self::COL_ID,
		self::COL_INTERACTIVE_ID,
		self::COL_CONTENT,
		self::COL_SORT_ORDER,
		self::COL_EXTRA_DATA,
	];

	/**
	 * @var int
	 */
	public $ID;

	/**
	 * @var int
	 */
	public $interactive_id;

	public function __construct() {
		global $wpdb;
		$this->collection       = $wpdb->prefix . 'learnpress_interactive_items';
		$this->collection_alias = 'ii';
		$this->order_by         = 'sort_order';
		$this->order            = 'ASC';
	}
}
