<?php

namespace LearnPress\Interactive\Admin;

use LearnPress\Helpers\Template;
use LearnPress\Interactive\Ajax\InteractiveAjax;
use LearnPress\Interactive\Helpers\Icon;
use LearnPress\Interactive\Models\InteractiveItemModel;
use LearnPress\Interactive\Models\InteractiveModel;
use LearnPress\Interactive\Services\InteractiveService;
use LearnPress\Interactive\Types\FlashCardType;
use LearnPress\Interactive\Types\TypeRegistry;

defined( 'ABSPATH' ) || exit;

class AdminInteractiveEditPage {

	public const FORM_ACTION = 'lp_interactive_save_form';
	public const FORM_NONCE  = '_lp_interactive_form_nonce';
	public const SCREEN_ID   = 'lp_interactive_builder';

	public static function handle_form_save(): void {
		if ( ! current_user_can( AdminMenu::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission.', 'learnpress-interactive' ), '', array( 'response' => 403 ) );
		}

		$id = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;
		if ( ! $id ) {
			wp_die( esc_html__( 'Missing ID.', 'learnpress-interactive' ), '', array( 'response' => 400 ) );
		}

		check_admin_referer( self::FORM_ACTION . ':' . $id, self::FORM_NONCE );

		$model = InteractiveModel::find( $id );
		if ( ! $model ) {
			wp_die( esc_html__( 'Not found.', 'learnpress-interactive' ), '', array( 'response' => 404 ) );
		}

		$is_trash = ! empty( $_POST['submit_trash'] );

		if ( $is_trash ) {
			$payload = array( 'status' => 'trash' );
		} else {
			$payload = array();

			if ( isset( $_POST['title'] ) ) {
				$payload['title'] = mb_substr(
					sanitize_text_field( wp_unslash( $_POST['title'] ) ),
					0,
					255
				);
			}

			if ( isset( $_POST['status'] ) ) {
				$status = sanitize_key( wp_unslash( $_POST['status'] ) );
				if ( in_array( $status, array( 'publish', 'draft', 'trash' ), true ) ) {
					$payload['status'] = $status;
				}
			}

			if ( isset( $_POST['items'] ) && is_string( $_POST['items'] ) ) {
				$raw_items = wp_unslash( $_POST['items'] );
				try {
					$decoded          = \LP_Helper::json_decode( $raw_items, true );
					$payload['items'] = is_array( $decoded ) ? $decoded : array();
				} catch ( \Throwable $e ) {
					$payload['items'] = array();
				}
			}

			if ( isset( $_POST['settings'] ) && is_string( $_POST['settings'] ) ) {
				$raw_settings = wp_unslash( $_POST['settings'] );
				try {
					$decoded             = \LP_Helper::json_decode( $raw_settings, true );
					$payload['settings'] = is_array( $decoded ) ? $decoded : array();
				} catch ( \Throwable $e ) {
					$payload['settings'] = array();
				}
			}
		}

		$ok = false;
		try {
			$ok = InteractiveService::instance()->save( $id, $payload );
		} catch ( \Throwable $e ) {
			$ok = false;
		}

		if ( ! $ok ) {
			wp_safe_redirect(
				add_query_arg(
					array(
						'page'    => AdminMenu::SLUG,
						'action'  => 'edit',
						'id'      => $id,
						'message' => '0',
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		if ( $is_trash ) {
			wp_safe_redirect(
				add_query_arg(
					array(
						'page'    => AdminMenu::SLUG,
						'trashed' => '1',
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => AdminMenu::SLUG,
					'action'  => 'edit',
					'id'      => $id,
					'message' => '1',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	public function render(): void {
		if ( ! current_user_can( AdminMenu::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission.', 'learnpress-interactive' ), '', array( 'response' => 403 ) );
		}

		$id = isset( $_GET['id'] ) ? absint( wp_unslash( $_GET['id'] ) ) : 0;

		if ( ! $id ) {
			$this->render_create();
			return;
		}

		$model = InteractiveModel::find( $id );
		if ( ! $model ) {
			$this->render_not_found();
			return;
		}

		$this->render_editor( $model );
	}

	private function render_create(): void {
		$nonce = wp_create_nonce( InteractiveAjax::NONCE_ACTION );
		$back  = admin_url( 'admin.php?page=' . AdminMenu::SLUG );
		$types = TypeRegistry::all();

		$sections = apply_filters(
			'learnpress/interactive/admin/create/sections',
			array(
				'wrapper_open'  => sprintf(
					'<div class="wrap lp-interactive-create" data-nonce="%s" data-ajax-action="lp_interactive_create">',
					esc_attr( $nonce )
				),
				'header_end'    => '<hr class="wp-header-end" />',
				'topbar'        => $this->create_topbar_html( $back ),
				'card_open'     => '<div class="lp-interactive-create__card">',
				'band'          => $this->create_band_html(),
				'form_open'     => '<form class="lp-interactive-create__form" autocomplete="off">',
				'nonce_field'   => wp_nonce_field( InteractiveAjax::NONCE_ACTION, '_lp_interactive_nonce', true, false ),
				'title_field'   => $this->create_title_field_html(),
				'type_field'    => $this->create_type_field_html( $types ),
				'footer'        => $this->create_footer_html( $back ),
				'form_close'    => '</form>',
				'card_close'    => '</div>',
				'wrapper_close' => '</div>',
			),
			$types
		);

		echo Template::combine_components( $sections );
	}

	private function create_topbar_html( string $back_url ): string {
		$sections = array(
			'breadcrumb' => sprintf(
				'<a class="lp-interactive-create__breadcrumb" href="%s">'
				. '<span class="lp-interactive-create__breadcrumb-parent">%s</span>'
				. '<span class="lp-interactive-create__breadcrumb-sep" aria-hidden="true">/</span>'
				. '<span class="lp-interactive-create__breadcrumb-current">%s</span>'
				. '</a>',
				esc_url( $back_url ),
				esc_html__( 'Library', 'learnpress-interactive' ),
				esc_html__( 'New content', 'learnpress-interactive' )
			),
			'step_pill'  => sprintf(
				'<span class="lp-interactive-create__step-pill">'
				. '<span class="lp-interactive-create__step-dot" aria-hidden="true"></span>'
				. '%s'
				. '</span>',
				esc_html__( 'Step 1 of 2 · Set up', 'learnpress-interactive' )
			),
		);

		return '<div class="lp-interactive-create__topbar">' . Template::combine_components( $sections ) . '</div>';
	}

	private function create_band_html(): string {
		$inner = sprintf(
			'<div class="lp-interactive-create__band-inner">'
			. '<span class="lp-interactive-create__band-icon" aria-hidden="true">%s</span>'
			. '<div class="lp-interactive-create__band-text">'
			. '<h1 class="lp-interactive-create__band-title">%s</h1>'
			. '<p class="lp-interactive-create__band-sub">%s</p>'
			. '</div>'
			. '</div>',
			$this->band_icon_svg(),
			esc_html__( 'Create New Interactive', 'learnpress-interactive' ),
			esc_html__( 'Name it, then pick a format. Easy.', 'learnpress-interactive' )
		);

		return sprintf(
			'<div class="lp-interactive-create__band">%s%s</div>',
			$inner,
			$this->band_confetti_svg()
		);
	}

	private function create_title_field_html(): string {
		return sprintf(
			'<div class="lp-interactive-create__field">'
			. '<label class="lp-interactive-create__label" for="lp-interactive-create-title">%s</label>'
			. '<div class="lp-interactive-create__input-wrap">'
			. '<span class="lp-interactive-create__input-icon" aria-hidden="true">%s</span>'
			. '<input type="text" id="lp-interactive-create-title" name="title" class="lp-interactive-create__input" required maxlength="255" placeholder="%s" autocomplete="off" />'
			. '</div>'
			. '</div>',
			esc_html__( 'Title', 'learnpress-interactive' ),
			$this->pencil_icon_svg(),
			esc_attr__( 'Name your masterpiece', 'learnpress-interactive' )
		);
	}

	private function create_type_field_html( array $types ): string {
		$segments = '';
		foreach ( $types as $type_obj ) {
			$segments .= $this->create_type_segment_html( $type_obj );
		}

		return sprintf(
			'<div class="lp-interactive-create__field">'
			. '<fieldset class="lp-interactive-create__type-fieldset">'
			. '<legend class="lp-interactive-create__label">%s</legend>'
			. '<div class="lp-interactive-create__segments">%s</div>'
			. '</fieldset>'
			. '</div>',
			esc_html__( 'Choose type', 'learnpress-interactive' ),
			$segments
		);
	}

	private function create_type_segment_html( $type_obj ): string {
		$key  = $type_obj->key();
		$meta = $this->type_segment_meta( $key );

		return sprintf(
			'<label class="lp-interactive-create__segment">'
			. '<input type="radio" name="type" value="%s" required class="lp-interactive-create__segment-input" />'
			. '<span class="lp-interactive-create__segment-illustration" aria-hidden="true">%s</span>'
			. '<span class="lp-interactive-create__segment-text">'
			. '<span class="lp-interactive-create__segment-label">%s</span>'
			. '<span class="lp-interactive-create__segment-hint">%s</span>'
			. '</span>'
			. '<span class="lp-interactive-create__segment-radio" aria-hidden="true"></span>'
			. '</label>',
			esc_attr( $key ),
			$meta['illustration'],
			esc_html( $type_obj->label() ),
			esc_html( $meta['hint'] )
		);
	}

	private function type_segment_meta( string $key ): array {
		$hints = array(
			'flash_card' => __( 'Memorize · Quiz', 'learnpress-interactive' ),
			'slide'      => __( 'Teach · Present', 'learnpress-interactive' ),
		);

		$icon_slugs = array(
			'flash_card' => 'create-flash-card',
			'slide'      => 'create-slide',
		);

		$slug = $icon_slugs[ $key ] ?? 'create-generic';

		return array(
			'hint'         => $hints[ $key ] ?? '',
			'illustration' => Icon::render( $slug ),
		);
	}

	private function create_footer_html( string $back_url ): string {
		return sprintf(
			'<div class="lp-interactive-create__footer">'
			. '<a href="%s" class="lp-interactive-create__btn-ghost">%s</a>'
			. '<button type="submit" class="lp-interactive-create__btn-primary">'
			. '<span>%s</span>'
			. '%s'
			. '</button>'
			. '</div>',
			esc_url( $back_url ),
			esc_html__( 'Cancel', 'learnpress-interactive' ),
			esc_html__( 'Save & Continue', 'learnpress-interactive' ),
			Icon::render( 'create-arrow' )
		);
	}

	private function pencil_icon_svg(): string {
		return Icon::render( 'create-pencil' );
	}

	private function band_icon_svg(): string {
		return Icon::render( 'create-band' );
	}

	private function band_confetti_svg(): string {
		return Icon::render( 'create-confetti', array( 'class' => 'lp-interactive-create__confetti' ) );
	}

	private function render_editor( InteractiveModel $model ): void {
		$type = TypeRegistry::get( $model->type );
		if ( ! $type ) {
			$this->render_not_found();
			return;
		}

		$item_models = InteractiveItemModel::find_by_parent( $model->ID );
		$is_flash    = 'flash_card' === $model->type;
		$items       = array_map(
			static function ( InteractiveItemModel $item ) use ( $is_flash ) {
				$row = array(
					'ID'         => $item->ID,
					'content'    => $item->content,
					'sort_order' => $item->sort_order,
					'extra_data' => is_array( $item->extra_data ) ? $item->extra_data : null,
				);

				if ( $is_flash ) {
					$row['card'] = FlashCardType::enrich_card_urls( FlashCardType::decode_card( $row ) );
				}

				return $row;
			},
			$item_models
		);

		$settings  = ( is_array( $model->extra_data ) && count( $model->extra_data ) > 0 )
			? $model->extra_data
			: $type->default_settings();
		$bootstrap = wp_json_encode(
			array(
				'id'         => $model->ID,
				'title'      => $model->title,
				'type'       => $model->type,
				'status'     => $model->status,
				'settings'   => $settings,
				'items'      => $items,
				'listUrl'    => admin_url( 'admin.php?page=' . AdminMenu::SLUG ),
			),
			JSON_UNESCAPED_UNICODE
		);

		if ( false === $bootstrap ) {
			$this->render_not_found();
			return;
		}

		$context = array(
			'model'        => $model,
			'shortcode'    => '[learnpress_single_interactive id=' . (int) $model->ID . ']',
			'nonce'        => wp_create_nonce( InteractiveAjax::NONCE_ACTION ),
			'bootstrap'    => (string) $bootstrap,
			'status_label' => $this->status_label_for( $model->status ),
			'msg'          => isset( $_GET['message'] ) ? sanitize_key( wp_unslash( $_GET['message'] ) ) : '',
			'items_count'  => count( $items ),
		);

		$sections = apply_filters(
			'learnpress/interactive/admin/editor/sections',
			array(
				'wrapper_open'  => sprintf(
					'<div class="wrap lp-interactive-builder" data-nonce="%s" data-ajax-action="lp_interactive_save" data-bootstrap="%s">',
					esc_attr( $context['nonce'] ),
					esc_attr( $context['bootstrap'] )
				),
				// 'lp_notices'    => '<div class="lp-admin-notices notice"></div>',
				'notice'        => $this->editor_notice_html( $context['msg'] ),
				'form_open'     => $this->editor_form_open_html( $model ),
				'title_card'    => $this->editor_title_card_html( $model ),
				'editor_card'   => $this->editor_main_card_html( $context ),
				'form_close'    => '</form>',
				'wrapper_close' => '</div>',
			),
			$context
		);

		echo Template::combine_components( $sections );
	}

	private function status_label_for( string $status ): string {
		$status_labels = array(
			'publish' => __( 'Published', 'learnpress-interactive' ),
			'draft'   => __( 'Draft', 'learnpress-interactive' ),
			'trash'   => __( 'Trashed', 'learnpress-interactive' ),
		);

		return $status_labels[ $status ] ?? $status;
	}

	private function editor_notice_html( string $msg ): string {
		$notices = array(
			'1' => array(
				'class' => 'lp-interactive-builder__inline-notice lp-interactive-builder__inline-notice--success',
				'text'  => __( 'Updated.', 'learnpress-interactive' ),
			),
			'0' => array(
				'class' => 'lp-interactive-builder__inline-notice lp-interactive-builder__inline-notice--error',
				'text'  => __( 'Update failed.', 'learnpress-interactive' ),
			),
		);

		if ( ! isset( $notices[ $msg ] ) ) {
			return '';
		}

		$config = $notices[ $msg ];

		return sprintf(
			'<div class="%s" role="status">%s</div>',
			esc_attr( $config['class'] ),
			esc_html( $config['text'] )
		);
	}

	private function editor_form_open_html( InteractiveModel $model ): string {
		$hidden_fields = array(
			'action'       => array( 'value' => self::FORM_ACTION ),
			'id'           => array( 'value' => (string) $model->ID ),
			'status'       => array(
				'value' => $model->status,
				'class' => 'lp-interactive-builder__status-input',
			),
			'items'        => array(
				'value' => '',
				'class' => 'lp-interactive-builder__items-input',
			),
			'settings'     => array(
				'value' => '',
				'class' => 'lp-interactive-builder__settings-input',
			),
			'submit_trash' => array(
				'value' => '',
				'class' => 'lp-interactive-builder__trash-input',
			),
		);

		$inputs = '';
		foreach ( $hidden_fields as $name => $cfg ) {
			$class_attr = ! empty( $cfg['class'] )
				? sprintf( ' class="%s"', esc_attr( $cfg['class'] ) )
				: '';
			$inputs    .= sprintf(
				'<input type="hidden" name="%s" value="%s"%s />',
				esc_attr( $name ),
				esc_attr( $cfg['value'] ),
				$class_attr
			);
		}

		return sprintf(
			'<form id="post" class="lp-interactive-builder__form" method="post" action="%s">%s%s',
			esc_url( admin_url( 'admin-post.php' ) ),
			$inputs,
			wp_nonce_field( self::FORM_ACTION . ':' . $model->ID, self::FORM_NONCE, true, false )
		);
	}

	private function editor_title_card_html( InteractiveModel $model ): string {
		return sprintf(
			'<div class="lp-interactive-builder__title-card">'
			. '<label class="screen-reader-text" for="lp-interactive-title">%s</label>'
			. '<input type="text" id="lp-interactive-title" name="title" class="lp-interactive-builder__title" value="%s" placeholder="%s" maxlength="255" autocomplete="off" />'
			. '</div>',
			esc_html__( 'Title', 'learnpress-interactive' ),
			esc_attr( $model->title ),
			esc_attr__( 'Add title…', 'learnpress-interactive' )
		);
	}

	private function editor_main_card_html( array $context ): string {
		$sections = array(
			'wrapper_open'  => '<div class="lp-interactive-builder__editor">',
			'head'          => $this->editor_head_strip_html( $context ),
			'tabs'          => $this->editor_tabs_html( $context['items_count'] ),
			'panels'        => $this->editor_panels_html(),
			'wrapper_close' => '</div>',
		);

		return Template::combine_components( $sections );
	}

	private function editor_head_strip_html( array $context ): string {
		$sections = array(
			'wrapper_open'  => '<header class="lp-interactive-builder__editor-head">',
			'left'          => $this->editor_head_left_html( $context['shortcode'] ),
			'right'         => $this->editor_head_right_html( $context['model'], $context['status_label'] ),
			'wrapper_close' => '</header>',
		);

		return Template::combine_components( $sections );
	}

	private function editor_head_left_html( string $shortcode ): string {
		return sprintf(
			'<div class="lp-interactive-builder__head-left">'
			. '<span class="lp-interactive-builder__head-label">%s</span>'
			. '<code class="lp-interactive-builder__code-chip" id="lp-interactive-shortcode" data-shortcode="%s">%s</code>'
			. '<button type="button" class="lp-interactive-builder__copy" title="%s">'
			. '<span class="lp-interactive-builder__copy-icon">%s</span>'
			. '<span class="lp-interactive-builder__copy-label">%s</span>'
			. '</button>'
			. '</div>',
			esc_html__( 'Shortcode', 'learnpress-interactive' ),
			esc_attr( $shortcode ),
			esc_html( $shortcode ),
			esc_attr__( 'Copy shortcode', 'learnpress-interactive' ),
			$this->svg_icon( 'copy' ),
			esc_html__( 'Copy', 'learnpress-interactive' )
		);
	}

	private function editor_head_right_html( InteractiveModel $model, string $status_label ): string {
		return sprintf(
			'<div class="lp-interactive-builder__head-right">'
			. '%s'
			. '<button type="submit" name="save" class="lp-interactive-builder__update">'
			. '<span class="lp-interactive-builder__update-icon">%s</span>'
			. '<span class="lp-interactive-builder__update-label">%s</span>'
			. '</button>'
			. '%s'
			. '</div>',
			$this->editor_status_menu_html( $model->status, $status_label ),
			$this->svg_icon( 'cloud' ),
			esc_html__( 'Update', 'learnpress-interactive' ),
			$this->editor_kebab_menu_html()
		);
	}

	private function editor_status_menu_html( string $current_status, string $status_label ): string {
		$options = array(
			'publish' => __( 'Published', 'learnpress-interactive' ),
			'draft'   => __( 'Draft', 'learnpress-interactive' ),
			'trash'   => __( 'Trashed', 'learnpress-interactive' ),
		);

		$items = '';
		foreach ( $options as $value => $label ) {
			$is_active = $current_status === $value;
			$items    .= sprintf(
				'<button type="button" class="lp-interactive-builder__status-item%s" role="menuitemradio" aria-checked="%s" data-status="%s">'
				. '<span class="lp-interactive-builder__status-item-dot lp-interactive-builder__status-item-dot--%s"></span>'
				. '<span class="lp-interactive-builder__status-item-label">%s</span>'
				. '<span class="lp-interactive-builder__status-item-check">%s</span>'
				. '</button>',
				$is_active ? ' is-active' : '',
				$is_active ? 'true' : 'false',
				esc_attr( $value ),
				esc_attr( $value ),
				esc_html( $label ),
				$this->svg_icon( 'check' )
			);
		}

		return sprintf(
			'<div class="lp-interactive-builder__status">'
			. '<button type="button" class="lp-interactive-builder__status-pill lp-interactive-builder__status-pill--%s" aria-haspopup="menu" aria-expanded="false" data-status="%s">'
			. '<span class="lp-interactive-builder__status-dot"></span>'
			. '<span class="lp-interactive-builder__status-text">%s</span>'
			. '<span class="lp-interactive-builder__status-caret">%s</span>'
			. '</button>'
			. '<div class="lp-interactive-builder__status-menu" role="menu" hidden>%s</div>'
			. '</div>',
			esc_attr( $current_status ),
			esc_attr( $current_status ),
			esc_html( $status_label ),
			$this->svg_icon( 'chevron-down' ),
			$items
		);
	}

	private function editor_kebab_menu_html(): string {
		return sprintf(
			'<div class="lp-interactive-builder__kebab-wrap">'
			. '<button type="button" class="lp-interactive-builder__kebab" aria-haspopup="menu" aria-expanded="false" title="%s">'
			. '%s'
			. '</button>'
			. '<div class="lp-interactive-builder__kebab-menu" role="menu" hidden>'
			. '<button type="button" class="lp-interactive-builder__kebab-item lp-interactive-builder__kebab-item--danger lp-interactive-builder__trash" role="menuitem">'
			. '<span class="lp-interactive-builder__kebab-icon">%s</span>'
			. '<span class="lp-interactive-builder__kebab-label">%s</span>'
			. '</button>'
			. '</div>'
			. '</div>',
			esc_attr__( 'More actions', 'learnpress-interactive' ),
			$this->svg_icon( 'more' ),
			$this->svg_icon( 'trash' ),
			esc_html__( 'Move to Trash', 'learnpress-interactive' )
		);
	}

	private function editor_tabs_html( int $items_count ): string {
		$tab_labels = array(
			'cards'    => __( 'Cards', 'learnpress-interactive' ),
			'settings' => __( 'Settings', 'learnpress-interactive' ),
			'preview'  => __( 'Preview', 'learnpress-interactive' ),
		);

		$tab_buttons = '';
		$first       = true;
		foreach ( $tab_labels as $id => $label ) {
			$active_class = $first ? ' is-active' : '';
			$aria         = $first ? 'true' : 'false';
			$count_pill   = 'cards' === $id
				? sprintf(
					'<span class="lp-interactive-builder__tab-count" data-count-target="cards">%d</span>',
					$items_count
				)
				: '';

			$tab_buttons .= sprintf(
				'<button type="button" class="lp-interactive-builder__tab%s" data-tab="%s" role="tab" aria-selected="%s">%s%s</button>',
				esc_attr( $active_class ),
				esc_attr( $id ),
				esc_attr( $aria ),
				esc_html( $label ),
				$count_pill
			);
			$first        = false;
		}

		return sprintf(
			'<div class="lp-interactive-builder__tabs-bar">'
			. '<nav class="lp-interactive-builder__tabs" role="tablist">%s</nav>'
			. '<button type="button" class="lp-interactive-builder__add-item lp-interactive-builder__add-item--prepend" data-add-position="start">'
			. '<span class="lp-interactive-builder__add-item-icon">%s</span>'
			. '<span class="lp-interactive-builder__add-item-label">%s</span>'
			. '</button>'
			. '</div>',
			$tab_buttons,
			$this->svg_icon( 'plus' ),
			esc_html__( 'Add card', 'learnpress-interactive' )
		);
	}

	private function editor_panels_html(): string {
		$panel_cards = sprintf(
			'<div class="lp-interactive-builder__panel lp-interactive-builder__panel--cards is-active" role="tabpanel">'
			. '<div class="lp-interactive-items"></div>'
			. '<button type="button" class="lp-interactive-builder__add-item lp-interactive-builder__add-item--append" data-add-position="end">'
			. '<span class="lp-interactive-builder__add-item-icon">%s</span>'
			. '<span class="lp-interactive-builder__add-item-label">%s</span>'
			. '</button>'
			. '<div class="lp-interactive-builder__items-helper">'
			. '<span class="lp-interactive-builder__items-helper-text">%s</span>'
			. '</div>'
			. '</div>',
			$this->svg_icon( 'plus' ),
			esc_html__( 'Add card', 'learnpress-interactive' ),
			esc_html__( 'Drag handles to reorder.', 'learnpress-interactive' )
		);

		$panel_settings = '<div class="lp-interactive-builder__panel lp-interactive-builder__panel--settings" role="tabpanel">'
			. '<div class="lp-interactive-settings"></div>'
			. '</div>';

		$panel_preview = '<div class="lp-interactive-builder__panel lp-interactive-builder__panel--preview" role="tabpanel">'
			. '<div class="lp-interactive-preview"></div>'
			. '</div>';

		return $panel_cards . $panel_settings . $panel_preview;
	}

	private function svg_icon( string $name ): string {
		return Icon::render( $name );
	}

	private function render_not_found(): void {
		$sections = apply_filters(
			'learnpress/interactive/admin/not_found/sections',
			array(
				'wrapper_open'  => '<div class="wrap">',
				'heading'       => sprintf( '<h1>%s</h1>', esc_html__( 'Not Found', 'learnpress-interactive' ) ),
				'notice'        => sprintf(
					'<div class="notice notice-error"><p>%s</p></div>',
					esc_html__( 'The interactive entry was not found.', 'learnpress-interactive' )
				),
				'back_link'     => sprintf(
					'<p><a class="button" href="%s">%s</a></p>',
					esc_url( admin_url( 'admin.php?page=' . AdminMenu::SLUG ) ),
					esc_html__( 'Back to list', 'learnpress-interactive' )
				),
				'wrapper_close' => '</div>',
			)
		);

		echo Template::combine_components( $sections );
	}
}
