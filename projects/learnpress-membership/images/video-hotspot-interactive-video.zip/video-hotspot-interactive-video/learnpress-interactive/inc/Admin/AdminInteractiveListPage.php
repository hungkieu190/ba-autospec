<?php

namespace LearnPress\Interactive\Admin;

use LearnPress\Helpers\Template;
use LearnPress\Interactive\Ajax\InteractiveAjax;
use LearnPress\Interactive\Helpers\Icon;
use LearnPress\Interactive\Types\TypeRegistry;

defined( 'ABSPATH' ) || exit;

/**
 * Class AdminInteractiveListPage
 *
 * Renders the manager list page with the LP Course Builder "Questions tab"
 * visual layout (`.cb-tab-*` / `.cb-list-*` classes). Rows are filled
 * client-side via the `lp_interactive_list` AJAX endpoint.
 *
 * @since 1.0.0
 * @version 1.0.0
 */
class AdminInteractiveListPage {

	public function render(): void {
		$context = array(
			'add_url'   => admin_url( 'admin.php?page=' . AdminMenu::SLUG . '&action=new' ),
			'reset_url' => admin_url( 'admin.php?page=' . AdminMenu::SLUG ),
			'nonce'     => wp_create_nonce( InteractiveAjax::NONCE_ACTION ),
			'page'      => AdminMenu::SLUG,
			'types'     => TypeRegistry::all(),
			'icon_more' => Icon::render( 'more' ),
		);

		$sections = apply_filters(
			'learnpress/interactive/admin/list/sections',
			array(
				'wrapper_open'  => $this->list_wrapper_open_html( $context ),
				'heading'       => $this->list_heading_html(),
				'host_open'     => '<div class="lp-interactive-cb-host"><div class="cb-tab-question">',
				'tab_header'    => $this->list_tab_header_html( $context['add_url'] ),
				'filter_form'   => $this->list_filter_form_html( $context ),
				'table'         => $this->list_table_html(),
				'host_close'    => '</div></div>',
				'wrapper_close' => '</div>',
			),
			$context
		);

		echo Template::combine_components( $sections );
	}

	private function list_wrapper_open_html( array $context ): string {
		return sprintf(
			'<div class="wrap lp-interactive-list-wrap" data-nonce="%s" data-ajax-action="lp_interactive_list" data-icon-more="%s">',
			esc_attr( $context['nonce'] ),
			esc_attr( $context['icon_more'] )
		);
	}

	private function list_heading_html(): string {
		return sprintf(
			'<h1 class="wp-heading-inline screen-reader-text">%s</h1><hr class="wp-header-end" />',
			esc_html__( 'Manager Content Builder', 'learnpress-interactive' )
		);
	}

	private function list_tab_header_html( string $add_url ): string {
		return sprintf(
			'<div class="cb-tab-header">'
			. '<h2 class="lp-cb-tab__title">%s</h2>'
			. '<div class="cb-tab-header-actions">'
			. '<a href="%s" class="lp-button lp-cb-btn-add-new">'
			. '<i class="lp-icon-plus" aria-hidden="true">+</i>%s'
			. '</a>'
			. '</div>'
			. '</div>',
			esc_html__( 'Interactives', 'learnpress-interactive' ),
			esc_url( $add_url ),
			esc_html__( 'Add New', 'learnpress-interactive' )
		);
	}

	private function list_filter_form_html( array $context ): string {
		$groups = array(
			'search'   => $this->filter_group_search_html(),
			'status'   => $this->filter_group_status_html(),
			'type'     => $this->filter_group_type_html( $context['types'] ),
			'per_page' => $this->filter_group_per_page_html(),
			'actions'  => $this->filter_actions_html( $context['reset_url'] ),
		);

		return sprintf(
			'<form class="cb-tab-filter-bar lp-interactive-filter" method="get" autocomplete="off">'
			. '<input type="hidden" name="page" value="%s" />'
			. '<div class="cb-filter-fields">%s</div>'
			. '</form>',
			esc_attr( $context['page'] ),
			Template::combine_components( $groups )
		);
	}

	private function filter_group_search_html(): string {
		return sprintf(
			'<div class="cb-filter-group">'
			. '<label>%s</label>'
			. '<div class="cb-filter-search">'
			. '<input type="search" name="c_search" value="" placeholder="%s" />'
			. '</div>'
			. '</div>',
			esc_html__( 'Search', 'learnpress-interactive' ),
			esc_attr__( 'Search by title', 'learnpress-interactive' )
		);
	}

	private function filter_group_status_html(): string {
		$options_map = array(
			''        => __( 'All Status', 'learnpress-interactive' ),
			'publish' => __( 'Published', 'learnpress-interactive' ),
			'draft'   => __( 'Draft', 'learnpress-interactive' ),
			'trash'   => __( 'Trash', 'learnpress-interactive' ),
		);

		$options = '';
		foreach ( $options_map as $value => $label ) {
			$options .= sprintf(
				'<option value="%s">%s</option>',
				esc_attr( $value ),
				esc_html( $label )
			);
		}

		return sprintf(
			'<div class="cb-filter-group">'
			. '<label>%s</label>'
			. '<select name="c_status" class="cb-filter-select">%s</select>'
			. '</div>',
			esc_html__( 'Status', 'learnpress-interactive' ),
			$options
		);
	}

	private function filter_group_type_html( array $types ): string {
		$options = sprintf(
			'<option value="">%s</option>',
			esc_html__( 'All Types', 'learnpress-interactive' )
		);

		foreach ( $types as $type_obj ) {
			$options .= sprintf(
				'<option value="%s">%s</option>',
				esc_attr( $type_obj->key() ),
				esc_html( $type_obj->label() )
			);
		}

		return sprintf(
			'<div class="cb-filter-group">'
			. '<label>%s</label>'
			. '<select name="c_type" class="cb-filter-select">%s</select>'
			. '</div>',
			esc_html__( 'Type', 'learnpress-interactive' ),
			$options
		);
	}

	private function filter_group_per_page_html(): string {
		$options_map = array(
			'10' => array(
				'label'    => '10',
				'selected' => false,
			),
			'20' => array(
				'label'    => '20',
				'selected' => true,
			),
			'50' => array(
				'label'    => '50',
				'selected' => false,
			),
		);

		$options = '';
		foreach ( $options_map as $value => $cfg ) {
			$options .= sprintf(
				'<option value="%s"%s>%s</option>',
				esc_attr( $value ),
				$cfg['selected'] ? ' selected' : '',
				esc_html( $cfg['label'] )
			);
		}

		return sprintf(
			'<div class="cb-filter-group">'
			. '<label>%s</label>'
			. '<select name="per_page" class="cb-filter-select">%s</select>'
			. '</div>',
			esc_html__( 'Items per page', 'learnpress-interactive' ),
			$options
		);
	}

	private function filter_actions_html( string $reset_url ): string {
		return sprintf(
			'<div class="cb-filter-actions">'
			. '<button type="submit" class="cb-filter-btn">%s</button>'
			. '<a href="%s" class="cb-filter-reset lp-interactive-filter__reset">%s</a>'
			. '</div>',
			esc_html__( 'Filter', 'learnpress-interactive' ),
			esc_url( $reset_url ),
			esc_html__( 'Reset', 'learnpress-interactive' )
		);
	}

	private function list_table_html(): string {
		$column_labels = array(
			'title'     => __( 'Title', 'learnpress-interactive' ),
			'type'      => __( 'Type', 'learnpress-interactive' ),
			'shortcode' => __( 'Shortcode', 'learnpress-interactive' ),
			'author'    => __( 'Author', 'learnpress-interactive' ),
			'date'      => __( 'Date', 'learnpress-interactive' ),
			'status'    => __( 'Status', 'learnpress-interactive' ),
			'actions'   => __( 'Actions', 'learnpress-interactive' ),
		);

		$header_spans = '';
		foreach ( $column_labels as $label ) {
			$header_spans .= sprintf( '<span>%s</span>', esc_html( $label ) );
		}

		return sprintf(
			'<div class="courses-builder__question-tab learn-press-questions">'
			. '<div class="cb-list-table-header">%s</div>'
			. '<ul class="cb-list-question lp-interactive-list__body">'
			. '<li class="cb-list-loading lp-interactive-list__loading">%s</li>'
			. '</ul>'
			. '<div class="learn-press-pagination lp-interactive-pagination"></div>'
			. '</div>',
			$header_spans,
			esc_html__( 'Loading…', 'learnpress-interactive' )
		);
	}
}
