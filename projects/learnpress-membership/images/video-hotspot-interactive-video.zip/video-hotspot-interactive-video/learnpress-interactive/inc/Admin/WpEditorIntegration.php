<?php

namespace LearnPress\Interactive\Admin;

use LearnPress\Interactive\Ajax\InteractiveAjax;
use LearnPress\Interactive\Assets\AssetRegistrar;

defined( 'ABSPATH' ) || exit;

class WpEditorIntegration {

	/** @var bool True while the LearnPress Course Builder page is being rendered. */
	private bool $is_course_builder_context = false;

	public function register(): void {
		add_action( 'init', array( $this, 'register_block' ) );
		add_action( 'admin_init', array( $this, 'register_tinymce' ) );
		add_action( 'learn-press/course-builder/head', array( $this, 'register_course_builder_editor' ) );
		// Gutenberg block registration is global, but its editor assets are
		// screen-gated in enqueue_block_editor_assets() to match Classic Editor.
		add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_block_editor_assets' ) );
	}

	// Gutenberg

	public function register_block(): void {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}

		register_block_type(
			'learnpress/flashcard',
			array(
				'render_callback' => array( $this, 'render_block' ),
				'attributes'      => array(
					'id' => array(
						'type'    => 'integer',
						'default' => 0,
					),
				),
			)
		);
	}

	/**
	 * Server-side render for the Gutenberg block.
	 * Delegates to the same shortcode that the Classic Editor inserts.
	 */
	public function render_block( array $attrs ): string {
		$id = absint( $attrs['id'] ?? 0 );
		if ( 0 === $id ) {
			return '';
		}
		return do_shortcode( '[learnpress_single_interactive id="' . $id . '"]' );
	}

	// Classic Editor (TinyMCE)

	public function register_tinymce(): void {
		if ( ! current_user_can( InteractiveAjax::CAPABILITY ) ) {
			return;
		}

		add_filter( 'mce_buttons', array( $this, 'add_mce_button' ) );
		add_filter( 'mce_external_plugins', array( $this, 'add_mce_plugin' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_wp_editor_assets' ) );
	}


	/**
	 * Whitelist of post types where the FlashCard modal is supported,
	 * shared by Classic Editor (`mce_buttons` / `mce_external_plugins` /
	 * `admin_enqueue_scripts`) and block editor (`enqueue_block_editor_assets`)
	 * paths so the toolbar button and the Gutenberg block only surface on
	 * screens whose CPT is in the list.
	 *
	 * Filter naming uses `post-types` because the returned values are
	 * post-type slugs (matched against `$screen->post_type`), not screen
	 * IDs or bases.
	 *
	 * @return string[]
	 */
	private function supported_post_types(): array {
		return (array) apply_filters(
			'learn-press-interactive/wp-editor/post-types',
			array( 'post', 'page', 'lp_lesson', 'lp_course', 'lp_quiz' )
		);
	}

	private function is_supported_screen(): bool {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}
		$screen = get_current_screen();
		if ( ! $screen ) {
			return false;
		}
		if ( 'post' !== ( $screen->base ?? '' ) ) {
			return false;
		}
		$post_type = isset( $screen->post_type ) ? (string) $screen->post_type : '';
		if ( '' === $post_type ) {
			return false;
		}
		return in_array( $post_type, $this->supported_post_types(), true );
	}

	private function is_editor_context_supported(): bool {
		return $this->is_course_builder_context || $this->is_supported_screen();
	}

	/**
	 * LearnPress Course Builder sets explicit TinyMCE toolbars for these
	 * description editors, so they need the toolbar injection path below.
	 *
	 * @return string[]
	 */
	private function supported_course_builder_editor_ids(): array {
		return (array) apply_filters(
			'learn-press-interactive/wp-editor/course-builder-editor-ids',
			array(
				'course_description_editor',
				'lesson_description_editor',
				'quiz_description_editor',
				'question_description_editor',
			)
		);
	}

	private function is_supported_course_builder_editor( string $editor_id ): bool {
		return in_array( $editor_id, $this->supported_course_builder_editor_ids(), true );
	}

	public function register_course_builder_editor(): void {
		if ( ! current_user_can( InteractiveAjax::CAPABILITY ) ) {
			return;
		}

		$this->is_course_builder_context = true;

		add_filter( 'mce_buttons', array( $this, 'add_mce_button' ) );
		add_filter( 'mce_external_plugins', array( $this, 'add_mce_plugin' ) );
		add_filter( 'tiny_mce_before_init', array( $this, 'add_flashcard_to_tinymce_toolbar' ), 10, 2 );

		$this->enqueue_modal_bundle( $this->asset_suffix() );
	}


	public function add_mce_button( array $buttons ): array {
		if ( ! $this->is_editor_context_supported() ) {
			return $buttons;
		}
		if ( in_array( 'lp_flashcard', $buttons, true ) ) {
			return $buttons;
		}
		$buttons[] = 'lp_flashcard';
		return $buttons;
	}


	public function add_mce_plugin( array $plugins ): array {
		if ( ! $this->is_editor_context_supported() ) {
			return $plugins;
		}
		$plugins['lp_flashcard'] = plugins_url(
			'assets/dist/js/wp-editor/tinymce-plugin' . $this->asset_suffix() . '.js',
			LP_ADDON_INTERACTIVE_FILE
		);
		return $plugins;
	}

	/** Returns true if in debug mode. */
	private function is_debug(): bool {
		return ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG )
			|| ( class_exists( 'LP_Debug' ) && method_exists( 'LP_Debug', 'is_debug' ) && \LP_Debug::is_debug() );
	}

	/** Returns '.min' for production, '' when SCRIPT_DEBUG or LP_Debug::is_debug() is on. */
	private function asset_suffix(): string {
		return $this->is_debug() ? '' : '.min';
	}

	/** Filemtime-based version in debug mode for cache busting. Static plugin version otherwise. */
	private function asset_ver( string $rel ): string {
		if ( ! $this->is_debug() ) {
			return (string) LP_ADDON_INTERACTIVE_VER;
		}
		$path = plugin_dir_path( LP_ADDON_INTERACTIVE_FILE ) . $rel;
		$mt   = file_exists( $path ) ? filemtime( $path ) : 0;
		return $mt ? (string) $mt : (string) LP_ADDON_INTERACTIVE_VER;
	}

	/**
	 * Enqueue FlashCardModal bundle + localize nonce for Classic Editor
	 * (TinyMCE) screens. Includes lp_lesson / lp_course / lp_quiz alongside
	 * post/page so authors editing any LP CPT in Classic Editor still get
	 * the Flashcard modal. Screen whitelist is shared with the button /
	 * plugin filters above via `is_supported_screen()`.
	 */
	public function enqueue_wp_editor_assets(): void {
		if ( ! $this->is_supported_screen() ) {
			return;
		}

		$this->enqueue_modal_bundle( $this->asset_suffix() );
	}

	public function add_flashcard_to_tinymce_toolbar( array $init, string $editor_id = '' ): array {
		if ( ! $this->is_editor_context_supported() ) {
			return $init;
		}
		if ( $this->is_course_builder_context && ! $this->is_supported_course_builder_editor( $editor_id ) ) {
			return $init;
		}

		$toolbar = isset( $init['toolbar1'] ) ? (string) $init['toolbar1'] : '';
		$buttons = array_filter( array_map( 'trim', explode( ',', $toolbar ) ) );
		if ( in_array( 'lp_flashcard', $buttons, true ) ) {
			return $init;
		}

		$wp_adv_index = array_search( 'wp_adv', $buttons, true );
		if ( false === $wp_adv_index ) {
			$buttons[] = 'lp_flashcard';
		} else {
			array_splice( $buttons, (int) $wp_adv_index, 0, array( 'lp_flashcard' ) );
		}

		$init['toolbar1'] = implode( ',', $buttons );
		return $init;
	}

	/**
	 * Enqueue the Gutenberg block JS on supported post types only. Shares
	 * the `is_supported_screen()` gate with the Classic Editor paths so a
	 * site never has the Flashcard block visible in WC product, custom
	 * CPT, or other 3p block-editor screens where the modal isn't wired.
	 *
	 * For authors (users with `InteractiveAjax::CAPABILITY`), the modal
	 * bundle is also enqueued so the block's "Insert" button can call
	 * `window.lpInteractive.openFlashCardModal()`. Readers only get the
	 * block-registration JS (read-only render).
	 */
	public function enqueue_block_editor_assets(): void {
		if ( ! $this->is_supported_screen() ) {
			return;
		}

		$min        = $this->asset_suffix();
		$block_rel  = 'assets/dist/js/wp-editor/gutenberg-block' . $min . '.js';

		wp_enqueue_script(
			'lp-interactive-gutenberg-block',
			plugins_url( $block_rel, LP_ADDON_INTERACTIVE_FILE ),
			array( 'wp-blocks', 'wp-element', 'wp-i18n' ),
			$this->asset_ver( $block_rel ),
			true
		);
		$this->set_translations( 'lp-interactive-gutenberg-block' );

		wp_localize_script(
			'lp-interactive-gutenberg-block',
			'lpInteractiveBlock',
			array(
				'canCreate' => current_user_can( InteractiveAjax::CAPABILITY ),
			)
		);

		if ( ! current_user_can( InteractiveAjax::CAPABILITY ) ) {
			return;
		}

		$this->enqueue_modal_bundle( $min );
	}

	/**
	 * Enqueues the modal bundle resources.
	 */
	private function enqueue_modal_bundle( string $min ): void {
		$js_rel  = 'assets/dist/js/wp-editor/lp-interactive-wp-editor' . $min . '.js';
		$css_rel = 'assets/dist/js/wp-editor/lp-interactive-wp-editor' . $min . '.css';

		wp_enqueue_script(
			'lp-interactive-wp-editor',
			plugins_url( $js_rel, LP_ADDON_INTERACTIVE_FILE ),
			array( 'wp-i18n' ),
			$this->asset_ver( $js_rel ),
			true
		);
		$this->set_translations( 'lp-interactive-wp-editor' );

		// CSS extracted from the same bundle (FlashCardModal imports flashcard-modal.scss).
		wp_enqueue_style(
			'lp-interactive-wp-editor',
			plugins_url( $css_rel, LP_ADDON_INTERACTIVE_FILE ),
			array(),
			$this->asset_ver( $css_rel )
		);

		wp_localize_script(
			'lp-interactive-wp-editor',
			'lpInteractive',
			array(
				'nonce'   => wp_create_nonce( InteractiveAjax::NONCE_ACTION ),
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			)
		);

		// Same icon map the admin builder uses — keeps the modal in sync.
		AssetRegistrar::localize_icon_map( 'lp-interactive-wp-editor' );

		wp_enqueue_media();

		if ( function_exists( 'wp_enqueue_editor' ) ) {
			wp_enqueue_editor();
		}
	}

	/**
	 * Register the plugin's text domain against the given JS handle so wp.i18n
	 * picks up translations from learnpress-interactive-{locale}.json files.
	 */
	private function set_translations( string $handle ): void {
		if ( function_exists( 'wp_set_script_translations' ) ) {
			wp_set_script_translations(
				$handle,
				'learnpress-interactive',
				plugin_dir_path( LP_ADDON_INTERACTIVE_FILE ) . 'languages'
			);
		}
	}
}
