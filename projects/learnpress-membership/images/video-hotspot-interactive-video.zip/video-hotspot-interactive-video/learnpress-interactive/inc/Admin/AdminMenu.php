<?php

namespace LearnPress\Interactive\Admin;

use LearnPress\Helpers\Singleton;

defined( 'ABSPATH' ) || exit;

/**
 * Class AdminMenu
 *
 * Registers the "Interactive" submenu under the LearnPress top-level menu
 * (alongside Certificates / Lab) and dispatches the page render to either the
 * list or edit screen based on `$_GET['action']`.
 *
 * @since 1.0.0
 * @version 1.0.0
 */
class AdminMenu {
	use Singleton;

	public const SLUG        = 'lp-interactive';
	public const CAPABILITY  = 'edit_lp_courses';
	public const PARENT_SLUG = 'learn_press';

	public function init(): void {
		// Priority 60 to register after LearnPress core admin menu (priority 0–10).
		add_action( 'admin_menu', array( $this, 'register_menu' ), 60 );
	}

	/**
	 * Hook callback — registers the submenu page on admin_menu.
	 */
	public function register_menu(): void {
		add_submenu_page(
			self::PARENT_SLUG,
			__( 'Interactive', 'learnpress-interactive' ),
			__( 'Interactive', 'learnpress-interactive' ),
			self::CAPABILITY,
			self::SLUG,
			array( $this, 'render' )
		);
	}

	/**
	 * Single entry point for the page — dispatches to list / create / editor.
	 */
	public function render(): void {
		$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : 'list';

		switch ( $action ) {
			case 'new':
			case 'edit':
				( new AdminInteractiveEditPage() )->render();
				break;

			case 'list':
			default:
				( new AdminInteractiveListPage() )->render();
				break;
		}
	}
}
