<?php
/**
 * Plugin load class.
 *
 * @since 1.0.0
 * @version 1.0.0
 */

use LearnPress\Interactive\Admin\AdminInteractiveEditPage;
use LearnPress\Interactive\Admin\AdminMenu;
use LearnPress\Interactive\Admin\WpEditorIntegration;
use LearnPress\Interactive\Ajax\InteractiveAjax;
use LearnPress\Interactive\Assets\AssetRegistrar;
use LearnPress\Interactive\Shortcodes\InteractivesListShortcode;
use LearnPress\Interactive\Shortcodes\SingleInteractiveShortcode;
use LearnPress\Interactive\Types\TypeRegistry;

defined( 'ABSPATH' ) || exit;

class LP_Addon_Interactive extends LP_Addon {
	public $version         = LP_ADDON_INTERACTIVE_VER;
	public $require_version = LP_ADDON_INTERACTIVE_REQUIRE_VER;
	public $plugin_file     = LP_ADDON_INTERACTIVE_FILE;
	public $text_domain     = 'learnpress-interactive';
	public static $instance = null;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * LP_Addon_Interactive constructor.
	 */
	public function __construct() {
		parent::__construct();

		$this->hooks();
	}

	protected function hooks() {
		TypeRegistry::boot();
		AssetRegistrar::register();
		InteractiveAjax::instance();

		if ( class_exists( '\LearnPress\Shortcodes\AbstractShortcode' ) ) {
			SingleInteractiveShortcode::instance();
			InteractivesListShortcode::instance();
		}
		( new WpEditorIntegration() )->register();

		if ( is_admin() ) {
			AdminMenu::instance();
			add_action( 'admin_post_lp_interactive_save_form', array( AdminInteractiveEditPage::class, 'handle_form_save' ) );
		}
	}
}
