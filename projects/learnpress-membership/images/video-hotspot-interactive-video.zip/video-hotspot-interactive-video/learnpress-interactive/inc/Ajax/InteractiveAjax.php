<?php

namespace LearnPress\Interactive\Ajax;

use LearnPress\Helpers\Singleton;
use LearnPress\Interactive\Databases\InteractiveDB;
use LearnPress\Interactive\Filters\InteractiveFilter;
use LearnPress\Interactive\Models\InteractiveItemModel;
use LearnPress\Interactive\Models\InteractiveModel;
use LearnPress\Interactive\Services\GoogleFontCacheService;
use LearnPress\Interactive\Services\InteractiveService;
use LearnPress\Interactive\Types\FlashCardType;
use LearnPress\Interactive\Types\TypeRegistry;
use Throwable;

defined( 'ABSPATH' ) || exit;

/**
 * Class InteractiveAjax
 *
 * Centralized admin-ajax.php endpoints for interactive content management.
 * Each handler runs the same gate (nonce + capability) before delegating
 * to InteractiveService for actual work.
 *
 * Action names: wp_ajax_lp_interactive_{create|save|get|list|delete|restore|force_delete|duplicate|cache_google_font|list_cached_google_fonts}.
 *
 * @since 1.0.0
 * @version 1.0.0
 */
class InteractiveAjax {
	use Singleton;

	public const NONCE_ACTION = 'lp-interactive-nonce';
	public const CAPABILITY   = 'edit_lp_courses';

	/**
	 * Hook every handler. Called from plugin bootstrap.
	 */
	public function init(): void {
		$actions = array(
			'create',
			'save',
			'save_meta',
			'save_slide_content',
			'create_slide',
			'delete_slide',
			'reorder_slides',
			'cache_google_font',
			'list_cached_google_fonts',
			'get',
			'list',
			'delete',
			'restore',
			'force_delete',
			'duplicate',
		);
		foreach ( $actions as $action ) {
			add_action(
				'wp_ajax_lp_interactive_' . $action,
				array( $this, 'handle_' . $action )
			);
		}
	}

	// Helpers — gate + response
	/**
	 * Verify nonce + capability before any handler runs. Aborts with 403 on fail.
	 */
	private function gate(): void {
		if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
			$this->error( 'invalid_nonce', 403 );
		}
		if ( ! current_user_can( self::CAPABILITY ) ) {
			$this->error( 'forbidden', 403 );
		}
	}

	/**
	 * Send a Unicode-safe success JSON response and exit.
	 *
	 * @param array $data
	 */
	private function success( array $data = array() ): void {
		wp_send_json(
			array(
				'success' => true,
				'data'    => $data,
			),
			200,
			JSON_UNESCAPED_UNICODE
		);
	}

	/**
	 * Send a Unicode-safe error JSON response and exit.
	 */
	private function error( string $code, int $http = 400, string $message = '' ): void {
		wp_send_json(
			array(
				'success' => false,
				'data'    => array(
					'code'    => $code,
					'message' => $message,
				),
			),
			$http,
			JSON_UNESCAPED_UNICODE
		);
	}

	/**
	 * Decode a JSON string field coming from $_POST / $_REQUEST (admin-ajax context).
	 *
	 * wp_magic_quotes() runs on every admin-ajax.php request and addslashes() the
	 * superglobals. JSON_decode chokes on the backslashed quotes, so wp_unslash()
	 * must run first to restore the literal JSON before decoding. This mirrors
	 * learnpress-certificates EditCertificateAjax::check_valid().
	 *
	 * Accepts mixed so callers can pass `$_POST[key] ?? null` directly — a
	 * client posting an array (e.g. `items[]=…`) instead of a JSON string
	 * yields an empty result rather than a "Array to string conversion" warning.
	 *
	 * @param mixed $raw Raw superglobal value. Expected JSON string; any other
	 *                   type (null, array, object, scalar) returns `array()`.
	 * @return array Decoded associative array, or `array()` on any failure.
	 */
	private function decode_json_field( $raw ): array {
		if ( ! is_string( $raw ) || '' === $raw ) {
			return array();
		}
		$raw = wp_unslash( $raw );
		try {
			$decoded = \LP_Helper::json_decode( $raw, true );
			return is_array( $decoded ) ? $decoded : array();
		} catch ( \Throwable $e ) {
			$this->log_internal( __METHOD__, $e );
			return array();
		}
	}

	/**
	 * Log an internal error when WP_DEBUG is on. Never echoes to client.
	 */
	private function log_internal( string $context, \Throwable $e ): void {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( $context . ': ' . $e->getMessage() );
		}
	}

	/**
	 * Find a model by ID or send 404 + exit. Caller never sees a missing record.
	 */
	private function find_or_404( int $id ): InteractiveModel {
		$model = InteractiveModel::find( $id );
		if ( ! $model ) {
			$this->error( 'not_found', 404 );
		}
		return $model;
	}

	private function valid_status( string $status ): bool {
		return in_array( $status, array( 'publish', 'draft', 'trash' ), true );
	}

	private function valid_type( string $key ): bool {
		return null !== TypeRegistry::get( $key );
	}

	// Handlers

	/**
	 * Create a new interactive entry. Optionally seed initial items.
	 *
	 * Input: title (text), type (whitelist), status?, items? (JSON), settings? (JSON).
	 * Output: { id, edit_url }.
	 */
	public function handle_create(): void {
		$this->gate();

		$title = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
		$title = mb_substr( $title, 0, 255 ); // DB column is varchar(255).
		$type  = isset( $_POST['type'] ) ? sanitize_key( wp_unslash( $_POST['type'] ) ) : '';

		if ( ! $this->valid_type( $type ) ) {
			$this->error( 'invalid_type' );
		}
		if ( '' === $title ) {
			$type_strategy = TypeRegistry::get( $type );
			if ( $type_strategy && method_exists( $type_strategy, 'default_title' ) ) {
				$title = mb_substr( sanitize_text_field( (string) $type_strategy->default_title() ), 0, 255 );
			}
			if ( '' === $title ) {
				$this->error( 'title_required' );
			}
		}

		$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'publish';
		if ( ! $this->valid_status( $status ) ) {
			$this->error( 'invalid_status' );
		}

		$items    = $this->decode_json_field( $_POST['items'] ?? null );
		$settings = $this->decode_json_field( $_POST['settings'] ?? null );

		$id = 0;
		try {
			$id = InteractiveService::instance()->create_with_items(
				array(
					'title'    => $title,
					'type'     => $type,
					'status'   => $status,
					'author'   => get_current_user_id(),
					'settings' => $settings,
					'items'    => $items,
				)
			);
		} catch ( Throwable $e ) {
			$this->log_internal( __METHOD__, $e );
			$this->error( 'create_failed', 500 );
		}

		if ( ! $id ) {
			$this->error( 'create_failed', 500 );
		}

		$this->success(
			array(
				'id'       => $id,
				'edit_url' => admin_url( 'admin.php?page=lp-interactive&action=edit&id=' . $id ),
			)
		);
	}

	/**
	 * Update an existing interactive entry. Only fields present in POST are touched.
	 *
	 * Input: id (int), title?, status?, items? (JSON), settings? (JSON).
	 * Output: { id, updated_at }.
	 */
	public function handle_save(): void {
		$this->gate();

		$id = absint( $_POST['id'] ?? 0 );
		if ( ! $id ) {
			$this->error( 'invalid_id' );
		}

		$payload = array();
		if ( isset( $_POST['title'] ) ) {
			$payload['title'] = mb_substr(
				sanitize_text_field( wp_unslash( $_POST['title'] ) ),
				0,
				255
			);
		}
		if ( isset( $_POST['status'] ) ) {
			$status = sanitize_key( wp_unslash( $_POST['status'] ) );
			if ( ! $this->valid_status( $status ) ) {
				$this->error( 'invalid_status' );
			}
			$payload['status'] = $status;
		}
		if ( isset( $_POST['settings'] ) ) {
			$payload['settings'] = $this->decode_json_field( $_POST['settings'] );
		}
		if ( isset( $_POST['items'] ) ) {
			$payload['items'] = $this->decode_json_field( $_POST['items'] );
		}

		$ok = false;
		try {
			$ok = InteractiveService::instance()->save( $id, $payload );
		} catch ( Throwable $e ) {
			$this->log_internal( __METHOD__, $e );
			$this->error( 'save_failed', 500 );
		}

		if ( ! $ok ) {
			$this->error( 'save_failed', 500 );
		}

		$model = InteractiveModel::find( $id );
		$data  = array(
			'id'         => $id,
			'updated_at' => $model ? $model->updated_at : '',
		);
		if ( array_key_exists( 'items', $payload ) ) {
			$data['items'] = $this->items_response_rows( $id );
		}
		$this->success( $data );
	}

	/**
	 * Update parent row metadata only. Items are never touched.
	 *
	 * Input: id (int), title?, status?, settings? (JSON).
	 * Output: { id, updated_at }.
	 */
	public function handle_save_meta(): void {
		$this->gate();

		$id = absint( $_POST['id'] ?? 0 );
		if ( ! $id ) {
			$this->error( 'invalid_id' );
		}

		$payload = array();
		if ( isset( $_POST['title'] ) ) {
			$payload['title'] = mb_substr(
				sanitize_text_field( wp_unslash( $_POST['title'] ) ),
				0,
				255
			);
		}
		if ( isset( $_POST['status'] ) ) {
			$status = sanitize_key( wp_unslash( $_POST['status'] ) );
			if ( ! $this->valid_status( $status ) ) {
				$this->error( 'invalid_status' );
			}
			$payload['status'] = $status;
		}
		if ( isset( $_POST['settings'] ) ) {
			$payload['settings'] = $this->decode_json_field( $_POST['settings'] );
		}

		try {
			if ( ! InteractiveService::instance()->save( $id, $payload ) ) {
				$this->error( 'save_failed', 500 );
			}
		} catch ( Throwable $e ) {
			$this->log_internal( __METHOD__, $e );
			$this->error( 'save_failed', 500 );
		}

		$model = InteractiveModel::find( $id );
		$this->success(
			array(
				'id'         => $id,
				'updated_at' => $model ? $model->updated_at : '',
			)
		);
	}

	/**
	 * Update one slide's canvas content.
	 *
	 * Input: id (int), slide_id (int), slide (JSON).
	 * Output: { id, slide_id }.
	 */
	public function handle_save_slide_content(): void {
		$this->gate();

		$id       = absint( $_POST['id'] ?? 0 );
		$slide_id = absint( $_POST['slide_id'] ?? 0 );
		if ( ! $id || ! $slide_id ) {
			$this->error( 'invalid_id' );
		}

		$slide = $this->decode_json_field( $_POST['slide'] ?? null );
		if ( ! is_array( $slide ) ) {
			$slide = array();
		}

		try {
			if ( ! InteractiveService::instance()->save_slide_content( $id, $slide_id, $slide ) ) {
				$this->error( 'save_failed', 500 );
			}
		} catch ( Throwable $e ) {
			$this->log_internal( __METHOD__, $e );
			$this->error( 'save_failed', 500 );
		}

		$this->success(
			array(
				'id'       => $id,
				'slide_id' => $slide_id,
			)
		);
	}

	public function handle_create_slide(): void {
		$this->gate();

		$id         = absint( $_POST['id'] ?? 0 );
		$sort_order = absint( $_POST['sort_order'] ?? 0 );
		if ( ! $id ) {
			$this->error( 'invalid_id' );
		}

		$slide = $this->decode_json_field( $_POST['slide'] ?? null );
		if ( ! is_array( $slide ) ) {
			$slide = array();
		}

		$slide_id = 0;
		try {
			$slide_id = InteractiveService::instance()->create_slide( $id, $slide, $sort_order );
		} catch ( Throwable $e ) {
			$this->log_internal( __METHOD__, $e );
			$this->error( 'save_failed', 500 );
		}

		if ( ! $slide_id ) {
			$this->error( 'save_failed', 500 );
		}

		$this->success(
			array(
				'id'       => $id,
				'slide_id' => $slide_id,
				'slide'    => array(
					'ID'             => $slide_id,
					'interactive_id' => $id,
					'sort_order'     => $sort_order,
				),
			)
		);
	}

	public function handle_delete_slide(): void {
		$this->gate();

		$id       = absint( $_POST['id'] ?? 0 );
		$slide_id = absint( $_POST['slide_id'] ?? 0 );
		if ( ! $id || ! $slide_id ) {
			$this->error( 'invalid_id' );
		}

		try {
			if ( ! InteractiveService::instance()->delete_slide( $id, $slide_id ) ) {
				$this->error( 'save_failed', 500 );
			}
		} catch ( Throwable $e ) {
			$this->log_internal( __METHOD__, $e );
			$this->error( 'save_failed', 500 );
		}

		$this->success(
			array(
				'id'       => $id,
				'slide_id' => $slide_id,
			)
		);
	}

	public function handle_reorder_slides(): void {
		$this->gate();

		$id = absint( $_POST['id'] ?? 0 );
		if ( ! $id ) {
			$this->error( 'invalid_id' );
		}

		$slide_ids = $this->decode_json_field( $_POST['slide_ids'] ?? null );
		$slide_ids = array_values(
			array_filter( array_map( 'absint', is_array( $slide_ids ) ? $slide_ids : array() ) )
		);
		if ( empty( $slide_ids ) ) {
			$this->error( 'invalid_id' );
		}

		try {
			if ( ! InteractiveService::instance()->reorder_slides( $id, $slide_ids ) ) {
				$this->error( 'save_failed', 500 );
			}
		} catch ( Throwable $e ) {
			$this->log_internal( __METHOD__, $e );
			$this->error( 'save_failed', 500 );
		}

		$this->success(
			array(
				'id'        => $id,
				'slide_ids' => $slide_ids,
			)
		);
	}

	public function handle_cache_google_font(): void {
		$this->gate();

		$family = isset( $_POST['family'] ) ? sanitize_text_field( wp_unslash( $_POST['family'] ) ) : '';
		if ( '' === $family ) {
			$this->error( 'invalid_font' );
		}

		$files = $this->decode_json_field( $_POST['files'] ?? null );
		if ( ! is_array( $files ) ) {
			$files = array();
		}
		$variants = $this->decode_json_field( $_POST['variants'] ?? null );
		if ( ! is_array( $variants ) ) {
			$variants = array();
		}
		$variant = isset( $_POST['variant'] ) ? sanitize_key( wp_unslash( $_POST['variant'] ) ) : 'regular';

		try {
			$payload = ( new GoogleFontCacheService() )->cache( $family, $files, $variant, $variants );
		} catch ( Throwable $e ) {
			$this->log_internal( __METHOD__, $e );
			$this->error( 'font_cache_failed', 500 );
		}

		$this->success( $payload );
	}

	public function handle_list_cached_google_fonts(): void {
		$this->gate();

		$this->success(
			array(
				'fonts' => ( new GoogleFontCacheService() )->cached_fonts(),
			)
		);
	}

	/**
	 * Fetch a single interactive entry + items by ID.
	 *
	 * Input: id (int).
	 * Output: { parent: {...}, items: [...] }.
	 */
	public function handle_get(): void {
		$this->gate();

		$id = absint( $_POST['id'] ?? 0 );
		if ( ! $id ) {
			$this->error( 'invalid_id' );
		}

		$model    = $this->find_or_404( $id );
		$is_flash = 'flash_card' === $model->type;

		$items = array_map(
			static function ( $item ) use ( $is_flash ) {
				$row = array(
					'ID'             => $item->ID,
					'interactive_id' => $item->interactive_id,
					'content'        => $item->content,
					'sort_order'     => $item->sort_order,
					'extra_data'     => is_array( $item->extra_data ) ? $item->extra_data : null,
				);
				if ( $is_flash ) {
					$row['card'] = FlashCardType::enrich_card_urls( FlashCardType::decode_card( $row ) );
				}
				return $row;
			},
			InteractiveItemModel::find_by_parent( $id )
		);

		$this->success(
			array(
				'parent' => array(
					'ID'         => $model->ID,
					'title'      => $model->title,
					'type'       => $model->type,
					'status'     => $model->status,
					'author'     => $model->author,
					'extra_data' => $model->extra_data,
					'created_at' => $model->created_at,
					'updated_at' => $model->updated_at,
				),
				'items'  => $items,
			)
		);
	}

	/**
	 * Build item rows for AJAX responses.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private function items_response_rows( int $id ): array {
		return array_map(
			static function ( $item ) {
				return array(
					'ID'             => $item->ID,
					'interactive_id' => $item->interactive_id,
					'content'        => $item->content,
					'sort_order'     => $item->sort_order,
					'extra_data'     => is_array( $item->extra_data ) ? $item->extra_data : null,
				);
			},
			InteractiveItemModel::find_by_parent( $id )
		);
	}

	/**
	 * List entries for the admin manager screen with pagination + filter + sort.
	 *
	 * Input: s? (search title), type?, status?, author?, paged?, per_page?, orderby?, order?.
	 * Output: { items: [...row summaries with shortcode...], total, total_pages, paged }.
	 */
	public function handle_list(): void {
		$this->gate();

		$allowed_orderby = array( 'title', 'type', 'status', 'author', 'created_at', 'updated_at' );
		$orderby_in      = isset( $_POST['orderby'] ) ? sanitize_key( wp_unslash( $_POST['orderby'] ) ) : 'created_at';
		$orderby         = in_array( $orderby_in, $allowed_orderby, true ) ? $orderby_in : 'created_at';
		$order_in        = isset( $_POST['order'] ) ? strtoupper( sanitize_key( wp_unslash( $_POST['order'] ) ) ) : 'DESC';
		$order           = 'ASC' === $order_in ? 'ASC' : 'DESC';

		$filter        = new InteractiveFilter();
		$filter->title = isset( $_POST['s'] ) ? sanitize_text_field( wp_unslash( $_POST['s'] ) ) : '';

		$type_in      = isset( $_POST['type'] ) ? sanitize_key( wp_unslash( $_POST['type'] ) ) : '';
		$filter->type = ( '' !== $type_in && $this->valid_type( $type_in ) ) ? $type_in : '';

		$status_input = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';
		if ( '' !== $status_input && $this->valid_status( $status_input ) ) {
			$filter->status = $status_input;
		} else {
			$filter->status_in = array( 'publish', 'draft', 'trash' );
		}
		$filter->author   = absint( $_POST['author'] ?? 0 );
		$filter->page     = max( 1, absint( $_POST['paged'] ?? 1 ) );
		$filter->limit    = max( 1, min( 100, absint( $_POST['per_page'] ?? 20 ) ) );
		$filter->order_by = $orderby;
		$filter->order    = $order;

		$total = 0;
		$rows  = array();
		try {
			$rows = InteractiveDB::getInstance()->get_interactives( $filter, $total );
		} catch ( Throwable $e ) {
			$this->log_internal( __METHOD__, $e );
			$this->error( 'query_failed', 500 );
		}

		$rows = (array) ( $rows ?? array() );

		$row_ids = array();
		foreach ( $rows as $row ) {
			$row_ids[] = (int) ( is_object( $row ) ? $row->ID : ( $row['ID'] ?? 0 ) );
		}
		$count_map = InteractiveItemModel::count_by_parent_ids( $row_ids );

		$items = array();
		foreach ( $rows as $row ) {
			$id      = (int) ( is_object( $row ) ? $row->ID : ( $row['ID'] ?? 0 ) );
			$row_arr = is_object( $row ) ? get_object_vars( $row ) : (array) $row;

			$author_id   = (int) ( $row_arr['author'] ?? 0 );
			$author_name = '';
			if ( $author_id > 0 ) {
				$user = get_userdata( $author_id );
				if ( $user ) {
					$author_name = $user->display_name;
				}
			}

			$type_key = (string) ( $row_arr['type'] ?? '' );
			$type_obj = $type_key ? TypeRegistry::get( $type_key ) : null;

			$items[] = array(
				'id'          => $id,
				'title'       => $row_arr['title'] ?? '',
				'type'        => $type_key,
				'type_label'  => $type_obj ? $type_obj->label() : $type_key,
				'status'      => $row_arr['status'] ?? '',
				'author'      => $author_id,
				'author_name' => $author_name,
				'shortcode'   => '[learnpress_single_interactive id=' . $id . ']',
				'edit_url'    => admin_url( 'admin.php?page=lp-interactive&action=edit&id=' . $id ),
				'created_at'  => $row_arr['created_at'] ?? '',
				'updated_at'  => $row_arr['updated_at'] ?? '',
				'item_count'  => (int) ( $count_map[ $id ] ?? 0 ),
			);
		}

		$total_pages = $filter->limit > 0 ? (int) ceil( $total / $filter->limit ) : 0;

		$this->success(
			array(
				'items'       => $items,
				'total'       => (int) $total,
				'total_pages' => $total_pages,
				'paged'       => $filter->page,
			)
		);
	}

	/**
	 * Soft delete (status=trash). Input: id. Output: { id }.
	 */
	public function handle_delete(): void {
		$this->gate();

		$id = absint( $_POST['id'] ?? 0 );
		if ( ! $id ) {
			$this->error( 'invalid_id' );
		}

		$this->find_or_404( $id );

		$ok = false;
		try {
			$ok = InteractiveService::instance()->soft_delete( $id );
		} catch ( Throwable $e ) {
			$this->log_internal( __METHOD__, $e );
			$this->error( 'delete_failed', 500 );
		}

		if ( ! $ok ) {
			$this->error( 'delete_failed', 500 );
		}

		$this->success( array( 'id' => $id ) );
	}

	/**
	 * Restore from trash (status=publish). Input: id. Output: { id }.
	 */
	public function handle_restore(): void {
		$this->gate();

		$id = absint( $_POST['id'] ?? 0 );
		if ( ! $id ) {
			$this->error( 'invalid_id' );
		}

		$this->find_or_404( $id );

		$ok = false;
		try {
			$ok = InteractiveService::instance()->restore( $id );
		} catch ( Throwable $e ) {
			$this->log_internal( __METHOD__, $e );
			$this->error( 'restore_failed', 500 );
		}

		if ( ! $ok ) {
			$this->error( 'restore_failed', 500 );
		}

		$this->success( array( 'id' => $id ) );
	}

	/**
	 * Permanently delete an entry after the admin confirms the action.
	 * Input: id. Output: { id }.
	 */
	public function handle_force_delete(): void {
		$this->gate();

		$id = absint( $_POST['id'] ?? 0 );
		if ( ! $id ) {
			$this->error( 'invalid_id' );
		}

		$model = $this->find_or_404( $id );

		if ( 'trash' !== $model->status ) {
			$this->error( 'not_in_trash', 400 );
		}

		$ok = false;
		try {
			$ok = InteractiveService::instance()->force_delete( $id );
		} catch ( Throwable $e ) {
			$this->log_internal( __METHOD__, $e );
			$this->error( 'force_delete_failed', 500 );
		}

		if ( ! $ok ) {
			$this->error( 'force_delete_failed', 500 );
		}

		$this->success( array( 'id' => $id ) );
	}

	/**
	 * Duplicate an entry + items as a new draft.
	 * Input: id (int). Output: { id: new_id }.
	 */
	public function handle_duplicate(): void {
		$this->gate();

		$id = absint( $_POST['id'] ?? 0 );
		if ( ! $id ) {
			$this->error( 'invalid_id' );
		}

		$this->find_or_404( $id );

		$new_id = 0;
		try {
			$new_id = InteractiveService::instance()->duplicate( $id );
		} catch ( Throwable $e ) {
			$this->log_internal( __METHOD__, $e );
			$this->error( 'duplicate_failed', 500 );
		}

		if ( ! $new_id ) {
			$this->error( 'duplicate_failed', 500 );
		}

		$this->success( array( 'id' => $new_id ) );
	}
}
