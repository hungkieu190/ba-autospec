<?php

namespace LearnPress\Interactive\Assets;

defined( 'ABSPATH' ) || exit;

final class AssetRegistrar {


	private const ASSETS = array(
		'flash_card' => array( 'handle' => 'lp-interactive-flash-card', 'has_js' => true ),
	);

	/** @var bool guard so register() only adds the action once per request. */
	private static bool $hooked = false;

	private const ADMIN_HANDLE = 'lp-admin-interactive';

	public static function register(): void {
		if ( self::$hooked ) {
			return;
		}
		self::$hooked = true;
		add_action( 'wp_enqueue_scripts', array( self::class, 'register_handles' ) );
		add_action( 'admin_enqueue_scripts', array( self::class, 'register_admin_handles' ) );

		add_action( 'wp_enqueue_scripts', array( self::class, 'eager_enqueue_when_shortcode_present' ), 11 );
	}

	public static function eager_enqueue_when_shortcode_present(): void {
		if ( is_admin() ) {
			return;
		}

		global $post;
		$should_enqueue = false;

		if ( function_exists( 'learn_press_is_course' ) && learn_press_is_course() ) {
			$should_enqueue = true;
		} elseif ( $post && ! empty( $post->post_content )
			&& function_exists( 'has_shortcode' )
			&& ( has_shortcode( $post->post_content, 'learnpress_single_interactive' )
				|| has_shortcode( $post->post_content, 'learnpress_interactives' ) ) ) {
			$should_enqueue = true;
		} elseif ( $post && function_exists( 'has_block' ) && has_block( 'learnpress/flashcard', $post ) ) {
			$should_enqueue = true;
		}

		$should_enqueue = (bool) apply_filters(
			'learn-press-interactive/assets/eager-enqueue',
			$should_enqueue,
			$post
		);

		if ( ! $should_enqueue ) {
			return;
		}

		foreach ( self::ASSETS as $info ) {
			self::enqueue_for_type( array( $info['handle'] ) );
		}
	}

	public static function register_handles(): void {
		$base_url = plugins_url( 'assets/dist', LP_ADDON_INTERACTIVE_FILE );
		$base_dir = plugin_dir_path( LP_ADDON_INTERACTIVE_FILE ) . 'assets/dist';
		$plugin_ver = defined( 'LP_ADDON_INTERACTIVE_VER' ) ? LP_ADDON_INTERACTIVE_VER : '1.0.0';
		$debug    = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG )
			|| ( class_exists( 'LP_Debug' ) && method_exists( 'LP_Debug', 'is_debug' ) && \LP_Debug::is_debug() );
		$min      = $debug ? '' : '.min';

		$asset_ver = static function ( string $rel ) use ( $base_dir, $plugin_ver, $debug ) {
			if ( ! $debug ) {
				return $plugin_ver;
			}
			$path = $base_dir . $rel;
			$mtime = file_exists( $path ) ? filemtime( $path ) : 0;
			return $mtime ? (string) $mtime : $plugin_ver;
		};

		foreach ( self::ASSETS as $type_key => $info ) {
			$slug   = str_replace( '_', '-', $type_key );
			$handle = $info['handle'];

			$css_rel = '/js/frontend/types/' . $slug . $min . '.css';
			$js_rel  = '/js/frontend/types/' . $slug . $min . '.js';

			wp_register_style(
				$handle,
				$base_url . $css_rel,
				array(),
				$asset_ver( $css_rel )
			);

			if ( $info['has_js'] ) {
				wp_register_script(
					$handle,
					$base_url . $js_rel,
					array(),
					$asset_ver( $js_rel ),
					true
				);
			}
		}
	}

	public static function register_admin_handles( $hook_suffix = '' ): void {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		if ( 'lp-interactive' !== $page ) {
			return;
		}

		$base_dir = plugin_dir_path( LP_ADDON_INTERACTIVE_FILE ) . 'assets/dist/js/admin/lp-admin-interactive';
		$debug = ( class_exists( 'LP_Debug' ) && \LP_Debug::is_debug() )
			|| ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG );
		$preferred = $debug ? '' : '.min';
		$alternate = $debug ? '.min' : '';

		$is_usable_bundle = static function ( string $path ): bool {
			return file_exists( $path ) && filesize( $path ) > 1024;
		};
		$suffix = ( ! $is_usable_bundle( $base_dir . $preferred . '.js' ) && $is_usable_bundle( $base_dir . $alternate . '.js' ) )
			? $alternate
			: $preferred;

		$asset_path = $base_dir . $suffix . '.asset.php';
		$asset_meta = file_exists( $asset_path )
			? include $asset_path
			: array( 'dependencies' => array(), 'version' => null );
		$dependencies = array_values(
			array_unique(
				array_merge(
					$asset_meta['dependencies'] ?? array(),
					array( 'postbox' )
				)
			)
		);

		$bundle_rel = 'assets/dist/js/admin/lp-admin-interactive' . $suffix;
		wp_register_script(
			self::ADMIN_HANDLE,
			plugins_url( $bundle_rel . '.js', LP_ADDON_INTERACTIVE_FILE ),
			$dependencies,
			$asset_meta['version'] ?? null,
			true
		);

		wp_register_style(
			self::ADMIN_HANDLE,
			plugins_url( $bundle_rel . '.css', LP_ADDON_INTERACTIVE_FILE ),
			array(),
			$asset_meta['version'] ?? null
		);

		self::localize_icon_map( self::ADMIN_HANDLE );

		wp_enqueue_script( self::ADMIN_HANDLE );
		wp_enqueue_style( self::ADMIN_HANDLE );

		if ( function_exists( 'wp_enqueue_media' ) ) {
			wp_enqueue_media();
		}

		if ( function_exists( 'wp_enqueue_editor' ) ) {
			wp_enqueue_editor();
		}
	}


	public static function localize_icon_map( string $handle ): void {
		if ( ! class_exists( '\LearnPress\Interactive\Helpers\Icon' ) ) {
			return;
		}

		$names = array(
			'align-center', 'align-left', 'align-right', 'back', 'bold',
			'celebrate', 'check', 'chevron-down', 'close', 'close-md',
			'cloud-check', 'copy', 'drag', 'duplicate', 'effects',
			'flip', 'fullscreen', 'fullscreen-exit', 'hamburger', 'image-lg', 'italic', 'layers', 'layout-grid',
			'layout-slider', 'menu', 'minus', 'next', 'paint', 'panel-toggle', 'plus', 'present',
			'prev', 'rail-bg', 'rail-text', 'rail-uploads', 'redo', 'search',
			'lock', 'strike', 'text-spacing', 'trash', 'underline', 'undo',
		);

		$map = array();
		foreach ( $names as $name ) {
			$map[ $name ] = \LearnPress\Interactive\Helpers\Icon::render( $name );
		}

		wp_localize_script( $handle, 'lpInteractiveIcons', $map );
	}

	public static function enqueue_for_type( array $handles ): void {
		foreach ( $handles as $handle ) {
			if ( ! is_string( $handle ) || '' === $handle ) {
				continue;
			}
			if ( wp_style_is( $handle, 'registered' ) ) {
				wp_enqueue_style( $handle );
			}
			if ( wp_script_is( $handle, 'registered' ) ) {
				wp_enqueue_script( $handle );
			}
		}
	}

	public static function reset_for_tests(): void {
		self::$hooked = false;
	}
}
