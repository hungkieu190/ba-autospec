<?php

namespace LearnPress\Interactive\Models;

use LearnPress\Interactive\Databases\InteractiveDB;
use LearnPress\Interactive\Filters\InteractiveFilter;
use stdClass;
use Throwable;

defined( 'ABSPATH' ) || exit;

/**
 * Class InteractiveModel
 *
 * Entity for parent table `wp_learnpress_interactive`. One instance = one row.
 *
 * @since 1.0.0
 * @version 1.0.0
 */
class InteractiveModel {

	/**
	 * Auto increment, Primary key.
	 * @var int
	 */
	public $ID = 0;
	/**
	 * @var string
	 */
	public $title = '';
	/**
	 * @var string
	 */
	public $type = '';
	/**
	 * @var string
	 */
	public $status = 'publish';
	/**
	 * Decoded settings JSON. Empty array if not present.
	 * @var array
	 */
	public $extra_data = [];
	/**
	 * @var int
	 */
	public $author = 0;
	/**
	 * @var string MySQL datetime
	 */
	public $created_at = '';
	/**
	 * @var string MySQL datetime
	 */
	public $updated_at = '';

	/**
	 * @param array|object|null $data
	 */
	public function __construct( $data = null ) {
		if ( $data ) {
			$this->map_to_object( $data );
		}
	}

	/**
	 * Map array/object data to model. Used after fetching from DB.
	 *
	 * @param array|object $data
	 */
	public function map_to_object( $data ): InteractiveModel {
		foreach ( $data as $key => $value ) {
			if ( property_exists( $this, $key ) ) {
				$this->{$key} = $value;
			}
		}

		// extra_data column stores JSON; hydrate to array.
		if ( is_string( $this->extra_data ) && $this->extra_data !== '' ) {
			try {
				$decoded          = \LP_Helper::json_decode( $this->extra_data, true );
				$this->extra_data = is_array( $decoded ) ? $decoded : [];
			} catch ( \Throwable $e ) {
				$this->extra_data = [];
			}
		} elseif ( ! is_array( $this->extra_data ) ) {
			$this->extra_data = [];
		}

		// Cast numeric primary keys.
		$this->ID     = (int) $this->ID;
		$this->author = (int) $this->author;

		return $this;
	}

	/**
	 * Find by ID. Returns model instance or false.
	 *
	 * @return InteractiveModel|false
	 */
	public static function find( int $id ) {
		if ( ! $id ) {
			return false;
		}
		$filter     = new InteractiveFilter();
		$filter->ID = $id;
		return self::get_interactive_model_from_db( $filter );
	}

	/**
	 * Get a single model from DB by filter. Returns false if not found.
	 *
	 * @return InteractiveModel|false
	 */
	public static function get_interactive_model_from_db( InteractiveFilter $filter ) {
		try {
			$total_rows = 0;
			$rows       = InteractiveDB::getInstance()->get_interactives( $filter, $total_rows );
			if ( ! is_array( $rows ) || empty( $rows[0] ) ) {
				return false;
			}
			$row = $rows[0];
			if ( ! ( $row instanceof stdClass ) && ! is_array( $row ) ) {
				return false;
			}
			return new self( $row );
		} catch ( Throwable $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( __METHOD__ . ': ' . $e->getMessage() );
			}
			return false;
		}
	}

	/**
	 * INSERT new row (when ID=0) or UPDATE existing (when ID>0). Returns ID on success, 0 on failure.
	 */
	public function save(): int {
		global $wpdb;
		$table = $wpdb->prefix . 'learnpress_interactive';
		$now   = current_time( 'mysql' );

		$row = [
			'title'      => (string) $this->title,
			'type'       => (string) $this->type,
			'status'     => '' !== (string) $this->status ? (string) $this->status : 'publish',
			'author'     => (int) $this->author,
			'extra_data' => is_array( $this->extra_data )
				? ( empty( $this->extra_data ) ? '{}' : wp_json_encode( $this->extra_data, JSON_UNESCAPED_UNICODE ) )
				: (string) $this->extra_data,
			'updated_at' => $now,
		];

		if ( $this->ID > 0 ) {
			$ok = $wpdb->update( $table, $row, [ 'ID' => $this->ID ] );
			return false !== $ok ? $this->ID : 0;
		}

		$row['created_at'] = $now;
		$ok                = $wpdb->insert( $table, $row );
		if ( $ok ) {
			$this->ID         = (int) $wpdb->insert_id;
			$this->created_at = $now;
			$this->updated_at = $now;
		}
		return $this->ID;
	}

	/**
	 * Soft delete: set status='trash'. Returns true on success.
	 */
	public function soft_delete(): bool {
		if ( ! $this->ID ) {
			return false;
		}
		$this->status = 'trash';
		return (bool) $this->save();
	}

	/**
	 * Hard delete row + cascade items.
	 */
	public function force_delete(): bool {
		global $wpdb;
		if ( ! $this->ID ) {
			return false;
		}
		InteractiveItemModel::delete_by_parent( $this->ID );
		$ok = $wpdb->delete( $wpdb->prefix . 'learnpress_interactive', [ 'ID' => $this->ID ] );
		return false !== $ok;
	}
}
