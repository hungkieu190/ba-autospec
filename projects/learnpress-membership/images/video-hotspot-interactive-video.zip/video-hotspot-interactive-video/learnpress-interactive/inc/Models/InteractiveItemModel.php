<?php

namespace LearnPress\Interactive\Models;

use LearnPress\Interactive\Databases\InteractiveDB;
use LearnPress\Interactive\Filters\InteractiveItemFilter;
use stdClass;
use Throwable;

defined( 'ABSPATH' ) || exit;

/**
 * Class InteractiveItemModel
 *
 * Entity for child table `wp_learnpress_interactive_items`. One instance = one row.
 *
 * @since 1.0.0
 * @version 1.0.0
 */
class InteractiveItemModel {

	/**
	 * Auto increment, Primary key.
	 * @var int
	 */
	public $ID = 0;
	/**
	 * FK to learnpress_interactive.ID.
	 * @var int
	 */
	public $interactive_id = 0;
	/**
	 * Item content (HTML allowed via wp_kses_post).
	 * @var string
	 */
	public $content = '';
	/**
	 * Display order within the parent.
	 * @var int
	 */
	public $sort_order = 0;
	/**
	 * Decoded per-item settings (e.g., front/back for flash card, caption for slide).
	 * @var array
	 */
	public $extra_data = array();

	/**
	 * @param array|object|null $data
	 */
	public function __construct( $data = null ) {
		if ( $data ) {
			$this->map_to_object( $data );
		}
	}

	public function map_to_object( $data ): InteractiveItemModel {
		foreach ( $data as $key => $value ) {
			if ( property_exists( $this, $key ) ) {
				$this->{$key} = $value;
			}
		}

		if ( is_string( $this->extra_data ) && $this->extra_data !== '' ) {
			try {
				$decoded          = \LP_Helper::json_decode( $this->extra_data, true );
				$this->extra_data = is_array( $decoded ) ? $decoded : array();
			} catch ( \Throwable $e ) {
				$this->extra_data = array();
			}
		} elseif ( ! is_array( $this->extra_data ) ) {
			$this->extra_data = array();
		}

		$this->ID             = (int) $this->ID;
		$this->interactive_id = (int) $this->interactive_id;
		$this->sort_order     = (int) $this->sort_order;

		return $this;
	}

	/**
	 * Find by ID. Returns model or false.
	 *
	 * @return InteractiveItemModel|false
	 */
	public static function find( int $id ) {
		if ( ! $id ) {
			return false;
		}
		$filter     = new InteractiveItemFilter();
		$filter->ID = $id;
		return self::get_interactive_item_model_from_db( $filter );
	}

	/**
	 * Get a single model from DB by filter.
	 *
	 * @return InteractiveItemModel|false
	 */
	public static function get_interactive_item_model_from_db( InteractiveItemFilter $filter ) {
		try {
			$total_rows = 0;
			$rows       = InteractiveDB::getInstance()->get_interactive_items( $filter, $total_rows );
			if ( ! is_array( $rows ) || empty( $rows[0] ) ) {
				return false;
			}
			$row = $rows[0];
			if ( ! ( $row instanceof stdClass ) && ! is_array( $row ) ) {
				return false;
			}
			return new self( $row );
		} catch ( Throwable $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( __METHOD__ . ': ' . $e->getMessage() );
			}
			return false;
		}
	}

	/**
	 * Find all items belonging to a parent, ordered by sort_order ASC.
	 *
	 * @return InteractiveItemModel[]
	 */
	public static function find_by_parent( int $interactive_id ): array {
		if ( ! $interactive_id ) {
			return array();
		}
		try {
			$filter                 = new InteractiveItemFilter();
			$filter->interactive_id = $interactive_id;
			$total_rows             = 0;
			$rows                   = InteractiveDB::getInstance()->get_interactive_items( $filter, $total_rows );
			$models                 = array();
			if ( is_array( $rows ) ) {
				foreach ( $rows as $row ) {
					$models[] = new self( $row );
				}
			}
			return $models;
		} catch ( Throwable $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( __METHOD__ . ': ' . $e->getMessage() );
			}
			return array();
		}
	}

	/**
	 * Fetch all items for a set of parents in a single query, grouped by parent ID.
	 *
	 * Used by list shortcodes / endpoints rendering many parents at once to avoid
	 * the N+1 of calling find_by_parent() inside a loop.
	 *
	 * @param int[] $interactive_ids
	 * @return array<int,InteractiveItemModel[]> Map of interactive_id → model list (sort_order ASC).
	 *                                          Parents with no items are present with an empty array.
	 */
	public static function find_by_parent_ids( array $interactive_ids ): array {
		$ids = array_values(
			array_unique(
				array_filter( array_map( 'intval', $interactive_ids ), static fn( $i ) => $i > 0 )
			)
		);
		$out = array();
		foreach ( $ids as $id ) {
			$out[ $id ] = array();
		}
		if ( empty( $ids ) ) {
			return $out;
		}

		global $wpdb;
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$table        = $wpdb->prefix . 'learnpress_interactive_items';
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $placeholders is %d-only.
		$sql  = $wpdb->prepare(
			"SELECT * FROM $table WHERE interactive_id IN ($placeholders) ORDER BY interactive_id ASC, sort_order ASC",
			$ids
		);
		$rows = $wpdb->get_results( $sql );
		if ( ! is_array( $rows ) ) {
			return $out;
		}
		foreach ( $rows as $row ) {
			$pid = (int) ( is_object( $row ) ? ( $row->interactive_id ?? 0 ) : ( $row['interactive_id'] ?? 0 ) );
			if ( ! isset( $out[ $pid ] ) ) {
				$out[ $pid ] = array();
			}
			$out[ $pid ][] = new self( $row );
		}
		return $out;
	}

	/**
	 * Count items grouped by parent for a batch of interactive IDs.
	 *
	 * Avoids the N+1 of running `find_by_parent()` once per row in list endpoints.
	 *
	 * @param int[] $interactive_ids
	 * @return array<int,int> Map of interactive_id → item count. Parents with zero
	 *                        items are present with value 0.
	 */
	public static function count_by_parent_ids( array $interactive_ids ): array {
		$ids = array_values(
			array_unique(
				array_filter( array_map( 'intval', $interactive_ids ), static fn( $i ) => $i > 0 )
			)
		);
		$out = array();
		foreach ( $ids as $id ) {
			$out[ $id ] = 0;
		}
		if ( empty( $ids ) ) {
			return $out;
		}

		global $wpdb;
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$table        = $wpdb->prefix . 'learnpress_interactive_items';
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $placeholders is %d-only.
		$sql  = $wpdb->prepare(
			"SELECT interactive_id, COUNT(*) AS cnt FROM $table WHERE interactive_id IN ($placeholders) GROUP BY interactive_id",
			$ids
		);
		$rows = $wpdb->get_results( $sql );
		if ( ! is_array( $rows ) ) {
			return $out;
		}
		foreach ( $rows as $row ) {
			$row_arr                             = is_object( $row ) ? get_object_vars( $row ) : (array) $row;
			$out[ (int) $row_arr['interactive_id'] ] = (int) $row_arr['cnt'];
		}
		return $out;
	}

	/**
	 * INSERT new row (ID=0) or UPDATE existing. Returns ID on success.
	 */
	public function save(): int {
		global $wpdb;
		$table = $wpdb->prefix . 'learnpress_interactive_items';

		$row = [
			'interactive_id' => (int) $this->interactive_id,
			'content'        => (string) $this->content,
			'sort_order'     => (int) $this->sort_order,
			'extra_data'     => is_array( $this->extra_data )
				? wp_json_encode( $this->extra_data, JSON_UNESCAPED_UNICODE )
				: (string) $this->extra_data,
		];

		if ( $this->ID > 0 ) {
			$ok = $wpdb->update( $table, $row, [ 'ID' => $this->ID ] );
			return false !== $ok ? $this->ID : 0;
		}

		$ok = $wpdb->insert( $table, $row );
		if ( $ok ) {
			$this->ID = (int) $wpdb->insert_id;
		}
		return $this->ID;
	}

	/**
	 * Replace ALL items of a parent atomically. Each $items entry is a plain array
	 * with content + extra_data; sort_order auto-set by array index.
	 *
	 * @param array<int,array> $items
	 */
	public static function bulk_replace( int $interactive_id, array $items ): bool {
		global $wpdb;
		if ( ! $interactive_id ) {
			return false;
		}

		$wpdb->query( 'START TRANSACTION' );
		try {
			self::delete_by_parent( $interactive_id );
			foreach ( array_values( $items ) as $idx => $item ) {
				if ( ! is_array( $item ) ) {
					continue;
				}
				$model                 = new self();
				$model->interactive_id = $interactive_id;
				$model->content        = $item['content'] ?? '';
				$model->sort_order     = $idx;

				$raw_extra = $item['extra_data'] ?? null;
				if ( null !== $raw_extra && ! is_array( $raw_extra ) ) {
					if ( function_exists( '_doing_it_wrong' ) ) {
						_doing_it_wrong(
							__METHOD__,
							esc_html( sprintf(
								'Item extra_data must be an array; got %s. The row will be saved with empty extra_data — fix the type\'s sanitize_item() to return an array.',
								gettype( $raw_extra )
							) ),
							'1.0.0'
						);
					}
				}
				$model->extra_data = is_array( $raw_extra ) ? $raw_extra : array();

				if ( ! $model->save() ) {
					throw new \RuntimeException( 'Insert item failed' );
				}
			}
			$wpdb->query( 'COMMIT' );
			return true;
		} catch ( Throwable $e ) {
			$wpdb->query( 'ROLLBACK' );
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( __METHOD__ . ': ' . $e->getMessage() );
			}
			return false;
		}
	}

	/**
	 * Delete all items of a parent. Returns deleted row count.
	 */
	public static function delete_by_parent( int $interactive_id ): int {
		global $wpdb;
		if ( ! $interactive_id ) {
			return 0;
		}
		return (int) $wpdb->delete(
			$wpdb->prefix . 'learnpress_interactive_items',
			[ 'interactive_id' => $interactive_id ]
		);
	}

	/**
	 * Hard delete this item.
	 */
	public function delete(): bool {
		global $wpdb;
		if ( ! $this->ID ) {
			return false;
		}
		$ok = $wpdb->delete(
			$wpdb->prefix . 'learnpress_interactive_items',
			[ 'ID' => $this->ID ]
		);
		return false !== $ok;
	}
}
