<?php

namespace LearnPress\Interactive\Types;

defined( 'ABSPATH' ) || exit;

/**
 * Static registry mapping type key (string) → TypeInterface instance.
 *
 * Populated once via {@see boot()} during plugin bootstrap; queried by
 * Service/AJAX/Shortcode layers to dispatch to the correct strategy.
 *
 * 3rd-party can hook 'learnpress/interactive/register-types' to add new types.
 */
final class TypeRegistry {

	/** @var TypeInterface[] keyed by type->key() */
	private static array $types = array();

	/** @var bool guards boot() against duplicate runs in same request */
	private static bool $booted = false;

	/**
	 * Register the built-in types and fire a hook for extensions.
	 * Idempotent — safe to call multiple times in the same request.
	 */
	public static function boot(): void {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		self::register( new FlashCardType() );
		self::register( new SlideType() );

		do_action( 'learnpress/interactive/register-types' );
	}

	public static function register( TypeInterface $type ): void {
		self::$types[ $type->key() ] = $type;
	}

	public static function get( string $key ): ?TypeInterface {
		return self::$types[ $key ] ?? null;
	}

	/** @return TypeInterface[] */
	public static function all(): array {
		return self::$types;
	}

	/**
	 * Reset registry — used by unit tests to ensure isolation.
	 */
	public static function reset_for_tests(): void {
		self::$types  = array();
		self::$booted = false;
	}
}
