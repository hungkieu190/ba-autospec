<?php

namespace LearnPress\Interactive\Types;

defined( 'ABSPATH' ) || exit;

final class SlideType extends AbstractType {

	private const DEFAULT_WIDTH  = 842;
	private const DEFAULT_HEIGHT = 595;
	private const DEFAULT_TITLE  = 'Untitled deck';

	public function key(): string {
		return 'slide';
	}

	public function label(): string {
		return __( 'Slide', 'learnpress-interactive' );
	}

	public function default_settings(): array {
		return array();
	}

	public function default_title(): string {
		return self::DEFAULT_TITLE;
	}

	public function sanitize_settings( array $raw ): array {
		unset( $raw );
		return array();
	}

	public function default_items(): array {
		return array( $this->sanitize_item( array() ) );
	}

	public function sanitize_item( array $raw ): array {
		$extra_data = is_array( $raw['extra_data'] ?? null ) ? $raw['extra_data'] : array();
		$dimensions = $this->sanitize_dimensions( $raw, $extra_data );

		return array(
			'content'    => $this->sanitize_fabric_content( $raw['content'] ?? ( $raw['fabric_json'] ?? array() ) ),
			'extra_data' => array(
				'width'  => $dimensions['width'],
				'height' => $dimensions['height'],
			),
		);
	}

	public function render( array $entity, array $items ): string {
		unset( $entity );

		$count = count( $items );
		$text  = sprintf(
			_n( 'Slide deck (%d slide)', 'Slide deck (%d slides)', $count, 'learnpress-interactive' ),
			$count
		);

		return '<div class="lp-interactive-slide-deck-placeholder">' . esc_html( $text ) . '</div>';
	}

	public function frontend_handles(): array {
		return array();
	}

	private function sanitize_dimensions( array $raw, array $extra_data ): array {
		$width = $raw['width']
			?? $extra_data['width']
			?? $raw['canvas_width']
			?? $extra_data['canvas_width']
			?? self::DEFAULT_WIDTH;

		$height = $raw['height']
			?? $extra_data['height']
			?? $raw['canvas_height']
			?? $extra_data['canvas_height']
			?? self::DEFAULT_HEIGHT;

		return array(
			'width'  => max( 320, min( 1920, (int) $width ) ),
			'height' => max( 180, min( 1080, (int) $height ) ),
		);
	}

	private function sanitize_fabric_content( $raw ): string {
		if ( is_string( $raw ) ) {
			$decoded = json_decode( $raw, true );
			$raw     = is_array( $decoded ) ? $decoded : array();
		}

		$raw = is_array( $raw ) ? $raw : array();

		$clean = array(
			'version' => sanitize_text_field( (string) ( $raw['version'] ?? '' ) ),
			'objects' => array(),
		);

		$objects = is_array( $raw['objects'] ?? null ) ? $raw['objects'] : array();
		foreach ( $objects as $fabric_object ) {
			if ( ! is_array( $fabric_object ) ) {
				continue;
			}

			$clean['objects'][] = $this->sanitize_fabric_object( $fabric_object );
		}

		$json = wp_json_encode( $clean, JSON_UNESCAPED_UNICODE );

		return is_string( $json ) ? $json : '{"version":"","objects":[]}';
	}

	private function sanitize_fabric_object( array $fabric_object ): array {
		$clean = array();
		foreach ( $fabric_object as $key => $value ) {
			$key = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $key );
			if ( '' === $key ) {
				continue;
			}

			$clean[ $key ] = $this->sanitize_fabric_value( $value );
		}

		return $clean;
	}

	private function sanitize_fabric_value( $value ) {
		if ( null === $value ) {
			return null;
		}

		if ( is_numeric( $value ) ) {
			return 0 + $value;
		}

		if ( is_bool( $value ) ) {
			return $value;
		}

		if ( is_array( $value ) ) {
			return $this->sanitize_fabric_object( $value );
		}

		if ( is_string( $value ) ) {
			return wp_kses( $value, array() );
		}

		return '';
	}
}
