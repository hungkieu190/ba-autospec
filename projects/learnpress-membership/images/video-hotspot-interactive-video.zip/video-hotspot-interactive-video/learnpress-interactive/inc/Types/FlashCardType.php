<?php

namespace LearnPress\Interactive\Types;

use LearnPress\Helpers\Template;

defined( 'ABSPATH' ) || exit;

/**
 * FlashCard interactive type.
 *
 * Deck (entity): `extra_data` stores deck-level settings (layout / progress /
 * shuffle / require_flip). `content` is unused.
 *
 * Card (item): `content` stores both sides as JSON:
 * `{front:{title,image_id,subtitle}, back:{title,image_id,subtitle}}`.
 * Title and subtitle are plain text. `extra_data` is intentionally empty for
 * flash card items.
 */
final class FlashCardType extends AbstractType {

	public function key(): string {
		return 'flash_card';
	}

	public function label(): string {
		return __( 'Flash Card', 'learnpress-interactive' );
	}

	public function default_settings(): array {
		return array(
			'layout'           => 'slider',
			'show_progress'    => true,
			'shuffle'          => false,
			'require_flip'     => true,
			'text_color'       => '#111827',
			'background_color' => '#ffffff',
		);
	}

	public function sanitize_settings( array $raw ): array {
		$defaults = $this->default_settings();

		$layout = isset( $raw['layout'] ) ? (string) $raw['layout'] : $defaults['layout'];
		if ( ! in_array( $layout, array( 'slider', 'grid' ), true ) ) {
			$layout = $defaults['layout'];
		}

		$pick_bool = static function ( array $raw, string $key, bool $default ): bool {
			return array_key_exists( $key, $raw ) ? ! empty( $raw[ $key ] ) : $default;
		};

		return array(
			'layout'           => $layout,
			'show_progress'    => $pick_bool( $raw, 'show_progress', $defaults['show_progress'] ),
			'shuffle'          => $pick_bool( $raw, 'shuffle',       $defaults['shuffle'] ),
			'require_flip'     => $pick_bool( $raw, 'require_flip',  $defaults['require_flip'] ),
			'text_color'       => $this->sanitize_hex_color_setting( $raw['text_color'] ?? '', $defaults['text_color'] ),
			'background_color' => $this->sanitize_hex_color_setting( $raw['background_color'] ?? '', $defaults['background_color'] ),
		);
	}

	/**
	 * Sanitize a card item for DB storage. The text column stores the full
	 * front/back card payload because it is the item source of truth; item
	 * extra_data remains empty.
	 */
	public function sanitize_item( array $raw ): array {
		$canonical = $this->extract_card_shape( $raw );

		$content_payload = array(
			'front' => array(
				'title'    => $canonical['front']['title'],
				'image_id' => $canonical['front']['image_id'],
				'subtitle' => $canonical['front']['subtitle'],
			),
			'back'  => array(
				'title'    => $canonical['back']['title'],
				'image_id' => $canonical['back']['image_id'],
				'subtitle' => $canonical['back']['subtitle'],
			),
		);

		$flags           = JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP;
		$content_encoded = wp_json_encode( $content_payload, $flags );

		return array(
			'content'    => is_string( $content_encoded ) ? $content_encoded : '',
			'extra_data' => array(),
		);
	}

	/**
	 * Decode a stored item row into the unified card shape.
	 *
	 * @param array $item Item row with `content` (JSON string) + `extra_data`
	 *                    (JSON string or already-decoded array).
	 */
	public static function decode_card( array $item ): array {
		$content = self::decode_json_array( $item['content'] ?? '' );

		return array(
			'front' => self::read_side( $content['front'] ?? array() ),
			'back'  => self::read_side( $content['back']  ?? array() ),
		);
	}

	/**
	 * Attach the resolved attachment URL for each side's `image_id` so the
	 * client side can render the thumbnail without re-querying.
	 *
	 * Accepts the canonical card shape returned by `decode_card()` and returns
	 * the same shape with `image_url` populated per side.
	 *
	 * Single source of truth — admin builder bootstrap and AJAX get/enrich
	 * paths both delegate here.
	 */
	public static function enrich_card_urls( array $card ): array {
		foreach ( array( 'front', 'back' ) as $side ) {
			$image_id = (int) ( $card[ $side ]['image_id'] ?? 0 );
			$card[ $side ]['image_url'] = self::attachment_url( $image_id );
		}
		return $card;
	}

	private static function decode_json_array( $raw ): array {
		if ( is_array( $raw ) ) {
			return $raw;
		}
		if ( is_string( $raw ) && '' !== $raw ) {
			$decoded = json_decode( $raw, true );
			if ( is_array( $decoded ) ) {
				return $decoded;
			}
		}
		return array();
	}

	private static function read_side( $content_raw ): array {
		$content = is_array( $content_raw ) ? $content_raw : array();

		return array(
			'title'    => is_string( $content['title'] ?? null ) ? $content['title'] : '',
			'image_id' => (int) ( $content['image_id'] ?? 0 ),
			'subtitle' => is_string( $content['subtitle'] ?? null ) ? $content['subtitle'] : '',
		);
	}

	/**
	 * Normalize input shape to the canonical card structure.
	 *
	 * Sanitizes title/subtitle as plain text and image IDs via `absint()`.
	 * Expects the canonical nested shape:
	 *   `[ 'front' => [ 'title' => ..., 'image_id' => ..., 'subtitle' => ... ], 'back' => [...] ]`
	 *
	 * Callers that hold a stored DB row (`content` as JSON string) must run it
	 * through `decode_card()` first — see `InteractiveService::duplicate()`.
	 */
	private function extract_card_shape( array $raw ): array {
		$front = is_array( $raw['front'] ?? null ) ? $raw['front'] : array();
		$back  = is_array( $raw['back']  ?? null ) ? $raw['back']  : array();

		return array(
			'front' => $this->extract_side_shape( $front ),
			'back'  => $this->extract_side_shape( $back ),
		);
	}

	private function extract_side_shape( array $side ): array {
		return array(
			'title'    => $this->sanitize_plain_text( (string) ( $side['title'] ?? '' ) ),
			'image_id' => absint( $side['image_id'] ?? 0 ),
			'subtitle' => $this->sanitize_plain_text( (string) ( $side['subtitle'] ?? '' ) ),
		);
	}

	private function sanitize_plain_text( string $value ): string {
		return sanitize_text_field( $value );
	}

	private function sanitize_hex_color_setting( $value, string $fallback ): string {
		$color = is_string( $value ) ? trim( $value ) : '';
		return preg_match( '/^#[0-9a-fA-F]{6}$/', $color ) ? strtolower( $color ) : $fallback;
	}

	public function render( array $entity, array $items ): string {
		$title         = (string) ( $entity['title'] ?? '' );
		$total         = count( $items );
		$settings      = is_array( $entity['extra_data'] ?? null ) && ! empty( $entity['extra_data'] )
			? $this->sanitize_settings( $entity['extra_data'] )
			: $this->default_settings();
		$layout        = $settings['layout'];
		$show_progress = $settings['show_progress'];
		$shuffle       = $settings['shuffle'];
		$require_flip  = $settings['require_flip'];
		$text_color    = $settings['text_color'];
		$background_color = $settings['background_color'];

		$deck = array();
		foreach ( $items as $item ) {
			$card = self::decode_card( $item );

			$deck[] = array(
				'front' => array(
					'title'    => $card['front']['title'],
					'image_url' => self::attachment_url( $card['front']['image_id'] ),
					'subtitle' => $card['front']['subtitle'],
				),
				'back'  => array(
					'title'    => $card['back']['title'],
					'image_url' => self::attachment_url( $card['back']['image_id'] ),
					'subtitle' => $card['back']['subtitle'],
				),
			);
		}

		$json = (string) wp_json_encode( $deck, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP );

		$sections = apply_filters(
			'learn-press-interactive/flash-card/render/sections',
			array(
				'wrapper_open'  => $this->wrapper_open_html( array(
					'total'            => $total,
					'layout'           => $layout,
					'show_progress'    => $show_progress,
					'shuffle'          => $shuffle,
					'require_flip'     => $require_flip,
					'text_color'       => $text_color,
					'background_color' => $background_color,
				) ),
				'header'        => $this->header_html( $title, $total ),
				'progress'      => $this->progress_html( $total ),
				'card_area'     => $this->card_area_html(),
				'done_screen'   => $this->done_screen_html( $total ),
				'data_script'   => $this->data_script_html( $json ),
				'wrapper_close' => '</div>',
			),
			$entity,
			$items
		);

		if ( class_exists( '\LearnPress\Helpers\Template' ) ) {
			return Template::combine_components( $sections );
		}

		return implode( '', array_filter( $sections, 'is_string' ) );
	}

	private static function attachment_url( int $id ): string {
		if ( $id <= 0 || ! function_exists( 'wp_get_attachment_image_url' ) ) {
			return '';
		}
		return (string) wp_get_attachment_image_url( $id, 'medium' );
	}

	private function wrapper_open_html( array $args ): string {
		return sprintf(
			'<div class="lp-interactive-flash-cards" data-total="%s" data-layout="%s" data-show-progress="%s" data-shuffle="%s" data-require-flip="%s" style="%s">',
			esc_attr( (string) $args['total'] ),
			esc_attr( (string) $args['layout'] ),
			$args['show_progress'] ? '1' : '0',
			$args['shuffle'] ? '1' : '0',
			$args['require_flip'] ? '1' : '0',
			esc_attr(
				'--lp-interactive-fc-text-color:' . $args['text_color'] . ';'
				. '--lp-interactive-fc-background-color:' . $args['background_color'] . ';'
			)
		);
	}

	private function progress_html( int $total ): string {
		return sprintf(
			'<div class="lp-interactive-flash-cards__progress-wrap">'
				. '<div class="lp-interactive-flash-cards__progress-track">'
					. '<div class="lp-interactive-flash-cards__progress-fill" style="width:0%%;"></div>'
				. '</div>'
				. '<div class="lp-interactive-flash-cards__progress-label">%s</div>'
			. '</div>',
			esc_html( sprintf( __( '0 / %d completed', 'learnpress-interactive' ), $total ) )
		);
	}

	private function header_html( string $title, int $total ): string {
		$meta = $total > 0
			? esc_html( sprintf( __( 'Card 1 of %d', 'learnpress-interactive' ), $total ) )
			: '';

		return sprintf(
			'<div class="lp-interactive-flash-cards__header">'
				. '<div class="lp-interactive-flash-cards__title">'
					. '<span class="lp-interactive-flash-cards__icon" aria-hidden="true">&#x1F5C2;</span>'
					. '%s'
				. '</div>'
				. '<div class="lp-interactive-flash-cards__meta">%s</div>'
			. '</div>',
			esc_html( $title ),
			$meta
		);
	}

	private function card_area_html(): string {
		$hint        = esc_html__( 'Click the card to flip', 'learnpress-interactive' );
		$prev_label  = esc_html__( 'Prev', 'learnpress-interactive' );
		$next_label  = esc_html__( 'Next', 'learnpress-interactive' );

		return '<div class="lp-interactive-flash-cards__card-area">'
			. '<div class="lp-interactive-flash-cards__scene">'
				. '<div class="lp-interactive-flash-card" data-flip="0" role="button" tabindex="0" aria-pressed="false">'
					. '<div class="lp-interactive-flash-card__face lp-interactive-flash-card__front" data-side="front">'
						. '<div class="lp-interactive-flash-card__side-label" style="display:none;"></div>'
						. '<div class="lp-interactive-flash-card__title-content lp-interactive-flash-card__text"></div>'
						. '<div class="lp-interactive-flash-card__image-wrap"></div>'
						. '<div class="lp-interactive-flash-card__subtitle"></div>'
					. '</div>'
					. '<div class="lp-interactive-flash-card__face lp-interactive-flash-card__back" data-side="back">'
						. '<div class="lp-interactive-flash-card__side-label" style="display:none;"></div>'
						. '<div class="lp-interactive-flash-card__title-content lp-interactive-flash-card__text"></div>'
						. '<div class="lp-interactive-flash-card__image-wrap"></div>'
						. '<div class="lp-interactive-flash-card__subtitle"></div>'
					. '</div>'
				. '</div>'
			. '</div>'
			. '<div class="lp-interactive-flash-cards__hint">'
				. '<span aria-hidden="true">&#x21BB;</span> ' . $hint
			. '</div>'
			. '<div class="lp-interactive-flash-cards__nav">'
				. '<button type="button" class="lp-interactive-flash-cards__prev" disabled>&larr; ' . $prev_label . '</button>'
				. '<button type="button" class="lp-interactive-flash-cards__next">' . $next_label . ' &rarr;</button>'
			. '</div>'
		. '</div>';
	}

	private function done_screen_html( int $total ): string {
		return sprintf(
			'<div class="lp-interactive-flash-cards__done">'
				. '<div class="lp-interactive-flash-cards__done-emoji" aria-hidden="true"></div>'
				. '<div class="lp-interactive-flash-cards__done-title">%s</div>'
				. '<div class="lp-interactive-flash-cards__done-sub">%s</div>'
				. '<div class="lp-interactive-flash-cards__done-actions">'
					. '<button type="button" class="lp-interactive-flash-cards__restart">&#x21BA; %s</button>'
				. '</div>'
			. '</div>',
			esc_html__( 'Deck Complete!', 'learnpress-interactive' ),
			esc_html( sprintf( __( "You've studied all %d cards in this deck.", 'learnpress-interactive' ), $total ) ),
			esc_html__( 'Study Again', 'learnpress-interactive' )
		);
	}

	private function data_script_html( string $json ): string {
		return '<script type="application/json" class="lp-interactive-flash-cards__data">' . $json . '</script>';
	}

	public function frontend_handles(): array {
		return array( 'lp-interactive-flash-card' );
	}
}
