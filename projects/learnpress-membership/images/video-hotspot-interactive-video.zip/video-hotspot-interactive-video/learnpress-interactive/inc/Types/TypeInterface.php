<?php

namespace LearnPress\Interactive\Types;

defined( 'ABSPATH' ) || exit;

/**
 * Contract for an interactive content type (flash_card, slide…).
 *
 * Each implementation owns:
 *  - identity ({@see key} / {@see label})
 *  - parent-level settings shape ({@see default_settings} / {@see sanitize_settings})
 *  - per-item shape ({@see sanitize_item})
 *  - frontend rendering ({@see render} / {@see frontend_handles})
 *
 * @since 1.0.0
 */
interface TypeInterface {

	/**
	 * Stable identifier stored in `learnpress_interactive.type` column.
	 * Must match `[a-z_]+` (e.g. 'flash_card', 'slide').
	 */
	public function key(): string;

	/**
	 * Human-readable label for admin UI (i18n via __()).
	 */
	public function label(): string;

	/**
	 * Default settings array used when creating a new entity.
	 */
	public function default_settings(): array;

	/**
	 * Whitelist + cast user-submitted parent settings.
	 * Drops unknown keys; returns array safe for JSON encoding.
	 */
	public function sanitize_settings( array $raw ): array;

	/**
	 * Whitelist + cast a single item's payload.
	 * Returns ['content' => string, 'extra_data' => array].
	 */
	public function sanitize_item( array $raw ): array;

	/**
	 * Render frontend HTML for the published entity.
	 *
	 * @param array $entity Hydrated row from `learnpress_interactive`
	 * @param array $items  Hydrated rows from `learnpress_interactive_items`
	 */
	public function render( array $entity, array $items ): string;

	/**
	 * Asset handles to enqueue when this type renders.
	 * Empty array = no frontend JS/CSS needed.
	 *
	 * @return string[]
	 */
	public function frontend_handles(): array;
}
