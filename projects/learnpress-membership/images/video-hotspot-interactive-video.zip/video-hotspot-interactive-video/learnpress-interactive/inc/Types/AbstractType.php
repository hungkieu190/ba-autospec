<?php

namespace LearnPress\Interactive\Types;

defined( 'ABSPATH' ) || exit;

/**
 * Default implementations for optional type methods.
 * Concrete types must still provide key(), label(), sanitize_item(), render().
 */
abstract class AbstractType implements TypeInterface {

	public function default_settings(): array {
		return array();
	}

	public function sanitize_settings( array $raw ): array {
		return array();
	}

	public function default_items(): array {
		return array();
	}

	public function frontend_handles(): array {
		return array();
	}
}
