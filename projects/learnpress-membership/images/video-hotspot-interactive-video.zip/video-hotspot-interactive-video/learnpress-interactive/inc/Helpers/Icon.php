<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Helpers;

defined( 'ABSPATH' ) || exit;

class Icon {

	private static $cache = array();

	public static function render( string $name, array $attrs = array() ): string {
		$name = trim( $name );
		if ( '' === $name ) {
			return '';
		}

		$svg = self::load( 'ico-' . $name . '.svg' );
		if ( '' === $svg ) {
			return '';
		}

		return self::merge_attrs( $svg, $attrs );
	}

	private static function load( string $filename ): string {
		if ( isset( self::$cache[ $filename ] ) ) {
			return self::$cache[ $filename ];
		}

		if ( ! defined( 'LP_ADDON_INTERACTIVE_FILE' ) ) {
			self::$cache[ $filename ] = '';
			return '';
		}

		$path = plugin_dir_path( LP_ADDON_INTERACTIVE_FILE ) . 'assets/images/svg/' . $filename;
		if ( ! is_readable( $path ) ) {
			self::$cache[ $filename ] = '';
			return '';
		}

		$svg = (string) file_get_contents( $path );
		$svg = preg_replace( '/^\s*<\?xml[^?]*\?>\s*/', '', $svg );

		self::$cache[ $filename ] = trim( (string) $svg );
		return self::$cache[ $filename ];
	}

	private static function merge_attrs( string $svg, array $attrs ): string {
		if ( empty( $attrs ) ) {
			return $svg;
		}

		return (string) preg_replace_callback(
			'/^(<svg\b)([^>]*)(>)/i',
			static function ( array $matches ) use ( $attrs ): string {
				$inner = $matches[2];

				foreach ( $attrs as $attr_name => $attr_value ) {
					$attr_name  = (string) $attr_name;
					$attr_value = (string) $attr_value;
					if ( '' === $attr_name ) {
						continue;
					}

					if ( 'class' === $attr_name && preg_match( '/\bclass\s*=\s*"([^"]*)"/', $inner, $m ) ) {
						$merged = trim( $m[1] . ' ' . $attr_value );
						$inner  = (string) preg_replace(
							'/\bclass\s*=\s*"[^"]*"/',
							sprintf( 'class="%s"', esc_attr( $merged ) ),
							$inner,
							1
						);
						continue;
					}

					$pattern     = '/\b' . preg_quote( $attr_name, '/' ) . '\s*=\s*"[^"]*"/';
					$replacement = sprintf( '%s="%s"', $attr_name, esc_attr( $attr_value ) );

					if ( preg_match( $pattern, $inner ) ) {
						$inner = (string) preg_replace( $pattern, $replacement, $inner, 1 );
					} else {
						$inner = $inner . ' ' . $replacement;
					}
				}

				return $matches[1] . $inner . $matches[3];
			},
			$svg,
			1
		);
	}

	public static function reset_cache(): void {
		self::$cache = array();
	}
}
