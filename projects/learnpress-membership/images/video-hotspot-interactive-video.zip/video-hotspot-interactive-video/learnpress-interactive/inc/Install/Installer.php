<?php
/**
 * Install + upgrade for learnpress-interactive custom tables.
 *
 * @package LearnPress\Interactive\Install
 */

namespace LearnPress\Interactive\Install;

defined( 'ABSPATH' ) || exit;

final class Installer {
	public const DB_VERSION     = '1.0.0';
	public const OPT_DB_VERSION = 'lp_addon_interactive_db_version';

	/**
	 * Run on plugin activation. Creates tables + stores version.
	 */
	public static function activate(): void {
		self::create_tables();
		update_option( self::OPT_DB_VERSION, self::DB_VERSION );
	}

	private static function create_tables(): void {
		global $wpdb;
		if ( ! function_exists( 'dbDelta' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		}

		$charset_collate = $wpdb->get_charset_collate();

		dbDelta( self::sql_parent_table( $charset_collate ) );
		dbDelta( self::sql_items_table( $charset_collate ) );
	}

	private static function sql_parent_table( string $charset_collate ): string {
		global $wpdb;

		return "CREATE TABLE {$wpdb->prefix}learnpress_interactive (
			ID bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			title varchar(255) NOT NULL DEFAULT '',
			type varchar(32) NOT NULL DEFAULT 'flash_card',
			status varchar(20) NOT NULL DEFAULT 'publish',
			extra_data longtext NULL,
			author bigint(20) UNSIGNED NOT NULL DEFAULT 0,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY  (ID),
			KEY title_idx (title(191)),
			KEY type_idx (type),
			KEY status_idx (status),
			KEY author_idx (author),
			KEY created_idx (created_at)
		) {$charset_collate};";
	}

	private static function sql_items_table( string $charset_collate ): string {
		global $wpdb;

		return "CREATE TABLE {$wpdb->prefix}learnpress_interactive_items (
			ID bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			interactive_id bigint(20) UNSIGNED NOT NULL,
			content longtext NULL,
			sort_order int(11) NOT NULL DEFAULT 0,
			extra_data longtext NULL,
			PRIMARY KEY  (ID),
			KEY interactive_sort_idx (interactive_id, sort_order)
		) {$charset_collate};";
	}
}
