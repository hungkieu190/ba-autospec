<?php

namespace LearnPress\Interactive\Databases;

use Exception;
use LearnPress\Databases\DataBase;
use LearnPress\Interactive\Filters\InteractiveFilter;
use LearnPress\Interactive\Filters\InteractiveItemFilter;

defined( 'ABSPATH' ) || exit;

/**
 * Class InteractiveDB
 *
 * Query layer for the 2 custom tables: learnpress_interactive (parent)
 * and learnpress_interactive_items (children).
 *
 * @since 4.0.0
 * @version 1.0.0
 */
class InteractiveDB extends DataBase {
	private static $_instance;

	protected function __construct() {
		parent::__construct();
	}

	public static function getInstance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Query parent table.
	 *
	 * @param InteractiveFilter $filter
	 * @param int $total_rows return total_rows
	 *
	 * @return array|int|string|null
	 * @throws Exception
	 */
	public function get_interactives( InteractiveFilter $filter, int &$total_rows = 0 ) {
		$filter->fields = array_merge( $filter->all_fields, $filter->fields );

		$ca = $filter->collection_alias;

		// Find ID
		if ( ! empty( $filter->ID ) ) {
			$filter->where[] = $this->wpdb->prepare( "AND $ca.ID = %d", $filter->ID );
		}

		// Title (LIKE search)
		if ( ! empty( $filter->title ) ) {
			$like            = '%' . $this->wpdb->esc_like( $filter->title ) . '%';
			$filter->where[] = $this->wpdb->prepare( "AND $ca.title LIKE %s", $like );
		}

		// Type
		if ( ! empty( $filter->type ) ) {
			$filter->where[] = $this->wpdb->prepare( "AND $ca.type = %s", $filter->type );
		}

		// Status
		if ( ! empty( $filter->status ) ) {
			$filter->where[] = $this->wpdb->prepare( "AND $ca.status = %s", $filter->status );
		} elseif ( ! empty( $filter->status_in ) && is_array( $filter->status_in ) ) {
			// Safe: placeholders are fixed `%s` literals; values still go through prepare().
			// phpcs:disable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$placeholders    = implode( ',', array_fill( 0, count( $filter->status_in ), '%s' ) );
			$filter->where[] = $this->wpdb->prepare( "AND $ca.status IN ($placeholders)", $filter->status_in );
			// phpcs:enable
		}

		// Author
		if ( ! empty( $filter->author ) ) {
			$filter->where[] = $this->wpdb->prepare( "AND $ca.author = %d", $filter->author );
		}

		$filter = apply_filters( 'lp/interactive/query/filter', $filter );

		return $this->execute( $filter, $total_rows );
	}

	/**
	 * Query interactive items table.
	 *
	 * @param InteractiveItemFilter $filter
	 * @param int $total_rows
	 *
	 * @return array|int|string|null
	 * @throws Exception
	 */
	public function get_interactive_items( InteractiveItemFilter $filter, int &$total_rows = 0 ) {
		$filter->fields = array_merge( $filter->all_fields, $filter->fields );

		$ca = $filter->collection_alias;

		if ( ! empty( $filter->ID ) ) {
			$filter->where[] = $this->wpdb->prepare( "AND $ca.ID = %d", $filter->ID );
		}

		if ( ! empty( $filter->interactive_id ) ) {
			$filter->where[] = $this->wpdb->prepare( "AND $ca.interactive_id = %d", $filter->interactive_id );
		}

		$filter = apply_filters( 'lp/interactive/query/items/filter', $filter );

		return $this->execute( $filter, $total_rows );
	}
}
