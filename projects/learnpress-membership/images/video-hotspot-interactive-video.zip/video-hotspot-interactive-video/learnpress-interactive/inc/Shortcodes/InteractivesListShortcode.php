<?php

namespace LearnPress\Interactive\Shortcodes;

use LearnPress\Helpers\Singleton;
use LearnPress\Interactive\Assets\AssetRegistrar;
use LearnPress\Interactive\Databases\InteractiveDB;
use LearnPress\Interactive\Filters\InteractiveFilter;
use LearnPress\Interactive\Models\InteractiveItemModel;
use LearnPress\Interactive\Models\InteractiveModel;
use LearnPress\Interactive\Types\TypeRegistry;
use LearnPress\Shortcodes\AbstractShortcode;
use Throwable;

defined( 'ABSPATH' ) || exit;

// Parse-time guard: PHP loads the file before runtime checks fire, so the
// `extends AbstractShortcode` declaration would fatal on LP Core versions that
// predate the abstract. Bail before declaring the class.
if ( ! class_exists( '\LearnPress\Shortcodes\AbstractShortcode' ) ) {
	return;
}

class InteractivesListShortcode extends AbstractShortcode {
	use Singleton;

	protected $prefix         = '';
	protected $shortcode_name = 'learnpress_interactives';

	private const MAX_LIMIT       = 50;
	private const ALLOWED_ORDERBY = array( 'title', 'type', 'created_at', 'updated_at' );

	public function init() {
		parent::init();
	}

	/**
	 * @param array|string $attrs
	 */
	public function render( $attrs ): string {
		try {
			$attrs  = is_array( $attrs ) ? $attrs : array();
			$filter = $this->build_filter( $attrs );

			$total = 0;
			$rows  = InteractiveDB::getInstance()->get_interactives( $filter, $total );
			if ( ! is_array( $rows ) || empty( $rows ) ) {
				return '';
			}

			// Pre-collect parent IDs so we can batch-load their items in one query
			// instead of running find_by_parent() per row.
			$parent_ids = array();
			foreach ( $rows as $row ) {
				$parent_ids[] = (int) ( is_object( $row ) ? ( $row->ID ?? 0 ) : ( $row['ID'] ?? 0 ) );
			}
			$items_by_parent = InteractiveItemModel::find_by_parent_ids( $parent_ids );

			$pieces = array();
			foreach ( $rows as $row ) {
				$parent = new InteractiveModel( $row );
				$id     = (int) $parent->ID;
				$type_k = (string) $parent->type;
				if ( ! $id || '' === $type_k ) {
					continue;
				}

				$type = TypeRegistry::get( $type_k );
				if ( ! $type ) {
					continue;
				}

				$item_models = $items_by_parent[ $id ] ?? array();
				$items       = array_map(
					static fn( InteractiveItemModel $m ) => array(
						'content'    => $m->content,
						'extra_data' => $m->extra_data,
						'sort_order' => $m->sort_order,
					),
					$item_models
				);

				AssetRegistrar::enqueue_for_type( $type->frontend_handles() );

				$entity   = array(
					'ID'         => $parent->ID,
					'title'      => $parent->title,
					'type'       => $parent->type,
					'status'     => $parent->status,
					'extra_data' => $parent->extra_data,
					'author'     => $parent->author,
					'created_at' => $parent->created_at,
					'updated_at' => $parent->updated_at,
				);
				$pieces[] = $this->wrap_item( $type_k, $type->render( $entity, $items ) );
			}

			if ( empty( $pieces ) ) {
				return '';
			}

			return '<div class="lp-interactive-list">' . implode( '', $pieces ) . '</div>';
		} catch ( Throwable $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( __METHOD__ . ': ' . $e->getMessage() );
			}
			return '';
		}
	}

	/**
	 * Build a sanitized filter from raw shortcode atts. Pure function — testable.
	 */
	public function build_filter( array $attrs ): InteractiveFilter {
		$filter = new InteractiveFilter();

		$filter->status = 'publish';

		$type = sanitize_key( (string) ( $attrs['type'] ?? '' ) );
		if ( '' !== $type ) {
			$filter->type = $type;
		}

		$limit         = absint( $attrs['limit'] ?? 10 );
		$filter->limit = max( 1, min( self::MAX_LIMIT, $limit > 0 ? $limit : 10 ) );

		$orderby          = sanitize_key( (string) ( $attrs['orderby'] ?? 'created_at' ) );
		$filter->order_by = in_array( $orderby, self::ALLOWED_ORDERBY, true ) ? $orderby : 'created_at';

		$order         = strtoupper( (string) ( $attrs['order'] ?? 'DESC' ) );
		$filter->order = in_array( $order, array( 'ASC', 'DESC' ), true ) ? $order : 'DESC';

		return $filter;
	}

	/**
	 * Wrap a single rendered entry. Pure function — testable.
	 */
	public function wrap_item( string $type_key, string $inner ): string {
		return sprintf(
			'<div class="lp-interactive-list__item lp-interactive-list__item--%s">%s</div>',
			esc_attr( $type_key ),
			$inner
		);
	}
}
