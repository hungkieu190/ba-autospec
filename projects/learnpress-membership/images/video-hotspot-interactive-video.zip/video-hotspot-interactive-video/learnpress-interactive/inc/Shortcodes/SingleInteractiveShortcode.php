<?php
namespace LearnPress\Interactive\Shortcodes;

use LearnPress\Helpers\Singleton;
use LearnPress\Helpers\Template;
use LearnPress\Interactive\Assets\AssetRegistrar;
use LearnPress\Interactive\Models\InteractiveItemModel;
use LearnPress\Interactive\Models\InteractiveModel;
use LearnPress\Interactive\Types\TypeRegistry;
use LearnPress\Shortcodes\AbstractShortcode;
use Throwable;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( '\LearnPress\Shortcodes\AbstractShortcode' ) ) {
	return;
}

class SingleInteractiveShortcode extends AbstractShortcode {
	use Singleton;

	protected $prefix         = '';
	protected $shortcode_name = 'learnpress_single_interactive';

	public function init() {
		parent::init();
	}

	/**
	 * @param array $attrs [id: int]
	 */
	public function render( $attrs ): string {
		try {
			$attrs = is_array( $attrs ) ? $attrs : array();
			$id    = absint( $attrs['id'] ?? 0 );
			if ( 0 === $id ) {
				return '';
			}
			if ( $this->is_course_builder_editor_request() ) {
				return '[learnpress_single_interactive id="' . $id . '"]';
			}

			$parent = InteractiveModel::find( $id );
			if ( ! $parent || 'publish' !== $parent->status ) {
				return '';
			}

			$type = TypeRegistry::get( $parent->type );
			if ( ! $type ) {
				return '';
			}

			$item_models = InteractiveItemModel::find_by_parent( $id );
			$items       = array_map(
				static fn( InteractiveItemModel $m ) => array(
					'content'    => $m->content,
					'extra_data' => $m->extra_data,
					'sort_order' => $m->sort_order,
				),
				$item_models
			);

			AssetRegistrar::enqueue_for_type( $type->frontend_handles() );

			$entity = array(
				'ID'         => $parent->ID,
				'title'      => $parent->title,
				'type'       => $parent->type,
				'status'     => $parent->status,
				'extra_data' => $parent->extra_data,
				'author'     => $parent->author,
				'created_at' => $parent->created_at,
				'updated_at' => $parent->updated_at,
			);

			return $type->render( $entity, $items );
		} catch ( Throwable $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				Template::print_message( $e->getMessage(), 'error', false );
			}
			return '';
		}
	}

	private function is_course_builder_editor_request(): bool {
		return class_exists( '\LP_Page_Controller' )
			&& method_exists( '\LP_Page_Controller', 'is_page_course_builder' )
			&& \LP_Page_Controller::is_page_course_builder();
	}
}
