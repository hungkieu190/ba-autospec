<?php

namespace LearnPress\Interactive\Services;

use RuntimeException;

defined( 'ABSPATH' ) || exit;

class GoogleFontCacheService {
	private const UPLOAD_DIR = 'interactive-fonts';
	private const CSS_FILE = 'font.css';
	private const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

	private array $css_cache = array();

	public function cache( string $family, array $files = array(), string $variant = 'regular', array $variants = array() ): array {
		$family = $this->normalize_family( $family );
		if ( '' === $family ) {
			throw new RuntimeException( 'Invalid font family.' );
		}
		$variant = $this->normalize_variant( $variant );

		$upload_dir = wp_upload_dir();
		if ( ! empty( $upload_dir['error'] ) ) {
			throw new RuntimeException( (string) $upload_dir['error'] );
		}

		$slug      = $this->family_slug( $family );
		$font_dir  = trailingslashit( $upload_dir['basedir'] ) . self::UPLOAD_DIR . '/' . $slug;
		$font_url  = trailingslashit( $upload_dir['baseurl'] ) . self::UPLOAD_DIR . '/' . $slug;

		if ( ! wp_mkdir_p( $font_dir ) ) {
			throw new RuntimeException( 'Could not create font directory.' );
		}

		$manifest = $this->read_manifest( $font_dir );
		$fonts    = is_array( $manifest['fonts'] ?? null ) ? $manifest['fonts'] : array();
		$variants = $this->normalize_variants( $variants );

		$css_url = $this->cached_css_url( $font_dir, $font_url, $manifest );
		$source  = $this->direct_source_for_variant( $variant, $files );
		try {
			$result            = $this->cache_css_variant( $family, $variant, $font_dir, $font_url );
			$fonts[ $variant ] = $result['font'];
			$css_url           = $result['cssUrl'];
		} catch ( RuntimeException $e ) {
			if ( ! $source ) {
				throw $e;
			}

			$format    = $this->source_format( $source );
			$file_path = $font_dir . '/' . $variant . '.' . $this->format_extension( $format );
			if ( ! file_exists( $file_path ) ) {
				$this->download_font_file( $source, $file_path );
			}

			$fonts[ $variant ] = $this->font_payload( $font_url, $variant, $format );
		}

		$variants = array_values( array_unique( array_merge( $variants, array_keys( $fonts ) ) ) );
		$this->write_manifest( $font_dir, $family, $slug, $fonts, $variants, $css_url );

		$payload = array(
			'family'   => $family,
			'slug'     => $slug,
			'cached'   => true,
			'category' => 'system',
			'variants' => $variants,
			'fonts'    => $fonts,
		);
		if ( $css_url ) {
			$payload['cssUrl'] = $css_url;
		}

		return $payload;
	}

	public function cached_fonts(): array {
		$upload_dir = wp_upload_dir();
		if ( ! empty( $upload_dir['error'] ) ) {
			return array();
		}

		$base_dir = trailingslashit( $upload_dir['basedir'] ) . self::UPLOAD_DIR;
		$base_url = trailingslashit( $upload_dir['baseurl'] ) . self::UPLOAD_DIR;
		if ( ! is_dir( $base_dir ) ) {
			return array();
		}

		$fonts = array();
		foreach ( glob( $base_dir . '/*', GLOB_ONLYDIR ) ?: array() as $font_dir ) {
			$slug = basename( $font_dir );

			$manifest = $this->read_manifest( $font_dir );
			$family   = ! empty( $manifest['family'] ) ? (string) $manifest['family'] : ucwords( str_replace( '-', ' ', $slug ) );
			$font_url = $base_url . '/' . $slug;
			$items    = is_array( $manifest['fonts'] ?? null ) ? $manifest['fonts'] : array();
			$css_url  = $this->cached_css_url( $font_dir, $font_url, $manifest );

			foreach ( $this->cached_font_files( $font_dir ) as $file_path ) {
				$format  = $this->source_format( $file_path );
				$variant = basename( $file_path, '.' . $this->format_extension( $format ) );
				if ( ! isset( $items[ $variant ] ) ) {
					$items[ $variant ] = $this->font_payload( $font_url, $variant, $format );
				}
			}
			if ( empty( $items ) ) {
				continue;
			}

			$payload = array(
				'family'   => $family,
				'slug'     => $slug,
				'cached'   => true,
				'category' => 'system',
				'variants' => array_values(
					array_unique(
						array_merge(
							is_array( $manifest['variants'] ?? null ) ? $manifest['variants'] : array(),
							array_keys( $items )
						)
					)
				),
				'fonts'    => $items,
			);
			if ( $css_url ) {
				$payload['cssUrl'] = $css_url;
			}

			$fonts[] = $payload;
		}

		usort(
			$fonts,
			static function ( array $a, array $b ): int {
				return strcasecmp( (string) $a['family'], (string) $b['family'] );
			}
		);

		return $fonts;
	}

	private function write_manifest( string $font_dir, string $family, string $slug, array $fonts, array $variants, string $css_url = '' ): void {
		$payload = array(
			'family'   => $family,
			'slug'     => $slug,
			'cached'   => true,
			'variants' => $variants,
			'fonts'    => $fonts,
		);
		if ( $css_url ) {
			$payload['cssUrl'] = $css_url;
		}

		file_put_contents(
			$font_dir . '/font.json',
			wp_json_encode(
				$payload,
				JSON_UNESCAPED_UNICODE
			)
		);
	}

	private function cached_font_files( string $font_dir ): array {
		$files = array_merge(
			glob( $font_dir . '/*.woff2' ) ?: array(),
			glob( $font_dir . '/*.ttf' ) ?: array()
		);

		return array_values(
			array_filter(
				$files,
				function ( string $file_path ): bool {
					$format  = $this->source_format( $file_path );
					$variant = basename( $file_path, '.' . $this->format_extension( $format ) );
					return $variant === $this->normalize_variant( $variant );
				}
			)
		);
	}

	private function font_payload( string $font_url, string $variant, string $format = 'woff2' ): array {
		$format = $this->normalize_format( $format );
		return array(
			'url'     => $font_url . '/' . $variant . '.' . $this->format_extension( $format ),
			'weight'  => $this->variant_weight( $variant ),
			'style'   => $this->variant_style( $variant ),
			'variant' => $variant,
			'label'   => $this->variant_label( $variant ),
			'format'  => $format,
		);
	}

	private function read_manifest( string $font_dir ): array {
		$path = $font_dir . '/font.json';
		if ( ! file_exists( $path ) ) {
			return array();
		}

		$contents = file_get_contents( $path );
		if ( ! is_string( $contents ) || '' === $contents ) {
			return array();
		}

		$manifest = json_decode( $contents, true );
		return is_array( $manifest ) ? $manifest : array();
	}

	private function normalize_family( string $family ): string {
		$family = trim( sanitize_text_field( wp_unslash( $family ) ) );
		if ( strlen( $family ) > 120 ) {
			return '';
		}

		return preg_match( '/^[\pL\pN ._\-]+$/u', $family ) ? $family : '';
	}

	private function normalize_variant( string $variant ): string {
		$variant = sanitize_key( wp_unslash( $variant ) );
		if ( 'italic' === $variant || 'regular' === $variant ) {
			return $variant;
		}
		if ( preg_match( '/^[1-9]00(?:italic)?$/', $variant ) ) {
			return $variant;
		}

		return 'regular';
	}

	private function normalize_variants( array $variants ): array {
		$normalized = array();
		foreach ( $variants as $variant ) {
			if ( is_string( $variant ) && '' !== $variant ) {
				$normalized[] = $this->normalize_variant( $variant );
			}
		}

		return array_values( array_unique( $normalized ) );
	}

	private function family_slug( string $family ): string {
		$slug = sanitize_title( $family );
		return $slug ?: sanitize_file_name( strtolower( str_replace( ' ', '-', $family ) ) );
	}

	private function cached_css_url( string $font_dir, string $font_url, array $manifest ): string {
		if ( file_exists( $font_dir . '/' . self::CSS_FILE ) ) {
			return $font_url . '/' . self::CSS_FILE;
		}

		return ! empty( $manifest['cssUrl'] ) ? (string) $manifest['cssUrl'] : '';
	}

	private function direct_source_for_variant( string $variant, array $files ): string {
		$source  = isset( $files[ $variant ] ) ? esc_url_raw( (string) $files[ $variant ] ) : '';

		if ( $source && $this->is_allowed_font_source( $source ) ) {
			return $source;
		}

		return '';
	}

	private function is_allowed_font_source( string $source ): bool {
		return (bool) preg_match(
			'/^https:\/\/fonts\.gstatic\.com\/(?:s\/.+\.(?:woff2|ttf)(?:\?.*)?|l\/font\?.+)$/',
			$source
		);
	}

	private function source_format( string $source ): string {
		$path = parse_url( $source, PHP_URL_PATH );
		if ( is_string( $path ) && preg_match( '/\.ttf$/i', $path ) ) {
			return 'truetype';
		}
		if ( '/l/font' === $path ) {
			return 'truetype';
		}

		return 'woff2';
	}

	private function normalize_format( string $format ): string {
		return 'truetype' === $format ? 'truetype' : 'woff2';
	}

	private function format_extension( string $format ): string {
		return 'truetype' === $this->normalize_format( $format ) ? 'ttf' : 'woff2';
	}

	private function cache_css_variant( string $family, string $variant, string $font_dir, string $font_url ): array {
		$remote_css = $this->google_css( $family, $variant );
		$sources    = $this->parse_css_sources( $remote_css );

		if ( empty( $sources ) ) {
			throw new RuntimeException( 'Google font variant was not found.' );
		}

		$localized_css = $remote_css;
		foreach ( $sources as $source ) {
			$filename   = $variant . '-' . substr( md5( $source['url'] ), 0, 12 ) . '.' . $this->format_extension( $source['format'] );
			$file_path  = $font_dir . '/' . $filename;
			if ( ! file_exists( $file_path ) ) {
				$this->download_font_file( $source['url'], $file_path );
			}
			$localized_css = str_replace( $source['url'], $filename, $localized_css );
		}

		$css_path = $font_dir . '/' . self::CSS_FILE;
		$existing = file_exists( $css_path ) ? (string) file_get_contents( $css_path ) : '';
		$merged   = trim( $this->without_variant_faces( $existing, $variant ) . "\n" . trim( $localized_css ) ) . "\n";
		if ( false === file_put_contents( $css_path, $merged ) ) {
			throw new RuntimeException( 'Could not save font CSS.' );
		}

		$font = $this->font_payload_from_source( $font_url, $variant, $sources[0] );
		return array(
			'cssUrl' => $font_url . '/' . self::CSS_FILE,
			'font'   => $font,
		);
	}

	private function font_payload_from_source( string $font_url, string $variant, array $source ): array {
		$filename = $variant . '-' . substr( md5( (string) $source['url'] ), 0, 12 ) . '.' . $this->format_extension( (string) $source['format'] );
		return array(
			'url'     => $font_url . '/' . $filename,
			'weight'  => $this->variant_weight( $variant ),
			'style'   => $this->variant_style( $variant ),
			'variant' => $variant,
			'label'   => $this->variant_label( $variant ),
			'format'  => $this->normalize_format( (string) $source['format'] ),
		);
	}

	private function google_css( string $family, string $variant ): string {
		$cache_key = $family . ':' . $variant;
		if ( isset( $this->css_cache[ $cache_key ] ) ) {
			return $this->css_cache[ $cache_key ];
		}

		$url = add_query_arg(
			array(
				'family'  => $this->google_css_family_spec( $family, $variant ),
				'display' => 'swap',
			),
			'https://fonts.googleapis.com/css2'
		);

		$response = wp_remote_get(
			$url,
			array(
				'timeout'    => 30,
				'user-agent' => self::USER_AGENT,
			)
		);

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			throw new RuntimeException( 'Could not fetch Google Fonts CSS.' );
		}

		$css = wp_remote_retrieve_body( $response );
		if ( ! is_string( $css ) || '' === $css ) {
			throw new RuntimeException( 'Google Fonts CSS was empty.' );
		}

		$this->css_cache[ $cache_key ] = $css;
		return $css;
	}

	private function parse_css_sources( string $css ): array {
		$sources = array();
		foreach ( $this->font_face_blocks( $css ) as $block ) {
			$body = $block['body'];

			if (
				! preg_match( '/font-weight:\s*(\d+)/i', $body, $weight_match ) ||
				! preg_match( '/font-style:\s*(normal|italic)/i', $body, $style_match ) ||
				! preg_match( '/src:\s*url\((?:\'|")?(https:\/\/fonts\.gstatic\.com\/[^)\'"]+)(?:\'|")?\)\s*format\((?:\'|")?([^)"\']+)(?:\'|")?\)/i', $body, $url_match )
			) {
				continue;
			}

			$url = esc_url_raw( $url_match[1] );
			if ( ! $this->is_allowed_font_source( $url ) ) {
				continue;
			}

			$sources[] = array(
				'url'    => $url,
				'weight' => absint( $weight_match[1] ),
				'style'  => sanitize_key( $style_match[1] ),
				'format' => $this->normalize_format( (string) $url_match[2] ),
			);
		}

		return $sources;
	}

	private function font_face_blocks( string $css ): array {
		preg_match_all(
			'/(?:\/\*\s*([^*]+)\s*\*\/\s*)?@font-face\s*\{([^}]+)\}/i',
			$css,
			$matches,
			PREG_SET_ORDER | PREG_OFFSET_CAPTURE
		);

		$blocks = array();
		foreach ( $matches as $match ) {
			$blocks[] = array(
				'text'   => $match[0][0],
				'offset' => $match[0][1],
				'body'   => $match[2][0] ?? '',
				'subset' => strtolower( trim( $match[1][0] ?? '' ) ),
			);
		}

		return $blocks;
	}

	private function without_variant_faces( string $css, string $variant ): string {
		if ( '' === trim( $css ) ) {
			return '';
		}

		$weight = $this->variant_weight( $variant );
		$style  = $this->variant_style( $variant );
		$result = '';
		$cursor = 0;

		foreach ( $this->font_face_blocks( $css ) as $block ) {
			$result .= substr( $css, $cursor, $block['offset'] - $cursor );
			$cursor  = $block['offset'] + strlen( $block['text'] );

			$body = $block['body'];
			if (
				preg_match( '/font-weight:\s*(\d+)/i', $body, $weight_match ) &&
				preg_match( '/font-style:\s*(normal|italic)/i', $body, $style_match ) &&
				absint( $weight_match[1] ) === $weight &&
				sanitize_key( $style_match[1] ) === $style
			) {
				continue;
			}

			$result .= $block['text'];
		}

		return trim( $result . substr( $css, $cursor ) );
	}

	private function google_css_family_spec( string $family, string $variant ): string {
		$weight = $this->variant_weight( $variant );
		$style  = $this->variant_style( $variant );

		if ( 'normal' === $style && 400 === $weight ) {
			return $family;
		}
		if ( 'normal' === $style ) {
			return $family . ':wght@' . $weight;
		}
		if ( 400 === $weight ) {
			return $family . ':ital@1';
		}

		return $family . ':ital,wght@1,' . $weight;
	}

	private function variant_weight( string $variant ): int {
		if ( 'regular' === $variant || 'italic' === $variant ) {
			return 400;
		}

		return absint( preg_replace( '/[^0-9]/', '', $variant ) ) ?: 400;
	}

	private function variant_style( string $variant ): string {
		return false !== strpos( $variant, 'italic' ) ? 'italic' : 'normal';
	}

	private function variant_label( string $variant ): string {
		$weight = $this->variant_weight( $variant );
		$style  = $this->variant_style( $variant );
		$labels = array(
			100 => 'Thin',
			200 => 'Extra Light',
			300 => 'Light',
			400 => 'Regular',
			500 => 'Medium',
			600 => 'Semi Bold',
			700 => 'Bold',
			800 => 'Extra Bold',
			900 => 'Black',
		);

		$label = $labels[ $weight ] ?? (string) $weight;
		return 'italic' === $style ? $label . ' Italic' : $label;
	}

	private function download_font_file( string $source, string $file_path ): void {
		$response = wp_remote_get(
			$source,
			array(
				'timeout'    => 30,
				'user-agent' => self::USER_AGENT,
			)
		);

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			throw new RuntimeException( 'Could not download font file.' );
		}

		$body = wp_remote_retrieve_body( $response );
		if ( ! is_string( $body ) || '' === $body ) {
			throw new RuntimeException( 'Font file was empty.' );
		}

		if ( false === file_put_contents( $file_path, $body ) ) {
			throw new RuntimeException( 'Could not save font file.' );
		}
	}
}
