<?php

namespace LearnPress\Interactive\Services;

use LearnPress\Helpers\Singleton;
use LearnPress\Interactive\Models\InteractiveItemModel;
use LearnPress\Interactive\Models\InteractiveModel;
use LearnPress\Interactive\Types\FlashCardType;
use LearnPress\Interactive\Types\TypeInterface;
use LearnPress\Interactive\Types\TypeRegistry;

defined( 'ABSPATH' ) || exit;

/**
 * Class InteractiveService
 *
 * Handle business logic for interactive content. Orchestrates parent +
 * items models and dispatches to the strategy registry for type-specific
 * sanitize/render. Used by AJAX handlers and shortcode render layer.
 *
 * @since 1.0.0
 * @version 1.0.0
 */
class InteractiveService {
	use Singleton;

	public function init() {}

	/**
	 * Create a new interactive entry together with its items in one shot.
	 *
	 * @param array $data title, type, status?, author, settings?, items?
	 * @return int Parent ID on success; 0 on failure.
	 * @throws \InvalidArgumentException When type key is unknown.
	 */
	public function create_with_items( array $data ): int {
		$type  = $this->require_type( (string) ( $data['type'] ?? '' ) );
		$title = $this->normalize_title( $type, (string) ( $data['title'] ?? '' ) );

		$settings = isset( $data['settings'] ) && is_array( $data['settings'] )
			? $type->sanitize_settings( $data['settings'] )
			: $type->default_settings();

		$model             = new InteractiveModel();
		$model->title      = $title;
		$model->type       = $type->key();
		$model->status     = (string) ( $data['status'] ?? 'publish' );
		$model->author     = (int) ( $data['author'] ?? 0 );
		$model->extra_data = $settings;

		$id = $model->save();
		if ( ! $id ) {
			return 0;
		}

		$items = $this->sanitize_items( $type, $data['items'] ?? array() );
		if ( empty( $items ) && method_exists( $type, 'default_items' ) ) {
			$items = $type->default_items();
		}
		if ( ! InteractiveItemModel::bulk_replace( $id, $items ) ) {
			$model->force_delete();
			return 0;
		}

		return $id;
	}

	/**
	 * Update an existing entry. Only fields present in $data are touched.
	 * If $data['items'] is provided, items are replaced atomically.
	 *
	 * @param int   $id   Parent entity ID.
	 * @param array $data title?, status?, settings?, items?
	 * @return bool true on success, false if entity not found.
	 */
	public function save( int $id, array $data ): bool {
		$model = InteractiveModel::find( $id );
		if ( ! $model ) {
			return false;
		}
		$type = $this->require_type( $model->type );

		if ( array_key_exists( 'title', $data ) ) {
			$model->title = $this->normalize_title( $type, (string) $data['title'] );
		}
		if ( array_key_exists( 'status', $data ) ) {
			$model->status = (string) $data['status'];
		}
		if ( array_key_exists( 'settings', $data ) && is_array( $data['settings'] ) ) {
			$model->extra_data = $type->sanitize_settings( $data['settings'] );
		}

		if ( ! $model->save() ) {
			return false;
		}

		if ( array_key_exists( 'items', $data ) ) {
			$items = $this->sanitize_items( $type, (array) $data['items'] );
			if ( ! InteractiveItemModel::bulk_replace( $id, $items ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Update one slide's canvas content without replacing the slide list.
	 *
	 * @param int   $id      Parent entity ID.
	 * @param int   $slide_id Child row ID for the slide.
	 * @param array $slide    Raw slide payload.
	 * @return bool true on success; false when parent/slide is missing or mismatched.
	 */
	public function save_slide_content( int $id, int $slide_id, array $slide ): bool {
		$model = InteractiveModel::find( $id );
		if ( ! $model ) {
			return false;
		}

		$slide_model = InteractiveItemModel::find( $slide_id );
		if ( ! $slide_model || (int) $slide_model->interactive_id !== $id ) {
			return false;
		}

		$type  = $this->require_type( $model->type );
		$clean = $type->sanitize_item( $slide );

		$slide_model->content    = $clean['content'] ?? '';
		$slide_model->extra_data = is_array( $clean['extra_data'] ?? null ) ? $clean['extra_data'] : array();

		return (bool) $slide_model->save();
	}

	/**
	 * Create one slide row without replacing the existing slide list.
	 *
	 * @param int   $id         Parent entity ID.
	 * @param array $slide      Raw slide payload.
	 * @param int   $sort_order Position within the parent list.
	 * @return int Slide row ID on success; 0 on failure.
	 */
	public function create_slide( int $id, array $slide, int $sort_order ): int {
		$model = InteractiveModel::find( $id );
		if ( ! $model ) {
			return 0;
		}

		$type  = $this->require_type( $model->type );
		$clean = $type->sanitize_item( $slide );

		$slide_model                 = new InteractiveItemModel();
		$slide_model->interactive_id = $id;
		$slide_model->content        = $clean['content'] ?? '';
		$slide_model->sort_order     = max( 0, $sort_order );
		$slide_model->extra_data     = is_array( $clean['extra_data'] ?? null ) ? $clean['extra_data'] : array();

		return $slide_model->save();
	}

	/**
	 * Delete one slide row after verifying it belongs to the given parent.
	 */
	public function delete_slide( int $id, int $slide_id ): bool {
		if ( ! InteractiveModel::find( $id ) ) {
			return false;
		}

		$slide_model = InteractiveItemModel::find( $slide_id );
		if ( ! $slide_model || (int) $slide_model->interactive_id !== $id ) {
			return false;
		}

		return $slide_model->delete();
	}

	/**
	 * Update slide sort_order values for the exact slide list submitted.
	 *
	 * @param int   $id       Parent entity ID.
	 * @param int[] $slide_ids Ordered slide row IDs.
	 */
	public function reorder_slides( int $id, array $slide_ids ): bool {
		if ( ! InteractiveModel::find( $id ) ) {
			return false;
		}

		$slide_ids = array_values(
			array_unique(
				array_filter( array_map( 'intval', $slide_ids ), static fn( $slide_id ) => $slide_id > 0 )
			)
		);
		if ( empty( $slide_ids ) ) {
			return false;
		}

		$slides_by_id = array();
		foreach ( InteractiveItemModel::find_by_parent( $id ) as $slide_model ) {
			$slides_by_id[ (int) $slide_model->ID ] = $slide_model;
		}

		if ( count( $slide_ids ) !== count( $slides_by_id ) ) {
			return false;
		}

		foreach ( $slide_ids as $slide_id ) {
			if ( ! isset( $slides_by_id[ $slide_id ] ) ) {
				return false;
			}
		}

		foreach ( $slide_ids as $sort_order => $slide_id ) {
			$slides_by_id[ $slide_id ]->sort_order = $sort_order;
			if ( ! $slides_by_id[ $slide_id ]->save() ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Move an entry to trash (status=trash).
	 */
	public function soft_delete( int $id ): bool {
		$model = InteractiveModel::find( $id );
		if ( ! $model ) {
			return false;
		}
		return $model->soft_delete();
	}

	/**
	 * Restore an entry from trash (status=publish).
	 */
	public function restore( int $id ): bool {
		$model = InteractiveModel::find( $id );
		if ( ! $model ) {
			return false;
		}
		$model->status = 'publish';
		return (bool) $model->save();
	}

	/**
	 * Duplicate an entry + its items into a new draft entry.
	 * Returns the new entry ID on success, 0 on failure.
	 */
	public function duplicate( int $id ): int {
		$source = InteractiveModel::find( $id );
		if ( ! $source ) {
			return 0;
		}
		$items_raw = InteractiveItemModel::find_by_parent( $source->ID );
		$is_flash  = 'flash_card' === $source->type;
		$items     = array();
		foreach ( $items_raw as $item ) {
			if ( $is_flash ) {
				$items[] = array(
					'sort_order' => $item->sort_order,
				) + FlashCardType::decode_card(
					array(
						'content'    => $item->content,
						'extra_data' => $item->extra_data,
					)
				);
			} else {
				$items[] = array(
					'content'    => $item->content,
					'sort_order' => $item->sort_order,
					'extra_data' => $item->extra_data,
				);
			}
		}

		$title = trim( (string) $source->title );
		if ( '' === $title ) {
			$title = sprintf( __( '(no title) (Copy)', 'learnpress-interactive' ) );
		} else {
			$title .= ' (Copy)';
		}

		return $this->create_with_items(
			array(
				'title'    => $title,
				'type'     => $source->type,
				'status'   => 'draft',
				'author'   => get_current_user_id(),
				'settings' => is_array( $source->extra_data ) ? $source->extra_data : array(),
				'items'    => $items,
			)
		);
	}

	/**
	 * Permanently delete an entry plus its items (cascade).
	 */
	public function force_delete( int $id ): bool {
		$model = InteractiveModel::find( $id );
		if ( ! $model ) {
			return false;
		}
		return $model->force_delete();
	}

	/**
	 * Render an entry's frontend HTML by dispatching to its type strategy.
	 * Returns empty string when entry missing or not published.
	 */
	public function render( int $id ): string {
		$model = InteractiveModel::find( $id );
		if ( ! $model || 'publish' !== $model->status ) {
			return '';
		}
		$type = TypeRegistry::get( $model->type );
		if ( ! $type ) {
			return '';
		}

		$items = array_map(
			static fn( InteractiveItemModel $item ) => array(
				'content'    => $item->content,
				'extra_data' => $item->extra_data,
				'sort_order' => $item->sort_order,
			),
			InteractiveItemModel::find_by_parent( $id )
		);

		$entity = array(
			'ID'         => $model->ID,
			'title'      => $model->title,
			'type'       => $model->type,
			'status'     => $model->status,
			'extra_data' => $model->extra_data,
			'author'     => $model->author,
			'created_at' => $model->created_at,
			'updated_at' => $model->updated_at,
		);

		return $type->render( $entity, $items );
	}

	/**
	 * Resolve a type key into its strategy instance, throwing if unknown.
	 *
	 * @throws \InvalidArgumentException
	 */
	private function require_type( string $key ): TypeInterface {
		$type = TypeRegistry::get( $key );
		if ( ! $type ) {
			throw new \InvalidArgumentException( 'Unknown interactive type: ' . $key );
		}
		return $type;
	}

	/**
	 * Sanitize each item via the type strategy. Drops non-array entries.
	 *
	 * @return array<int, array{content:string, extra_data:array}>
	 */
	private function sanitize_items( TypeInterface $type, array $raw_items ): array {
		$clean = array();
		foreach ( array_values( $raw_items ) as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$clean[] = $type->sanitize_item( $item );
		}
		return $clean;
	}

	private function normalize_title( TypeInterface $type, string $title ): string {
		$title = mb_substr( sanitize_text_field( $title ), 0, 255 );
		if ( '' !== $title ) {
			return $title;
		}

		if ( method_exists( $type, 'default_title' ) ) {
			return mb_substr( sanitize_text_field( (string) $type->default_title() ), 0, 255 );
		}

		return '';
	}
}
