<?php
/**
 * Plugin Name: LearnPress - Interactive
 * Plugin URI: https://thimpress.com/product/interactive-add-on-for-learnpress/
 * Description: Interactive add-on for LearnPress.
 * Author: ThimPress
 * Version: 4.0.0
 * Author URI: http://thimpress.com
 * Tags: learnpress, lms, interactive
 * Requires at least: 6.3
 * Requires PHP: 7.4
 * Text Domain: learnpress-interactive
 * Domain Path: /languages/
 * Require_LP_Version: 4.3.2.7
 *
 * @package learnpress-interactive
 */

defined( 'ABSPATH' ) || exit;

const LP_ADDON_INTERACTIVE_FILE = __FILE__;
const LP_ADDON_INTERACTIVE_PATH = __DIR__;

/**
 * Class LP_Addon_Interactive_Preload
 */
class LP_Addon_Interactive_Preload {
	/**
	 * @var array
	 */
	public static $addon_info = array();
	/**
	 * @var LP_Addon_Interactive $addon
	 */
	public static $addon;

	/**
	 * Singleton.
	 *
	 * @return LP_Addon_Interactive_Preload|mixed
	 */
	public static function instance() {
		static $instance;
		if ( is_null( $instance ) ) {
			$instance = new self();
		}

		return $instance;
	}

	/**
	 * LP_Addon_Interactive_Preload constructor.
	 */
	protected function __construct() {
		$can_load = true;
		define( 'LP_ADDON_INTERACTIVE_BASENAME', plugin_basename( __FILE__ ) );

		// Set version addon for LP check .
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
		self::$addon_info = get_file_data(
			LP_ADDON_INTERACTIVE_FILE,
			array(
				'Name'               => 'Plugin Name',
				'Require_LP_Version' => 'Require_LP_Version',
				'Version'            => 'Version',
			)
		);

		define( 'LP_ADDON_INTERACTIVE_VER', self::$addon_info['Version'] );
		define( 'LP_ADDON_INTERACTIVE_REQUIRE_VER', self::$addon_info['Require_LP_Version'] );

		// Check LP activated .
		if ( ! is_plugin_active( 'learnpress/learnpress.php' ) ) {
			$can_load = false;
		} else {
			// Check version LP
			if ( version_compare(
				LP_ADDON_INTERACTIVE_REQUIRE_VER,
				get_option( 'learnpress_version', '3.0.0' ),
				'>'
			)
			) {
				$can_load = false;
			}
		}

		if ( ! $can_load ) {
			add_action( 'admin_notices', array( $this, 'show_note_errors_require_lp' ) );

			return;
		}

		include_once LP_ADDON_INTERACTIVE_PATH . '/vendor/autoload.php';

		register_activation_hook( LP_ADDON_INTERACTIVE_FILE, [ '\LearnPress\Interactive\Install\Installer', 'activate' ] );

		/**
		 * Hook learn-press/ready call on hook 'init' with priority -1000
		 */
		add_action( 'learn-press/ready', array( $this, 'load' ) );
	}

	/**
	 * Load addon
	 */
	public function load() {
		require_once LP_ADDON_INTERACTIVE_PATH . '/inc/load.php';
		self::$addon = LP_Addon_Interactive::instance();
	}

	public function show_note_errors_require_lp() {
		?>
		<div class="notice notice-error">
			<p><?php echo( 'Please active <strong>LearnPress version ' . LP_ADDON_INTERACTIVE_REQUIRE_VER . ' or later</strong> before active <strong>' . self::$addon_info['Name'] . '</strong>' ); ?></p>
		</div>
		<?php
	}
}

LP_Addon_Interactive_Preload::instance();
