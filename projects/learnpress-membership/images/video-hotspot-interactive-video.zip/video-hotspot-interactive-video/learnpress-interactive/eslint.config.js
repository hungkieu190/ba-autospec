const globals = require("globals");

module.exports = [
	{
		ignores: [
			"**/*.min.js",
			"assets/dist/**",
			"node_modules/**",
			"vendor/**",
			"release/**",
			"languages/**",
		],
	},
	{
		files: ["assets/src/js/**/*.js"],
		languageOptions: {
			ecmaVersion: 2022,
			sourceType: "module",
			globals: {
				...globals.browser,
				...globals.es2022,
				wp: "readonly",
				ajaxurl: "readonly",
				lpInteractiveAdminSettings: "readonly",
			},
		},
		rules: {
			"no-var": "error",
			"prefer-const": "warn",
			"no-unused-expressions": ["error", { allowShortCircuit: true }],

			indent: ["error", "tab", { SwitchCase: 1 }],
			"space-in-parens": ["error", "always"],
			quotes: ["warn", "single", { avoidEscape: true }],
			semi: ["error", "always"],

			"no-console": "off",
			"no-unused-vars": ["warn", { args: "none", caughtErrors: "none" }],
		},
	},
];
