<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Helpers;

use LearnPress\Interactive\Types\AbstractType;

/**
 * In-memory fake type used by Service + Ajax tests so they don't depend on
 * the real type implementations.
 */
final class FakeServiceType extends AbstractType {

	public function key(): string {
		return 'fake';
	}

	public function label(): string {
		return 'Fake';
	}

	public function default_settings(): array {
		return array( 'flag' => false );
	}

	public function sanitize_settings( array $raw ): array {
		return array( 'flag' => ! empty( $raw['flag'] ) );
	}

	public function sanitize_item( array $raw ): array {
		return array(
			'content'    => (string) ( $raw['content'] ?? '' ),
			'extra_data' => array( 'note' => (string) ( $raw['note'] ?? '' ) ),
		);
	}

	public function render( array $entity, array $items ): string {
		return '<div class="fake">' . ( $entity['title'] ?? '' ) . ' (' . count( $items ) . ' items)</div>';
	}
}
