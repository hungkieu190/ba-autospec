<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Helpers;

use Brain\Monkey;
use Mockery\Adapter\Phpunit\MockeryPHPUnitIntegration;
use PHPUnit\Framework\TestCase;

abstract class BrainMonkeyTestCase extends TestCase {

	use MockeryPHPUnitIntegration;

	protected function setUp(): void {
		parent::setUp();
		Monkey\setUp();

		Monkey\Functions\stubTranslationFunctions();
		Monkey\Functions\stubEscapeFunctions();

		Monkey\Functions\when( 'sanitize_text_field' )->alias(
			static function ( $s ) {
				$s = (string) $s;
				$s = strip_tags( $s );
				$s = preg_replace( "/[\r\n\t\0\x0B]+/", ' ', $s );
				$s = preg_replace( '/\s+/', ' ', $s );
				return trim( $s );
			}
		);

		// Like sanitize_text_field but preserves newlines.
		Monkey\Functions\when( 'sanitize_textarea_field' )->alias(
			static function ( $s ) {
				$s = (string) $s;
				$s = strip_tags( $s );
				$s = preg_replace( '/\s+/', ' ', $s );
				return trim( $s );
			}
		);

		Monkey\Functions\when( 'wp_get_attachment_image' )->alias(
			static function ( $id, $size = 'thumbnail', $icon = false, $attr = array() ) {
				return $id > 0 ? '<img src="http://example.test/img/' . (int) $id . '.jpg" alt="" />' : '';
			}
		);

		Monkey\Functions\when( 'wp_kses_post' )->returnArg();

		Monkey\Functions\when( 'wp_kses' )->alias(
			static function ( $content, $allowed_html = array() ) {
				return empty( $allowed_html ) ? strip_tags( (string) $content ) : (string) $content;
			}
		);

		// Mirror real WP wp_unslash → stripslashes_deep: recurses into nested
		// arrays/objects, leaves non-string scalars untouched.
		$stripslashes_deep = static function ( $value ) use ( &$stripslashes_deep ) {
			if ( is_array( $value ) ) {
				return array_map( $stripslashes_deep, $value );
			}
			if ( is_object( $value ) ) {
				foreach ( get_object_vars( $value ) as $k => $v ) {
					$value->$k = $stripslashes_deep( $v );
				}
				return $value;
			}
			return is_string( $value ) ? stripslashes( $value ) : $value;
		};
		Monkey\Functions\when( 'wp_unslash' )->alias( $stripslashes_deep );
		Monkey\Functions\when( 'sanitize_key' )->alias(
			static fn( $s ) => preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $s ) )
		);
		Monkey\Functions\when( 'absint' )->alias(
			static fn( $v ) => abs( (int) $v )
		);

		Monkey\Functions\when( 'current_user_can' )->justReturn( true );
		Monkey\Functions\when( 'wp_create_nonce' )->justReturn( 'test-nonce' );
		Monkey\Functions\when( 'admin_url' )->alias(
			static fn( $path = '' ) => 'http://example.test/wp-admin/' . ltrim( (string) $path, '/' )
		);
		Monkey\Functions\when( 'selected' )->alias(
			static function ( $a, $b = true, $echo = true ) {
				$out = $a == $b ? ' selected="selected"' : '';
				if ( $echo ) {
					echo $out;
				}
				return $out;
			}
		);

		Monkey\Functions\when( 'wp_nonce_field' )->alias(
			static function ( $action = -1, $name = '_wpnonce', $referer = true, $echo = true ) {
				$out = '<input type="hidden" name="' . $name . '" value="test-nonce" />';
				if ( $echo ) {
					echo $out;
				}
				return $out;
			}
		);

		Monkey\Functions\when( 'wp_style_is' )->justReturn( true );
		Monkey\Functions\when( 'wp_script_is' )->justReturn( true );
		Monkey\Functions\when( 'plugin_dir_path' )->alias(
			static fn( $file = '' ) => dirname( (string) $file ) . '/'
		);

		Monkey\Functions\when( 'mysql2date' )->alias(
			static function ( $format, $date, $translate = true ) {
				if ( empty( $date ) ) {
					return '';
				}
				$ts = strtotime( (string) $date );
				if ( false === $ts ) {
					return '';
				}
				return date( (string) $format, $ts );
			}
		);

		Monkey\Functions\when( 'get_userdata' )->alias(
			static function ( $id ) {
				$user              = new \stdClass();
				$user->ID          = (int) $id;
				$user->display_name = 'User ' . (int) $id;
				$user->user_login   = 'user_' . (int) $id;
				return $user;
			}
		);

		Monkey\Functions\when( 'wp_dropdown_users' )->alias(
			static function ( $args = array() ) {
				$args = is_array( $args ) ? $args : array();
				$name = isset( $args['name'] ) ? (string) $args['name'] : 'user';
				$id   = isset( $args['id'] ) ? (string) $args['id'] : $name;
				$echo = ! isset( $args['echo'] ) || $args['echo'];
				$out  = '<select name="' . $name . '" id="' . $id . '">'
					. '<option value="0">All</option>'
					. '</select>';
				if ( $echo ) {
					echo $out;
				}
				return $out;
			}
		);
	}

	protected function tearDown(): void {
		Monkey\tearDown();
		parent::tearDown();
	}
}
