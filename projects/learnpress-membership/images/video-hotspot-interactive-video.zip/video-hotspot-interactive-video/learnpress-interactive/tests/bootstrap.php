<?php
/**
 * PHPUnit bootstrap for learnpress-interactive unit tests.
 *
 * Mirrors LearnPress core pattern: Brain Monkey stubs WP functions, no WP core needed.
 */

declare( strict_types=1 );

// ── Composer autoloader (PSR-4: LearnPress\Interactive\ → inc/) ─────────────
require_once dirname( __DIR__ ) . '/vendor/autoload.php';

// ── Normalise timezone for deterministic datetime calculations ──────────────
date_default_timezone_set( 'UTC' );

// ── WordPress constants expected by classes under test ──────────────────────
defined( 'ABSPATH' )         || define( 'ABSPATH', '/fake/wp/' );
defined( 'WPINC' )           || define( 'WPINC', 'wp-includes' );
defined( 'WP_DEBUG' )        || define( 'WP_DEBUG', false );
defined( 'HOUR_IN_SECONDS' ) || define( 'HOUR_IN_SECONDS', 3600 );
defined( 'DAY_IN_SECONDS' )  || define( 'DAY_IN_SECONDS', 86400 );

// ── Addon constants (minimal set; mirror learnpress-interactive.php header) ──
defined( 'LP_ADDON_INTERACTIVE_FILE' )        || define( 'LP_ADDON_INTERACTIVE_FILE', dirname( __DIR__ ) . '/learnpress-interactive.php' );
defined( 'LP_ADDON_INTERACTIVE_PATH' )        || define( 'LP_ADDON_INTERACTIVE_PATH', dirname( __DIR__ ) );
defined( 'LP_ADDON_INTERACTIVE_VER' )         || define( 'LP_ADDON_INTERACTIVE_VER', '4.0.0-test' );
defined( 'LP_ADDON_INTERACTIVE_REQUIRE_VER' ) || define( 'LP_ADDON_INTERACTIVE_REQUIRE_VER', '4.3.2.7' );

// ── WordPress stub classes used in code paths ───────────────────────────────
if ( ! class_exists( 'WP_Error' ) ) {
	class WP_Error {
		public string $code;
		public string $message;
		public function __construct( string $code = '', string $message = '', $data = '' ) {
			$this->code    = $code;
			$this->message = $message;
		}
	}
}

// ── LP Core class stubs (NOT modifying LP Core; isolated test stubs) ────────
// Mirrors the surface area used by InteractiveFilter/InteractiveDB/Models.
if ( ! class_exists( '\\LearnPress\\Filters\\FilterBase' ) ) {
	require_once __DIR__ . '/Stubs/lp-core-stubs.php';
}

if ( ! class_exists( 'LP_Debug' ) ) {
	class LP_Debug {
		private static bool $debug_mode = false;
		public static function set_is_debug( bool $value ): void { self::$debug_mode = $value; }
		public static function is_debug(): bool { return self::$debug_mode; }
	}
}

if ( ! class_exists( 'LP_Helper' ) ) {
	class LP_Helper {
		/**
		 * Mirror real LP_Helper::json_decode behaviour: throw on invalid JSON.
		 *
		 * @throws \Exception
		 */
		public static function json_decode( string $json, bool $assoc = false ) {
			$result = \json_decode( $json, $assoc );
			if ( JSON_ERROR_NONE !== \json_last_error() ) {
				throw new \Exception( 'JSON error: ' . \json_last_error_msg() );
			}
			return $result;
		}
	}
}
