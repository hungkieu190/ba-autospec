import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadModule( relativePath, exportNames, context = {} ) {
	let source = fs.readFileSync( path.join( ROOT, relativePath ), 'utf8' );

	source = source
		.replace( /^import .*;$/gm, '' )
		.replace( /export class /g, 'class ' )
		.replace( /export function /g, 'function ' );

	const script = new vm.Script( `${ source }\n( { ${ exportNames.join( ', ' ) } } );` );
	return script.runInNewContext( Object.assign( { console }, context ) );
}

test( 'dirty autosave routes meta current slide and list changes separately', () => {
	const { createEmptySlide } = loadModule(
		'assets/src/js/admin/builder/slide/state/slideSchema.js',
		[ 'createEmptySlide' ]
	);
	const { SlideStore } = loadModule(
		'assets/src/js/admin/builder/slide/state/SlideStore.js',
		[ 'SlideStore' ],
		{ createEmptySlide }
	);
	const { SlideBuilder } = loadModule(
		'assets/src/js/admin/builder/slide/SlideBuilder.js',
		[ 'SlideBuilder' ],
		{
			TABLET_BREAKPOINT: 1180,
			CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
		}
	);

	let metaSaveCount = 0;
	const currentSlideSaveArgs = [];
	const slideListSaveArgs = [];
	const store = new SlideStore( {
		slides: [ Object.assign( createEmptySlide( 0, { background: '#ffffff' } ), { slideId: 11 } ) ],
	} );
	const builder = new SlideBuilder();
	builder.store = store;
	builder.autosave = {
		saveMetaDebounced:         () => metaSaveCount++,
		saveCurrentSlideDebounced: ( args ) => currentSlideSaveArgs.push( args ),
		saveSlideListDebounced:    ( args ) => slideListSaveArgs.push( args ),
	};
	builder.canvas = {
		addTextbox: ( options ) => {
			store.updateCurrentSlideContent( {
				version: '7.0.0',
				objects: [ Object.assign( { type: 'textbox' }, options ) ],
			} );
		},
	};
	builder.bindDirtyAutosave();

	store.setState( { zoom: 80 } );
	assert.equal( metaSaveCount, 0 );
	assert.equal( currentSlideSaveArgs.length, 0 );
	assert.equal( slideListSaveArgs.length, 0 );

	store.setState( { deckTitle: 'Renamed', dirty: true, dirtyScope: 'meta' } );
	assert.equal( metaSaveCount, 1 );
	assert.equal( currentSlideSaveArgs.length, 0 );
	assert.equal( slideListSaveArgs.length, 0 );

	store.updateCurrentSlide( { background: '#f8fafc' } );
	assert.equal( currentSlideSaveArgs.length, 1 );
	assert.equal( currentSlideSaveArgs[0].slideIndex, 0 );

	store.updateCurrentSlideContent( { version: '7.0.0', objects: [] } );
	assert.equal( currentSlideSaveArgs.length, 2 );

	builder.addText( { text: 'Lesson title' } );
	assert.equal( currentSlideSaveArgs.length, 3 );
	assert.equal( currentSlideSaveArgs[2].slideIndex, 0 );
	assert.equal( slideListSaveArgs.length, 0 );

	store.addNewSlide();
	assert.equal( slideListSaveArgs.length, 1 );
	assert.equal( slideListSaveArgs[0].listAction.type, 'create' );
	assert.equal( slideListSaveArgs[0].listAction.slideIndex, 1 );
	assert.equal( slideListSaveArgs[0].listAction.targetSlideClientId, store.get().slides[1].clientId );
	assert.equal( slideListSaveArgs[0].listAction.reorderAfterSuccess, false );

	store.setState( { dirty: false } );
	store.setSelectedElement( 'object-1', 'textbox' );
	assert.equal( metaSaveCount, 1 );
	assert.equal( currentSlideSaveArgs.length, 3 );
	assert.equal( slideListSaveArgs.length, 1 );

	builder.unbindDirtyAutosave();
	store.updateCurrentSlide( { background: '#ffffff' } );
	assert.equal( currentSlideSaveArgs.length, 3 );
} );
