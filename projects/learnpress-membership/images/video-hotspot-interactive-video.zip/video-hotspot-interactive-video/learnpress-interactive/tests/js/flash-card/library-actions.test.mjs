import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';
import { JSDOM } from 'jsdom';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadModule( relativePath, exportNames, context = {} ) {
	let source = fs.readFileSync( path.join( ROOT, relativePath ), 'utf8' );

	source = source
		.replace( /^import .*;$/gm, '' )
		.replace( /export function /g, 'function ' );

	const script = new vm.Script( `${ source }\n( { ${ exportNames.join( ', ' ) } } );` );
	return script.runInNewContext( Object.assign( { console, setTimeout, clearTimeout, FormData }, context ) );
}

test( 'flashcard library exposes preview clone and use actions separately', async () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const document = dom.window.document;
	const navigator = {
		clipboard: {
			writeText: () => Promise.resolve(),
		},
	};

	const { buildLibraryPanel } = loadModule(
		'assets/src/js/shared/flash-card/library-panel.js',
		[ 'buildLibraryPanel' ],
		{
			__,
			_n,
			sprintf,
			document,
			navigator,
			fetch: () => Promise.resolve( {
				json: () => Promise.resolve( {
					success: true,
					data:    {
						items: [
							{
								id:         34,
								title:      'Existing deck',
								item_count: 2,
								shortcode:  '[learnpress_single_interactive id=34]',
							},
						],
					},
				} ),
			} ),
		}
	);

	Object.defineProperty( globalThis, 'navigator', {
		value: {
			clipboard: {
				writeText: () => Promise.resolve(),
			},
		},
		configurable: true,
	} );

	const calls = [];
	const panel = buildLibraryPanel( {
		ajaxUrl:   '/wp-admin/admin-ajax.php',
		nonce:     'nonce',
		onPreview: ( id ) => calls.push( [ 'preview', id ] ),
		onClone:   ( id ) => calls.push( [ 'clone', id ] ),
		onUse:     ( id ) => calls.push( [ 'use', id ] ),
	} );

	document.body.appendChild( panel );
	panel._lpFcLibrary.ensureFetched();
	await new Promise( ( resolve ) => setTimeout( resolve, 0 ) );

	const buttons = Array.from( panel.querySelectorAll( 'button' ) );
	const previewBtn = buttons.find( ( button ) => button.textContent.trim() === 'Preview' );
	const cloneBtn = buttons.find( ( button ) => button.textContent.trim() === 'Clone' );
	const useBtn = buttons.find( ( button ) => button.textContent.trim() === 'Use' );

	assert.ok( previewBtn );
	assert.ok( cloneBtn );
	assert.ok( useBtn );

	previewBtn.click();
	cloneBtn.click();
	useBtn.click();

	assert.deepEqual( calls, [
		[ 'preview', 34 ],
		[ 'clone', 34 ],
		[ 'use', 34 ],
	] );
} );

function __( text ) {
	return text;
}

function _n( single, plural, count ) {
	return count === 1 ? single : plural;
}

function sprintf( format, ...args ) {
	let index = 0;
	return String( format ).replace( /%(?:(\d+)\$)?[sdf]/g, ( _match, position ) => {
		const argIndex = position ? parseInt( position, 10 ) - 1 : index++;
		return String( args[ argIndex ] ?? '' );
	} );
}
