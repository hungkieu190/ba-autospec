import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';
import { JSDOM } from 'jsdom';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadModule( context = {} ) {
	const domSource = fs.readFileSync(
		path.join( ROOT, 'assets/src/js/admin/builder/slide/utils/dom.js' ),
		'utf8'
	);
	const textToolbarSource = fs.readFileSync(
		path.join( ROOT, 'assets/src/js/admin/builder/slide/ui/toolbar/TextToolbar.js' ),
		'utf8'
	);
	const toolbarSource = fs.readFileSync(
		path.join( ROOT, 'assets/src/js/admin/builder/slide/ui/Toolbar.js' ),
		'utf8'
	);

	let source = domSource + '\n' + textToolbarSource + '\n' + toolbarSource;
	source = source
		.replace( /^import .*;$/gm, '' )
		.replace( /export class /g, 'class ' )
		.replace( /export function /g, 'function ' );

	const script = new vm.Script( `${ source }\n( { ContentToolbar: Toolbar } );` );
	return script.runInNewContext( Object.assign( { console }, context ) );
}

function createStore( state ) {
	const listeners = new Set();
	let currentState = Object.assign(
		{
			selectedElementId: null,
			selectedElementType: null,
			selectedElementProps: {},
		},
		state || {}
	);

	return {
		get: () => currentState,
		setState: ( patch ) => {
			currentState = Object.assign( {}, currentState, patch );
			listeners.forEach( ( listener ) => listener( currentState ) );
		},
		subscribe: ( listener ) => {
			listeners.add( listener );
			return () => listeners.delete( listener );
		},
	};
}

test( 'content toolbar shows text controls for selected text objects', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="toolbar"></div></body></html>' );
	const { ContentToolbar } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const store = createStore();
	const toolbar = new ContentToolbar( store );

	toolbar.mount( dom.window.document.getElementById( 'toolbar' ) );
	assert.equal( dom.window.document.querySelector( '[data-control="bold"]' ), null );

	store.setState( { selectedElementId: 'obj-1', selectedElementType: 'i-text' } );
	assert.notEqual( dom.window.document.querySelector( '[data-control="bold"]' ), null );

	store.setState( { selectedElementId: 'obj-2', selectedElementType: 'textbox' } );
	assert.notEqual( dom.window.document.querySelector( '[data-control="bold"]' ), null );
} );

test( 'content toolbar text controls call injected callbacks', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="toolbar"></div></body></html>' );
	const { ContentToolbar } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const calls = [];
	const toolbar = new ContentToolbar(
		createStore( { selectedElementId: 'obj-1', selectedElementType: 'textbox' } ),
		{
			onUpdateText: ( patch ) => calls.push( patch ),
		}
	);

	toolbar.mount( dom.window.document.getElementById( 'toolbar' ) );
	dom.window.document.querySelector( '[data-control="italic"]' ).click();
	const sizeInput = dom.window.document.querySelector( '[data-control="font-size"]' );
	sizeInput.value = '64';
	sizeInput.dispatchEvent( new dom.window.Event( 'change', { bubbles: true } ) );

	assert.deepEqual( JSON.parse( JSON.stringify( calls ) ), [
		{ fontStyle: 'italic' },
		{ fontSize: 64 },
	] );
} );

test( 'content toolbar color picker updates text while dragging', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="toolbar"></div></body></html>' );
	const { ContentToolbar } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const calls = [];
	const toolbar = new ContentToolbar(
		createStore( {
			selectedElementId: 'obj-1',
			selectedElementType: 'textbox',
			selectedElementProps: {
				fill: '#111111',
			},
		} ),
		{
			onUpdateText: ( patch ) => calls.push( patch ),
		}
	);

	toolbar.mount( dom.window.document.getElementById( 'toolbar' ) );
	const colorInput = dom.window.document.querySelector( '.lp-interactive-slide-editor__content-toolbar-color-input' );
	colorInput.value = '#ff00aa';
	colorInput.dispatchEvent( new dom.window.Event( 'input', { bubbles: true } ) );

	assert.deepEqual( JSON.parse( JSON.stringify( calls ) ), [
		{ fill: '#ff00aa' },
	] );
} );

test( 'content toolbar keeps the color input open when selected fill changes', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="toolbar"></div></body></html>' );
	const { ContentToolbar } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const store = createStore( {
		selectedElementId: 'obj-1',
		selectedElementType: 'textbox',
		selectedElementProps: {
			fill: '#111111',
		},
	} );
	const toolbar = new ContentToolbar( store );

	toolbar.mount( dom.window.document.getElementById( 'toolbar' ) );
	const firstColorInput = dom.window.document.querySelector( '.lp-interactive-slide-editor__content-toolbar-color-input' );

	store.setState( {
		selectedElementProps: {
			fill: '#ff00aa',
		},
	} );

	assert.equal( dom.window.document.querySelector( '.lp-interactive-slide-editor__content-toolbar-color-input' ), firstColorInput );
	assert.equal( firstColorInput.value, '#ff00aa' );
	assert.equal(
		dom.window.document.querySelector( '[data-control="text-color"]' ).style.getPropertyValue( '--lp-se-toolbar-color' ),
		'#ff00aa'
	);
} );

test( 'content toolbar ignores stale color events after selecting another text object', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="toolbar"></div></body></html>' );
	const { ContentToolbar } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const calls = [];
	const store = createStore( {
		selectedElementId: 'obj-1',
		selectedElementType: 'textbox',
		selectedElementProps: {
			fill: '#111111',
		},
	} );
	const toolbar = new ContentToolbar( store, {
		onUpdateText: ( patch ) => calls.push( {
			elementId: store.get().selectedElementId,
			patch,
		} ),
	} );

	toolbar.mount( dom.window.document.getElementById( 'toolbar' ) );
	const oldColorInput = dom.window.document.querySelector( '.lp-interactive-slide-editor__content-toolbar-color-input' );
	oldColorInput.value = '#ff00aa';
	oldColorInput.dispatchEvent( new dom.window.Event( 'input', { bubbles: true } ) );

	store.setState( {
		selectedElementId: 'obj-2',
		selectedElementType: 'textbox',
		selectedElementProps: {
			fill: '#222222',
		},
	} );

	oldColorInput.dispatchEvent( new dom.window.Event( 'change', { bubbles: true } ) );

	assert.deepEqual( JSON.parse( JSON.stringify( calls ) ), [
		{
			elementId: 'obj-1',
			patch:     { fill: '#ff00aa' },
		},
	] );
} );

test( 'content toolbar renders selected text props with standalone-style controls', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="toolbar"></div></body></html>' );
	const { ContentToolbar } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const toolbar = new ContentToolbar(
		createStore( {
			selectedElementId: 'obj-1',
			selectedElementType: 'textbox',
			selectedElementProps: {
				fontFamily: 'Inter',
				fontSize:   64,
				fill:       '#ffffff',
				fontWeight: 'bold',
				textAlign:  'center',
			},
		} )
	);

	toolbar.mount( dom.window.document.getElementById( 'toolbar' ) );

	assert.equal( dom.window.document.querySelector( 'select[data-control="font-family"]' ), null );
	assert.equal( dom.window.document.querySelector( 'select[data-control="align"]' ), null );
	assert.equal( dom.window.document.querySelector( '[data-control="font-family"]' ).textContent.includes( 'Inter' ), true );
	assert.equal( dom.window.document.querySelector( '[data-control="font-size"]' ).value, '64' );
	assert.equal( dom.window.document.querySelector( '[data-control="bold"]' ).classList.contains( 'is-active' ), true );
	assert.equal( dom.window.document.querySelector( '[data-control="align-center"]' ).classList.contains( 'is-active' ), true );
	assert.equal(
		dom.window.document.querySelector( '[data-control="text-color"]' ).style.getPropertyValue( '--lp-se-toolbar-color' ),
		'#ffffff'
	);
} );

test( 'content toolbar renders formatting controls with registered SVG icons', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="toolbar"></div></body></html>' );
	const usedIcons = [];
	const { ContentToolbar } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		icon: ( name ) => {
			usedIcons.push( name );
			const node = dom.window.document.createElement( 'span' );
			node.dataset.icon = name;
			return node;
		},
	} );
	const toolbar = new ContentToolbar(
		createStore( {
			selectedElementId: 'obj-1',
			selectedElementType: 'i-text',
			selectedElementProps: {
				fontFamily: 'Inter',
				fontSize:   64,
				fill:       '#ffffff',
				fontWeight: 'bold',
				textAlign:  'center',
			},
		} )
	);

	toolbar.mount( dom.window.document.getElementById( 'toolbar' ) );

	[
		'bold',
		'italic',
		'underline',
			'strike',
			'minus',
			'plus',
			'align-left',
			'align-center',
			'align-right',
		].forEach( ( name ) => {
			assert.equal( usedIcons.includes( name ), true, name );
			assert.notEqual( dom.window.document.querySelector( '[data-icon="' + name + '"]' ), null );
		} );

		assert.equal( dom.window.document.querySelector( '[data-control="link"]' ), null );
	} );

test( 'content toolbar opens spacing popup and updates text spacing controls', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="toolbar"></div></body></html>' );
	const { ContentToolbar } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		icon: ( name ) => {
			const node = dom.window.document.createElement( 'span' );
			node.dataset.icon = name;
			return node;
		},
	} );
	const calls = [];
	const toolbar = new ContentToolbar(
		createStore( {
			selectedElementId: 'obj-1',
			selectedElementType: 'i-text',
			selectedElementProps: {
				charSpacing: 120,
				lineHeight:  1.4,
			},
		} ),
		{
			onUpdateText: ( patch ) => calls.push( patch ),
		}
	);

	toolbar.mount( dom.window.document.getElementById( 'toolbar' ) );
	const spacingControl = dom.window.document.querySelector( '[data-control="text-spacing"]' );
	spacingControl.getBoundingClientRect = () => ( {
		left:   120,
		bottom: 48,
		width:  32,
	} );
	spacingControl.click();

	const menu = dom.window.document.querySelector( '[data-control="text-spacing-menu"]' );
	assert.notEqual( menu, null );
	assert.equal( menu.style.position, 'fixed' );
	assert.equal( menu.style.top, '54px' );

	const charRange = dom.window.document.querySelector( '[data-control="char-spacing-range"]' );
	const lineRange = dom.window.document.querySelector( '[data-control="line-height-range"]' );
	assert.equal( charRange.min, '-200' );
	assert.equal( charRange.max, '800' );
	assert.equal( charRange.value, '120' );
	assert.equal( lineRange.min, '0.5' );
	assert.equal( lineRange.max, '2.5' );
	assert.equal( lineRange.step, '0.1' );
	assert.equal( lineRange.value, '1.4' );
	assert.notEqual( charRange.style.getPropertyValue( '--lp-se-spacing-progress' ), '' );

	charRange.value = '259';
	charRange.dispatchEvent( new dom.window.Event( 'input', { bubbles: true } ) );
	charRange.dispatchEvent( new dom.window.Event( 'change', { bubbles: true } ) );
	assert.equal( dom.window.document.querySelector( '[data-control="char-spacing-number"]' ).value, '259' );

	const lineNumber = dom.window.document.querySelector( '[data-control="line-height-number"]' );
	lineNumber.value = '1.1';
	lineNumber.dispatchEvent( new dom.window.Event( 'change', { bubbles: true } ) );
	assert.equal( lineRange.value, '1.1' );

	assert.deepEqual( JSON.parse( JSON.stringify( calls ) ), [
		{ charSpacing: 259 },
		{ lineHeight: 1.1 },
	] );
} );

test( 'content toolbar font family control opens a dropdown before applying a font', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="toolbar"></div></body></html>' );
	const { ContentToolbar } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const calls = [];
	const toolbar = new ContentToolbar(
		createStore( {
			selectedElementId: 'obj-1',
			selectedElementType: 'textbox',
			selectedElementProps: {
				fontFamily: 'Inter',
			},
		} ),
		{
			onUpdateText: ( patch ) => calls.push( patch ),
		}
	);

	toolbar.mount( dom.window.document.getElementById( 'toolbar' ) );

	const fontControl = dom.window.document.querySelector( '[data-control="font-family"]' );
	fontControl.click();

	assert.deepEqual( calls, [] );
	assert.equal( toolbar.store.get().activeTab, 'font' );
} );

test( 'content toolbar closes popup when another element is selected', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="toolbar"></div></body></html>' );
	const { ContentToolbar } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const store = createStore( {
		selectedElementId: 'obj-1',
		selectedElementType: 'textbox',
		selectedElementProps: {
			fontFamily: 'Inter',
		},
	} );
	const toolbar = new ContentToolbar( store );

	toolbar.mount( dom.window.document.getElementById( 'toolbar' ) );
	dom.window.document.querySelector( '[data-control="bold"]' ).click();
	assert.notEqual( dom.window.document.querySelector( '[data-control="font-variant-menu"]' ), null );

	store.setState( {
		selectedElementId: 'obj-2',
		selectedElementType: 'textbox',
		selectedElementProps: {
			fontFamily: 'Georgia',
		},
	} );

	assert.equal( dom.window.document.querySelector( '[data-control="font-variant-menu"]' ), null );
} );

test( 'content toolbar closes popup after another toolbar control is clicked', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="toolbar"></div></body></html>' );
	const { ContentToolbar } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const calls = [];
	const toolbar = new ContentToolbar(
		createStore( {
			selectedElementId: 'obj-1',
			selectedElementType: 'textbox',
			selectedElementProps: {
				fontFamily: 'Inter',
			},
		} ),
		{
			onUpdateText: ( patch ) => calls.push( patch ),
		}
	);

	toolbar.mount( dom.window.document.getElementById( 'toolbar' ) );
	dom.window.document.querySelector( '[data-control="text-spacing"]' ).click();
	assert.notEqual( dom.window.document.querySelector( '[data-control="text-spacing-menu"]' ), null );

	dom.window.document.querySelector( '[data-control="italic"]' ).click();

	assert.deepEqual( JSON.parse( JSON.stringify( calls ) ), [
		{ fontStyle: 'italic' },
	] );
	assert.equal( dom.window.document.querySelector( '[data-control="text-spacing-menu"]' ), null );
} );

test( 'content toolbar closes popup when clicking outside', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="toolbar"></div><button id="outside"></button></body></html>' );
	const { ContentToolbar } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const toolbar = new ContentToolbar(
		createStore( {
			selectedElementId: 'obj-1',
			selectedElementType: 'textbox',
			selectedElementProps: {
				fontFamily: 'Inter',
			},
		} )
	);

	toolbar.mount( dom.window.document.getElementById( 'toolbar' ) );
	dom.window.document.querySelector( '[data-control="bold"]' ).click();
	assert.notEqual( dom.window.document.querySelector( '[data-control="font-variant-menu"]' ), null );

	dom.window.document.getElementById( 'outside' ).dispatchEvent( new dom.window.Event( 'pointerdown', { bubbles: true } ) );

	assert.equal( dom.window.document.querySelector( '[data-control="font-variant-menu"]' ), null );
} );

test( 'content toolbar keeps existing controls across unrelated store updates', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="toolbar"></div></body></html>' );
	const { ContentToolbar } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const store = createStore( {
		selectedElementId: 'obj-1',
		selectedElementType: 'textbox',
		selectedElementProps: {
			fontFamily: 'Inter',
			fontSize:   56,
		},
	} );
	const toolbar = new ContentToolbar( store );

	toolbar.mount( dom.window.document.getElementById( 'toolbar' ) );
	const firstBoldButton = dom.window.document.querySelector( '[data-control="bold"]' );

	store.setState( { dirty: true, dirtyRevision: 1, zoom: 84 } );

	assert.equal( dom.window.document.querySelector( '[data-control="bold"]' ), firstBoldButton );
} );
