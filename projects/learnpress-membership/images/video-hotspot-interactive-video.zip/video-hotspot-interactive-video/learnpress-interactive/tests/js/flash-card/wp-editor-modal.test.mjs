import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';
import { JSDOM } from 'jsdom';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadModalModule( context = {} ) {
	let source = fs.readFileSync(
		path.join( ROOT, 'assets/src/js/admin/wp-editor/FlashCardModal.js' ),
		'utf8'
	);

	source = source
		.replace( /import[\s\S]*?from\s+['"][^'"]+['"];?/g, '' )
		.replace( /export class FlashCardModal/, 'class FlashCardModal' );

	const script = new vm.Script( `${ source }\n( { FlashCardModal } );` );
	return script.runInNewContext( Object.assign( {
		console,
		document: context.document,
		window:   context.window,
		Sortable: {
			create: () => ( { destroy() {} } ),
		},
		SweetAlert: {
			fire: () => {},
		},
		buildFlashCardSettingsPanel: () => context.document.createElement( 'div' ),
		readFlashCardSettings: () => ( {} ),
		mountFlashCardPreview: () => ( { render() {}, schedule() {}, destroy() {} } ),
		buildFlashCardEditorCard: () => context.document.createElement( 'div' ),
		serializeFlashCardEditorCard: () => ( {} ),
		defaultCardData: () => ( {
			front: { title: '', image_id: 0, image_url: '', subtitle: '' },
			back:  { title: '', image_id: 0, image_url: '', subtitle: '' },
		} ),
		updateCardNumbers: () => {},
		initCardEditors: () => {},
		destroyCardEditors: () => {},
		buildLibraryPanel: () => context.document.createElement( 'div' ),
		__,
		_n,
		sprintf,
		lpiConfirm: () => Promise.resolve( false ),
		SWAL_ICON_DUPLICATE: '',
		fetch: () => Promise.resolve(),
		FormData: context.window.FormData,
		setTimeout,
		clearTimeout,
	}, context ) );
}

test( 'wp editor modal library settings preserve card colors', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { FlashCardModal } = loadModalModule( {
		document: dom.window.document,
		window:   dom.window,
	} );
	const modal = new FlashCardModal();

	const settings = modal._settingsFromDeckPayload( {
		parent: {
			extra_data: {
				layout:           'grid',
				show_progress:    0,
				shuffle:          1,
				require_flip:     0,
				text_color:       '#1f2937',
				background_color: '#f8fafc',
			},
		},
	} );

	assert.deepEqual( plain( settings ), {
		layout:           'grid',
		show_progress:    0,
		shuffle:          1,
		require_flip:     0,
		text_color:       '#1f2937',
		background_color: '#f8fafc',
	} );
} );

test( 'wp editor modal loads library deck colors into settings panel', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	let capturedInitial = null;
	const { FlashCardModal } = loadModalModule( {
		document: dom.window.document,
		window:   dom.window,
		buildFlashCardSettingsPanel: ( options ) => {
			capturedInitial = options.initial;
			return dom.window.document.createElement( 'div' );
		},
	} );
	const modal = new FlashCardModal();
	modal.deckNameInput = dom.window.document.createElement( 'input' );
	modal.cardList = dom.window.document.createElement( 'div' );
	modal.settingsPanelEl = dom.window.document.createElement( 'div' );
	dom.window.document.body.appendChild( modal.settingsPanelEl );
	modal._addCard = () => {};
	modal._updateNumbers = () => {};
	modal._updateCardCount = () => {};
	modal._schedulePreviewUpdate = () => {};

	modal._loadDeckIntoEditor( {
		parent: {
			title:      'Deck',
			extra_data: {
				layout:           'grid',
				show_progress:    0,
				shuffle:          1,
				require_flip:     0,
				text_color:       '#1f2937',
				background_color: '#f8fafc',
			},
		},
		items: [],
	} );

	assert.deepEqual( plain( capturedInitial ), {
		layout:           'grid',
		show_progress:    0,
		shuffle:          1,
		require_flip:     0,
		text_color:       '#1f2937',
		background_color: '#f8fafc',
	} );
} );

function __( text ) {
	return text;
}

function _n( single, plural, count ) {
	return count === 1 ? single : plural;
}

function sprintf( format, ...args ) {
	let index = 0;
	return String( format ).replace( /%(?:(\d+)\$)?[sdf]/g, ( _match, position ) => {
		const argIndex = position ? parseInt( position, 10 ) - 1 : index++;
		return String( args[ argIndex ] ?? '' );
	} );
}

function plain( value ) {
	return JSON.parse( JSON.stringify( value ) );
}
