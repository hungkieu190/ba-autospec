import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';
import { JSDOM } from 'jsdom';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadModule( context = {} ) {
	const domSource = fs.readFileSync(
		path.join( ROOT, 'assets/src/js/admin/builder/slide/utils/dom.js' ),
		'utf8'
	);
	const panelSources = [
		'assets/src/js/admin/builder/slide/panels/left-panel/section.js',
		'assets/src/js/admin/builder/slide/panels/left-panel/TextPanel.js',
		'assets/src/js/admin/builder/slide/panels/left-panel/FontPanel.js',
		'assets/src/js/admin/builder/slide/panels/left-panel/UploadsPanel.js',
		'assets/src/js/admin/builder/slide/panels/left-panel/BackgroundPanel.js',
		'assets/src/js/admin/builder/slide/panels/LeftPanel.js',
	].map( ( file ) => fs.readFileSync( path.join( ROOT, file ), 'utf8' ) );

	let source = domSource + '\n' + panelSources.join( '\n' );
	source = source
		.replace( /^import .*;$/gm, '' )
		.replace( /export class /g, 'class ' )
		.replace( /export function /g, 'function ' );

	const script = new vm.Script( `${ source }\n( { LeftPanel } );` );
	return script.runInNewContext( Object.assign( { console }, context ) );
}

function createStore() {
	let state = { activeTab: 'text', selectedElementProps: {} };
	const listeners = new Set();

	return {
		get: () => state,
		setState: ( patch ) => {
			state = Object.assign( {}, state, patch );
			listeners.forEach( ( listener ) => listener( state ) );
		},
		subscribe: ( listener ) => {
			listeners.add( listener );
			return () => listeners.delete( listener );
		},
	};
}

test( 'left panel add text action calls the injected text callback', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="panel"></div></body></html>' );
	const { LeftPanel } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const calls = [];
	const panel = new LeftPanel( createStore(), {
		onAddText: ( options ) => calls.push( options ),
	} );

	panel.mount( dom.window.document.getElementById( 'panel' ) );
	dom.window.document.querySelector( '.lp-interactive-slide-editor__btn--secondary' ).click();

	assert.deepEqual( JSON.parse( JSON.stringify( calls ) ), [ {
		text:         'The content of your text',
		enterEditing: true,
		selectAll:    true,
	} ] );
} );

test( 'left panel shows applying state while a font variant is applied to the canvas', async () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="panel"></div></body></html>' );
	const { LeftPanel } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		setTimeout,
		clearTimeout,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const store = createStore();
	store.setState( {
		activeTab: 'font',
		selectedElementProps: { fontFamily: 'Inter', fontWeight: 400, fontStyle: 'normal' },
	} );

	let resolveApply;
	const panel = new LeftPanel( store, {
		fontService: {
			listFonts: () => Promise.resolve( [
				{ family: 'Inter', category: 'system', variants: [ 'regular', '700' ] },
			] ),
		},
		onSelectFontVariant: () => new Promise( ( resolve ) => {
			resolveApply = resolve;
		} ),
	} );

	panel.mount( dom.window.document.getElementById( 'panel' ) );
	await Promise.resolve();
	await Promise.resolve();
	await new Promise( ( resolve ) => setTimeout( resolve, 0 ) );

	dom.window.document.querySelector( '[data-font-family="Inter"]' ).click();
	dom.window.document.querySelectorAll( '.lp-interactive-slide-editor__content-toolbar-font-variant' )[1].click();

	assert.equal(
		dom.window.document.querySelector( '[data-control="font-apply-status"]' ).textContent,
		'Applying...'
	);

	resolveApply();
	await Promise.resolve();
	await Promise.resolve();
	await new Promise( ( resolve ) => setTimeout( resolve, 0 ) );

	assert.equal( dom.window.document.querySelector( '[data-control="font-apply-status"]' ), null );
} );

test( 'left panel preserves font list scroll when expanding a font family', async () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="panel"></div></body></html>' );
	const { LeftPanel } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		setTimeout,
		clearTimeout,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const store = createStore();
	store.setState( { activeTab: 'font' } );
	const fonts = Array.from( { length: 30 }, ( _, index ) => ( {
		family:   'Font ' + index,
		category: 'google',
		variants: [ 'regular', '700' ],
	} ) );
	const panel = new LeftPanel( store, {
		fontService: {
			listFonts: () => Promise.resolve( fonts ),
		},
	} );

	panel.mount( dom.window.document.getElementById( 'panel' ) );
	await Promise.resolve();
	await Promise.resolve();
	await new Promise( ( resolve ) => setTimeout( resolve, 0 ) );

	const body = dom.window.document.querySelector( '.lp-interactive-slide-editor__left-panel-body' );
	body.scrollTop = 420;
	dom.window.document.querySelector( '[data-font-family="Font 20"]' ).click();

	const nextBody = dom.window.document.querySelector( '.lp-interactive-slide-editor__left-panel-body' );
	assert.equal( nextBody.scrollTop, 420 );
	assert.notEqual( dom.window.document.querySelector( '.lp-interactive-slide-editor__content-toolbar-font-variants' ), null );
} );

test( 'left panel refreshes fonts after applying a Google font so it appears in System immediately', async () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="panel"></div></body></html>' );
	const { LeftPanel } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		setTimeout,
		clearTimeout,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const store = createStore();
	store.setState( {
		activeTab: 'font',
		selectedElementProps: { fontFamily: 'Inter', fontWeight: 400, fontStyle: 'normal' },
	} );
	let fonts = [
		{ family: 'Inter', category: 'system', variants: [ 'regular', '700' ] },
		{ family: 'Roboto', category: 'sans-serif', variants: [ 'regular', '700' ] },
	];
	const panel = new LeftPanel( store, {
		fontService: {
			listFonts: () => Promise.resolve( fonts ),
		},
		onSelectFontVariant: () => {
			fonts = [
				{ family: 'Inter', category: 'system', variants: [ 'regular', '700' ] },
				{ family: 'Roboto', category: 'system', cached: true, variants: [ 'regular', '700' ] },
				{ family: 'Roboto', category: 'sans-serif', variants: [ 'regular', '700' ] },
			];
			return Promise.resolve();
		},
	} );

	panel.mount( dom.window.document.getElementById( 'panel' ) );
	await Promise.resolve();
	await Promise.resolve();
	await new Promise( ( resolve ) => setTimeout( resolve, 0 ) );

	dom.window.document.querySelector( '[data-font-family="Roboto"]' ).click();
	dom.window.document.querySelector( '.lp-interactive-slide-editor__content-toolbar-font-variant' ).click();
	await Promise.resolve();
	await Promise.resolve();
	await new Promise( ( resolve ) => setTimeout( resolve, 0 ) );

	const groups = Array.from( dom.window.document.querySelectorAll( '.lp-interactive-slide-editor__content-toolbar-font-group' ) );
	const systemGroup = groups.find( ( group ) => group.querySelector( '.lp-interactive-slide-editor__content-toolbar-font-title' ).textContent === 'System' );
	const sansSerifGroup = groups.find( ( group ) => group.querySelector( '.lp-interactive-slide-editor__content-toolbar-font-title' ).textContent === 'Sans Serif' );

	assert.match( systemGroup.textContent, /Roboto/ );
	assert.match( sansSerifGroup.textContent, /Roboto/ );
} );

test( 'left panel keeps duplicate font rows independently expanded and active', async () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="panel"></div></body></html>' );
	const { LeftPanel } = loadModule( {
		document: dom.window.document,
		Node: dom.window.Node,
		setTimeout,
		clearTimeout,
		icon: ( name ) => dom.window.document.createTextNode( name ),
	} );
	const store = createStore();
	store.setState( {
		activeTab: 'font',
		selectedElementProps: { fontFamily: 'Roboto', fontWeight: 400, fontStyle: 'normal' },
	} );
	const panel = new LeftPanel( store, {
		fontService: {
			listFonts: () => Promise.resolve( [
				{ family: 'Roboto', category: 'system', cached: true, variants: [ 'regular', '700' ] },
				{ family: 'Roboto', category: 'sans-serif', variants: [ 'regular', '700' ] },
			] ),
		},
	} );

	panel.mount( dom.window.document.getElementById( 'panel' ) );
	await Promise.resolve();
	await Promise.resolve();
	await new Promise( ( resolve ) => setTimeout( resolve, 0 ) );

	dom.window.document.querySelector( '[data-font-family="Roboto"]' ).click();

	assert.equal(
		dom.window.document.querySelectorAll( '.lp-interactive-slide-editor__content-toolbar-font-variants' ).length,
		1
	);
	assert.equal(
		dom.window.document.querySelectorAll( '.lp-interactive-slide-editor__content-toolbar-select-option.is-active' ).length,
		1
	);
} );
