import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';
import { JSDOM } from 'jsdom';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadModule( relativePath, exportNames, context = {} ) {
	let source = fs.readFileSync( path.join( ROOT, relativePath ), 'utf8' );

	source = source
		.replace( /^import .*;$/gm, '' )
		.replace( /export function /g, 'function ' );

	const script = new vm.Script( `${ source }\n( { ${ exportNames.join( ', ' ) } } );` );
	return script.runInNewContext( Object.assign( {
		console,
		__,
		iconNode: () => null,
	}, context ) );
}

test( 'flashcard settings panel reads text and background colors', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const document = dom.window.document;

	const {
		buildFlashCardSettingsPanel,
		readFlashCardSettings,
	} = loadModule(
		'assets/src/js/shared/flash-card/settings-panel.js',
		[ 'buildFlashCardSettingsPanel', 'readFlashCardSettings' ],
		{ document, window: dom.window }
	);

	const panel = buildFlashCardSettingsPanel( {
		initial: {
			layout:           'grid',
			show_progress:    1,
			shuffle:          0,
			require_flip:     1,
			text_color:       '#111827',
			background_color: '#f8fafc',
		},
	} );
	document.body.appendChild( panel );

	assert.equal(
		panel.querySelector( 'input[data-key="text_color"]' ).value,
		'#111827'
	);
	assert.equal(
		panel.querySelector( 'input[data-key="background_color"]' ).value,
		'#f8fafc'
	);

	const settings = plain( readFlashCardSettings( panel ) );

	assert.deepEqual( settings, {
		layout:           'grid',
		show_progress:    1,
		shuffle:          0,
		require_flip:     1,
		text_color:       '#111827',
		background_color: '#f8fafc',
	} );
} );

function __( text ) {
	return text;
}

function plain( value ) {
	return JSON.parse( JSON.stringify( value ) );
}
