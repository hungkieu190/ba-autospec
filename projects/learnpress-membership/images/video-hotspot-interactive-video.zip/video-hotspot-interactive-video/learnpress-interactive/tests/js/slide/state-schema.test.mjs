import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function plain( value ) {
	return JSON.parse( JSON.stringify( value ) );
}

function loadModule( relativePath, exportNames, context = {} ) {
	let source = fs.readFileSync( path.join( ROOT, relativePath ), 'utf8' );

	source = source
		.replace( /^import .*;$/gm, '' )
		.replace( /export class /g, 'class ' )
		.replace( /export function /g, 'function ' );

	const script = new vm.Script( `${ source }\n( { ${ exportNames.join( ', ' ) } } );` );
	return script.runInNewContext( Object.assign( { console }, context ) );
}

test( 'loads empty saved rows as one empty v2 slide', () => {
	const { loadSlidesFromSavedRows } = loadModule(
		'assets/src/js/admin/builder/slide/state/slideSchema.js',
		[ 'loadSlidesFromSavedRows' ]
	);

	assert.deepEqual( plain( loadSlidesFromSavedRows( null, { background: '#ffffff' } ) ), [
		{
			clientId:   's1',
			content:    { version: '', objects: [] },
			background: '#ffffff',
		},
	] );
} );

test( 'loads saved slide IDs for single-slide autosave', () => {
	const { loadSlidesFromSavedRows } = loadModule(
		'assets/src/js/admin/builder/slide/state/slideSchema.js',
		[ 'loadSlidesFromSavedRows' ]
	);

	assert.deepEqual(
		plain( loadSlidesFromSavedRows( [
			{
				ID:         55,
				content:    { version: '', objects: [] },
				extra_data: { width: 842, height: 595 },
			},
		] ) )[0].slideId,
		55
	);
} );

test( 'builds slide payload with Fabric content and slide dimensions', () => {
	const { buildSlidesForSave } = loadModule(
		'assets/src/js/admin/builder/slide/state/slideSchema.js',
		[ 'buildSlidesForSave' ]
	);

	assert.deepEqual(
		plain( buildSlidesForSave(
			[
				{
					clientId:   's1',
					content:    { version: '7.0.0', objects: [ { type: 'textbox', text: 'Hello' } ] },
					background: '#f8fafc',
				},
			],
			{ width: 842, height: 595, background: '#ffffff' }
		) ),
		[
			{
				content:       { version: '7.0.0', objects: [ { type: 'textbox', text: 'Hello' } ] },
				extra_data:    {
					width:  842,
					height: 595,
				},
			},
		]
	);
} );

test( 'builds empty slide settings payload for the parent row', () => {
	const { buildSlideSettingsForSave } = loadModule(
		'assets/src/js/admin/builder/slide/state/slideSchema.js',
		[ 'buildSlideSettingsForSave' ]
	);

	assert.deepEqual(
		plain( buildSlideSettingsForSave() ),
		{}
	);
} );

test( 'slide store mutates slides and marks them dirty', () => {
	const { createEmptySlide } = loadModule(
		'assets/src/js/admin/builder/slide/state/slideSchema.js',
		[ 'createEmptySlide' ]
	);
	const { SlideStore } = loadModule(
		'assets/src/js/admin/builder/slide/state/SlideStore.js',
		[ 'SlideStore' ],
		{ createEmptySlide }
	);

	const store = new SlideStore( {
		slides: [
			Object.assign( createEmptySlide( 0, { background: '#ffffff' } ), { slideId: 11 } ),
			Object.assign( createEmptySlide( 1, { background: '#ffffff' } ), {
				slideId:  12,
				content: { version: '7.0.0', objects: [ { type: 'textbox', text: 'Second' } ] },
			} ),
		],
		dirty: false,
	} );

	store.updateCurrentSlideContent( { version: '7.0.0', objects: [ { type: 'textbox', text: 'First' } ] } );
	assert.equal( store.get().dirty, true );
	assert.equal( store.get().slides[0].content.objects[0].text, 'First' );

	store.duplicateSlide( 0 );
	assert.equal( store.get().slides.length, 3 );
	assert.equal( store.get().currentIdx, 1 );
	assert.notEqual( store.get().slides[0].clientId, store.get().slides[1].clientId );
	assert.equal( Number( store.get().slides[1].slideId || 0 ), 0 );
	assert.equal( store.get().dirtyListAction.type, 'create' );

	store.reorderSlides( 1, 2 );
	assert.equal( store.get().currentIdx, 2 );
	assert.equal( store.get().slides[2].content.objects[0].text, 'First' );
	assert.equal( store.get().dirtyListAction.type, 'full' );

	store.deleteSlide( 2 );
	store.deleteSlide( 1 );
	store.deleteSlide( 0 );
	assert.equal( store.get().slides.length, 1 );
	assert.deepEqual( plain( store.get().slides[0].content ), { version: '', objects: [] } );

	store.setSelectedElement( 'object-1', 'textbox' );
	assert.equal( store.get().selectedElementId, 'object-1' );
	assert.equal( store.get().selectedElementType, 'textbox' );
} );
