import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';
import { JSDOM } from 'jsdom';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadModule( relativePath, exportNames, context = {} ) {
	let source = fs.readFileSync( path.join( ROOT, relativePath ), 'utf8' );

	source = source
		.replace( /^import .*;$/gm, '' )
		.replace( /export function /g, 'function ' );

	const script = new vm.Script( `${ source }\n( { ${ exportNames.join( ', ' ) } } );` );
	return script.runInNewContext( Object.assign( {
		console,
		setTimeout,
		clearTimeout,
		__,
		sprintf,
		appendIcon: () => {},
	}, context ) );
}

test( 'flashcard editor default data has title image and subtitle per side', () => {
	const { defaultCardData } = loadModule(
		'assets/src/js/shared/flash-card/card-editor.js',
		[ 'defaultCardData' ]
	);

	assert.deepEqual( plain( defaultCardData() ), {
		front: { title: '', image_id: 0, image_url: '', subtitle: '' },
		back:  { title: '', image_id: 0, image_url: '', subtitle: '' },
	} );
} );

test( 'flashcard editor serializes title image and subtitle from each side', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const document = dom.window.document;
	const window = dom.window;

	const {
		buildFlashCardEditorCard,
		serializeFlashCardEditorCard,
	} = loadModule(
		'assets/src/js/shared/flash-card/card-editor.js',
		[ 'buildFlashCardEditorCard', 'serializeFlashCardEditorCard' ],
		{ document, window }
	);

	const card = buildFlashCardEditorCard( {
		front: {
			title:     'Question',
			image_id:  42,
			image_url: 'http://example.test/img/42.jpg',
			subtitle:  'Hint',
		},
		back:  {
			title:     'Answer',
			image_id:  99,
			image_url: 'http://example.test/img/99.jpg',
			subtitle:  'Detail',
		},
	} );

	document.body.appendChild( card );

	assert.deepEqual( plain( serializeFlashCardEditorCard( card ) ), {
		front: {
			title:     'Question',
			image_id:  42,
			image_url: 'http://example.test/img/42.jpg',
			subtitle:  'Hint',
		},
		back:  {
			title:     'Answer',
			image_id:  99,
			image_url: 'http://example.test/img/99.jpg',
			subtitle:  'Detail',
		},
	} );
} );

test( 'flashcard editor ignores removed legacy text and background fields', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const document = dom.window.document;
	const window = dom.window;

	const {
		buildFlashCardEditorCard,
		serializeFlashCardEditorCard,
	} = loadModule(
		'assets/src/js/shared/flash-card/card-editor.js',
		[ 'buildFlashCardEditorCard', 'serializeFlashCardEditorCard' ],
		{ document, window }
	);

	const card = buildFlashCardEditorCard( {
		front: {
			text:           'Legacy question',
			background_id:  42,
			background_url: 'http://example.test/legacy-front.jpg',
		},
		back:  {
			text:           'Legacy answer',
			background_id:  99,
			background_url: 'http://example.test/legacy-back.jpg',
		},
	} );

	document.body.appendChild( card );

	assert.deepEqual( plain( serializeFlashCardEditorCard( card ) ), {
		front: { title: '', image_id: 0, image_url: '', subtitle: '' },
		back:  { title: '', image_id: 0, image_url: '', subtitle: '' },
	} );
} );

test( 'flashcard editor places title image and subtitle in a vertical sequence', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const document = dom.window.document;
	const window = dom.window;

	const { buildFlashCardEditorCard } = loadModule(
		'assets/src/js/shared/flash-card/card-editor.js',
		[ 'buildFlashCardEditorCard' ],
		{ document, window }
	);

	const card = buildFlashCardEditorCard();
	document.body.appendChild( card );

	const frontSide = card.querySelector( '.lp-interactive-fc-card__side--front' );
	const titleField = frontSide.querySelector( '.lp-interactive-fc-card__field--title' );
	const imageWrap = frontSide.querySelector( '.lp-interactive-fc-card__image-wrap' );
	const subtitleField = frontSide.querySelector( '.lp-interactive-fc-card__field--subtitle' );

	assert.equal( titleField.querySelector( 'input.lp-interactive-fc-card__editor' ) !== null, true );
	assert.equal( subtitleField.querySelector( 'input.lp-interactive-fc-card__editor' ) !== null, true );
	assert.equal(
		frontSide.children[1],
		titleField,
		'title input should be directly below the side label'
	);
	assert.equal(
		frontSide.children[2],
		imageWrap,
		'image picker should be between title and subtitle'
	);
	assert.equal(
		frontSide.children[3],
		subtitleField,
		'subtitle input should be below the image picker'
	);
} );

function __( text ) {
	return text;
}

function plain( value ) {
	return JSON.parse( JSON.stringify( value ) );
}

function sprintf( format, ...args ) {
	let index = 0;
	return String( format ).replace( /%(?:(\d+)\$)?[sdf]/g, ( _match, position ) => {
		const argIndex = position ? parseInt( position, 10 ) - 1 : index++;
		return String( args[ argIndex ] ?? '' );
	} );
}
