import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';
import { JSDOM } from 'jsdom';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadModule( context = {} ) {
	let source = fs.readFileSync(
		path.join( ROOT, 'assets/src/js/admin/builder/slide/canvas/FabricCanvas.js' ),
		'utf8'
	);

	source = source
		.replace( /^import .*;$/gm, '' )
		.replace( /export class /g, 'class ' );

	const script = new vm.Script( `${ source }\n( { FabricCanvas } );` );
	return script.runInNewContext( Object.assign( {
		console,
		FabricObject: { customProperties: [] },
		fabricCache: { clearFontCache: () => {} },
		Point: class FakePoint {
			constructor( x, y ) {
				this.x = x;
				this.y = y;
			}
		},
		ALIGNMENT: { MARGIN: 4, COLOR: '#0015ff', LINE_WIDTH: 2 },
		SERIALIZED_OBJECT_PROPS: [ 'id' ],
		LAYER_DEFAULTS: {
			DUPLICATE_OFFSET: 10,
			MOVE_STEP: 10,
			MOVE_STEP_FAST: 20,
			MAX_HISTORY_STEPS: 20,
		},
		TIMING: { DEBOUNCE_SAVE: 500 },
		ELEMENT_SCALING: { TARGET_PERCENT: 0.2 },
		createTextbox: ( options = {} ) => Object.assign( { id: 'obj-text', type: 'i-text' }, options ),
		ActiveSelection: class FakeActiveSelection {
			constructor( objects, opts ) {
				this.type = 'activeselection';
				this._objects = objects;
				this.canvas = opts && opts.canvas;
				this.left = 0;
				this.top  = 0;
			}
			set( patch ) { Object.assign( this, patch ); }
			setCoords() {}
		},
	}, context ) );
}

class FakeFabricCanvas {
	constructor( element, options ) {
		this.element = element;
		this.options = options;
		this.width = options.width;
		this.height = options.height;
		this.backgroundColor = options.backgroundColor;
		this.handlers = {};
		this.loadedJson = null;
		this.renderedJson = null;
		this.objects = [];
		this.activeObject = null;
		this.pendingLoads = [];
		this.disposed = false;
		this.contextTop = { name: 'context-top' };
		this.clearedContexts = [];
		this.firedEvents = [];
		FakeFabricCanvas.instances.push( this );
	}

	on( eventName, handler ) {
		this.handlers[ eventName ] = handler;
	}

	fire( eventName, payload ) {
		this.firedEvents.push( { eventName, payload } );
		if ( this.handlers[ eventName ] ) {
			this.handlers[ eventName ]( payload );
		}
	}

	off() {
		this.handlers = {};
	}

	async loadFromJSON( json ) {
		this.loadedJson = json;
		this.objects = Array.isArray( json && json.objects ) ? json.objects.slice() : [];
	}

	clear() {
		this.cleared = true;
	}

	requestRenderAll() {
		this.rendered = true;
		this.renderedJson = this.loadedJson;
	}

	toJSON( extraProperties ) {
		this.extraProperties = extraProperties;
		return {
			version: '7.4.0',
			objects: this.objects.length
				? this.objects.map( ( object ) => Object.assign( {}, object ) )
				: [ { id: 'obj-1', type: 'textbox', text: 'Changed' } ],
		};
	}

	toObject( extraProperties ) {
		return this.toJSON( extraProperties );
	}

	add( object ) {
		this.objects.push( object );
		if ( this.handlers[ 'object:added' ] ) {
			this.handlers[ 'object:added' ]( { target: object } );
		}
	}

	remove( object ) {
		const idx = this.objects.indexOf( object );
		if ( idx !== -1 ) {
			this.objects.splice( idx, 1 );
		}
		if ( this.handlers[ 'object:removed' ] ) {
			this.handlers[ 'object:removed' ]( { target: object } );
		}
	}

	getActiveObjects() {
		if ( ! this.activeObject ) {
			return [];
		}
		if ( this.activeObject.type === 'activeselection' ) {
			return this.activeObject._objects || [];
		}
		return [ this.activeObject ];
	}

	discardActiveObject() {
		this.activeObject = null;
	}

	getWidth() {
		return this.options.width;
	}

	getHeight() {
		return this.options.height;
	}

	getZoom() {
		return 1;
	}

	getSelectionContext() {
		return this.selectionContext || null;
	}

	clearContext( context ) {
		this.clearedContexts.push( context );
	}

	setActiveObject( object ) {
		this.activeObject = object;
	}

	getActiveObject() {
		return this.activeObject;
	}

	getObjects() {
		return this.objects;
	}

	dispose() {
		this.disposed = true;
	}
}

FakeFabricCanvas.instances = [];

function createStore( initialState = {} ) {
	let state = {
		slides: [
			{
				clientId: 's1',
				content: { version: '7.4.0', objects: [] },
				background: '#f8fafc',
			},
		],
		currentIdx: 0,
		selectedElementId: null,
		selectedElementType: null,
		selectedElementProps: {},
		dirty: false,
	};
	state = Object.assign( {}, state, initialState );
	const listeners = new Set();

	return {
		get: () => state,
		setState: ( patch ) => {
			state = Object.assign( {}, state, patch );
			listeners.forEach( ( listener ) => listener( state ) );
		},
		subscribe: ( listener ) => {
			listeners.add( listener );
			return () => listeners.delete( listener );
		},
		updateSlideContent: ( index, content ) => {
			const slides = state.slides.slice();
			slides[ index ] = Object.assign( {}, slides[ index ], { content } );
			state = Object.assign( {}, state, {
				slides,
				dirty: true,
				dirtySlideIndex: index,
			} );
			listeners.forEach( ( listener ) => listener( state ) );
		},
		updateCurrentSlideContent: ( content ) => {
			const index = Number.isInteger( state.currentIdx ) ? state.currentIdx : 0;
			const slides = state.slides.slice();
			slides[ index ] = Object.assign( {}, slides[ index ], { content } );
			state = Object.assign( {}, state, {
				slides,
				dirty: true,
				dirtySlideIndex: index,
			} );
			listeners.forEach( ( listener ) => listener( state ) );
		},
		setSelectedElement: ( elementId, elementType, elementProps = {} ) => {
			state = Object.assign( {}, state, {
				selectedElementId: elementId,
				selectedElementType: elementType,
				selectedElementProps: elementProps,
			} );
		},
	};
}

test( 'mounts a Fabric canvas using configured slide dimensions and loads current slide content', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const canvas = parent.querySelector( 'canvas' );
	const instance = FakeFabricCanvas.instances[0];

	assert.equal( canvas.getAttribute( 'width' ), '842' );
	assert.equal( canvas.getAttribute( 'height' ), '595' );
	assert.equal( instance.options.width, 842 );
	assert.equal( instance.options.height, 595 );
	assert.equal( instance.backgroundColor, '#f8fafc' );
	assert.deepEqual( instance.loadedJson, { version: '7.4.0', objects: [] } );
} );

test( 'shows certificate-style center snapping guidelines while moving objects', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const drawCalls = [];
	const selectionContext = {
		save:        () => drawCalls.push( [ 'save' ] ),
		setLineDash: ( value ) => drawCalls.push( [ 'setLineDash', value ] ),
		beginPath:   () => drawCalls.push( [ 'beginPath' ] ),
		moveTo:      ( x, y ) => drawCalls.push( [ 'moveTo', x, y ] ),
		lineTo:      ( x, y ) => drawCalls.push( [ 'lineTo', x, y ] ),
		stroke:      () => drawCalls.push( [ 'stroke' ] ),
		restore:     () => drawCalls.push( [ 'restore' ] ),
	};
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const instance = FakeFabricCanvas.instances[0];
	instance.selectionContext = selectionContext;
	const object = {
		center: { x: 420, y: 296 },
		getCenterPoint() {
			return this.center;
		},
		setPositionByOrigin( point ) {
			this.center = { x: point.x, y: point.y };
		},
	};

	instance.handlers[ 'object:moving' ]( { target: object } );
	instance.handlers[ 'after:render' ]();

	assert.deepEqual( object.center, { x: 421, y: 297.5 } );
	assert.deepEqual(
		drawCalls.filter( ( call ) => call[0] === 'moveTo' || call[0] === 'lineTo' ),
		[
			[ 'moveTo', 421, 0 ],
			[ 'lineTo', 421, 595 ],
			[ 'moveTo', 0, 297.5 ],
			[ 'lineTo', 842, 297.5 ],
		]
	);

	drawCalls.length = 0;
	instance.handlers[ 'mouse:up' ]();
	instance.handlers[ 'after:render' ]();

	assert.equal( instance.rendered, true );
	assert.equal( drawCalls.length, 0 );
} );

test( 'clears guideline drawing context before rendering so released lines do not remain visible', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const drawCalls = [];
	const selectionContext = {
		save:        () => drawCalls.push( [ 'save' ] ),
		setLineDash: () => {},
		beginPath:   () => {},
		moveTo:      ( x, y ) => drawCalls.push( [ 'moveTo', x, y ] ),
		lineTo:      ( x, y ) => drawCalls.push( [ 'lineTo', x, y ] ),
		stroke:      () => {},
		restore:     () => {},
	};
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const instance = FakeFabricCanvas.instances[0];
	instance.selectionContext = selectionContext;
	const object = {
		center: { x: 421, y: 297.5 },
		getCenterPoint() {
			return this.center;
		},
		setPositionByOrigin( point ) {
			this.center = { x: point.x, y: point.y };
		},
	};

	assert.equal( typeof instance.handlers[ 'before:render' ], 'function' );

	instance.handlers[ 'object:moving' ]( { target: object } );
	instance.handlers[ 'before:render' ]();
	instance.handlers[ 'after:render' ]();
	assert.equal( drawCalls.length > 0, true );
	assert.deepEqual( instance.clearedContexts, [ instance.contextTop ] );

	drawCalls.length = 0;
	instance.handlers[ 'mouse:up' ]();
	instance.handlers[ 'before:render' ]();
	instance.handlers[ 'after:render' ]();

	assert.deepEqual( instance.clearedContexts, [ instance.contextTop, instance.contextTop ] );
	assert.equal( drawCalls.length, 0 );
} );

test( 'shows red object alignment guidelines while moving objects near each other', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const drawCalls = [];
	const selectionContext = {
		save:        () => drawCalls.push( [ 'save' ] ),
		setLineDash: ( value ) => drawCalls.push( [ 'setLineDash', value ] ),
		beginPath:   () => drawCalls.push( [ 'beginPath' ] ),
		moveTo:      ( x, y ) => drawCalls.push( [ 'moveTo', x, y, selectionContext.strokeStyle ] ),
		lineTo:      ( x, y ) => drawCalls.push( [ 'lineTo', x, y, selectionContext.strokeStyle ] ),
		stroke:      () => drawCalls.push( [ 'stroke', selectionContext.strokeStyle ] ),
		restore:     () => drawCalls.push( [ 'restore' ] ),
	};
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const instance = FakeFabricCanvas.instances[0];
	instance.selectionContext = selectionContext;
	const target = {
		center: { x: 100, y: 100 },
		getCenterPoint() {
			return this.center;
		},
		getBoundingRect() {
			return { width: 50, height: 50 };
		},
	};
	const active = {
		center: { x: 102, y: 180 },
		getCenterPoint() {
			return this.center;
		},
		getBoundingRect() {
			return { width: 30, height: 30 };
		},
		setPositionByOrigin( point ) {
			this.center = { x: point.x, y: point.y };
		},
	};
	instance.objects = [ target, active ];

	instance.handlers[ 'object:moving' ]( { target: active } );
	instance.handlers[ 'after:render' ]();

	assert.deepEqual( active.center, { x: 100, y: 180 } );
	assert.deepEqual(
		drawCalls.filter( ( call ) => call[0] === 'moveTo' || call[0] === 'lineTo' ),
		[
			[ 'moveTo', 100.5, 70, 'rgba(255,0,0,0.9)' ],
			[ 'lineTo', 100.5, 200, 'rgba(255,0,0,0.9)' ],
		]
	);
} );

test( 'nudgeActiveObject triggers guidelines and clears them after the keyboard move delay', async () => {
	FakeFabricCanvas.instances = [];
	const scheduled = [];
	const cleared = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const drawCalls = [];
	const selectionContext = {
		save:        () => drawCalls.push( [ 'save' ] ),
		setLineDash: () => {},
		beginPath:   () => {},
		moveTo:      ( x, y ) => drawCalls.push( [ 'moveTo', x, y ] ),
		lineTo:      ( x, y ) => drawCalls.push( [ 'lineTo', x, y ] ),
		stroke:      () => {},
		restore:     () => {},
	};
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
		TIMING: { DEBOUNCE_SAVE: 500, KEYBOARD_MOVE_DELAY: 300 },
		LAYER_DEFAULTS: {
			DUPLICATE_OFFSET: 10,
			MOVE_STEP: 10,
			MOVE_STEP_FAST: 20,
			MAX_HISTORY_STEPS: 20,
		},
		setTimeout: ( callback, delay ) => {
			const timerId = 'keyboard-timer-' + ( scheduled.length + 1 );
			scheduled.push( { timerId, callback, delay } );
			return timerId;
		},
		clearTimeout: ( timerId ) => cleared.push( timerId ),
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const instance = FakeFabricCanvas.instances[0];
	instance.selectionContext = selectionContext;
	const object = {
		id: 'obj-text',
		type: 'textbox',
		left: 420,
		top: 297.5,
		set( property, value ) {
			if ( typeof property === 'string' ) {
				this[ property ] = value;
				return;
			}
			Object.assign( this, property );
		},
		getCenterPoint() {
			return { x: this.left, y: this.top };
		},
		getBoundingRect() {
			return { width: 40, height: 20 };
		},
		setPositionByOrigin( point ) {
			this.left = point.x;
			this.top = point.y;
		},
		setCoords() {},
	};
	instance.objects = [ object ];
	instance.activeObject = object;

	adapter.nudgeActiveObject( 'ArrowRight', false );
	instance.handlers[ 'after:render' ]();

	assert.equal( object.left, 430 );
	assert.equal( instance.firedEvents[0].eventName, 'object:moving' );
	assert.equal( scheduled.length, 1 );
	assert.equal( scheduled[0].delay, 300 );
	assert.equal( drawCalls.length > 0, true );

	drawCalls.length = 0;
	scheduled[0].callback();
	instance.handlers[ 'after:render' ]();

	assert.equal( instance.firedEvents.at( -1 ).eventName, 'mouse:up' );
	assert.equal( drawCalls.length, 0 );
	assert.equal( adapter._keyboardMoveTimeout, null );
	assert.deepEqual( cleared, [] );
} );

test( 'nudgeActiveObject uses the certificate fast move step when shift is pressed', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
		TIMING: { DEBOUNCE_SAVE: 500, KEYBOARD_MOVE_DELAY: 300 },
		LAYER_DEFAULTS: {
			DUPLICATE_OFFSET: 10,
			MOVE_STEP: 10,
			MOVE_STEP_FAST: 20,
			MAX_HISTORY_STEPS: 20,
		},
		setTimeout: () => 'keyboard-timer',
		clearTimeout: () => {},
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const instance = FakeFabricCanvas.instances[0];
	const object = {
		id: 'obj-text',
		type: 'textbox',
		left: 50,
		top: 50,
		set( property, value ) {
			if ( typeof property === 'string' ) {
				this[ property ] = value;
				return;
			}
			Object.assign( this, property );
		},
		getCenterPoint() {
			return { x: this.left, y: this.top };
		},
		getBoundingRect() {
			return { width: 40, height: 20 };
		},
		setPositionByOrigin( point ) {
			this.left = point.x;
			this.top = point.y;
		},
		setCoords() {},
	};
	instance.objects = [ object ];
	instance.activeObject = object;

	adapter.nudgeActiveObject( 'ArrowDown', true );

	assert.equal( object.top, 70 );
} );

test( 'serializes object changes and mirrors Fabric selection into the slide store', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();
	store.setState( { dirty: false } );

	const instance = FakeFabricCanvas.instances[0];
	instance.handlers[ 'object:modified' ]();
	instance.handlers[ 'selection:created' ]( {
		selected: [ { id: 'obj-1', type: 'textbox' } ],
	} );

	assert.equal( store.get().dirty, true );
	assert.deepEqual(
		store.get().slides[0].content,
		{
			version: '7.4.0',
			objects: [ { id: 'obj-1', type: 'textbox', text: 'Changed' } ],
		}
	);
	assert.equal( store.get().selectedElementId, 'obj-1' );
	assert.equal( store.get().selectedElementType, 'textbox' );

	adapter.destroy();
	assert.equal( instance.disposed, true );
} );

test( 'mirrors selected textbox style props into the slide store', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();
	store.setState( { dirty: false } );

	const instance = FakeFabricCanvas.instances[0];
	instance.handlers[ 'selection:created' ]( {
		selected: [
			{
				id:          'obj-1',
				type:        'textbox',
				fontFamily:  'Inter',
				fontSize:    64,
				fill:        '#ffffff',
				fontWeight:  'bold',
				fontStyle:   'italic',
					underline:   true,
					linethrough: true,
					textAlign:   'center',
					charSpacing: 120,
					lineHeight:  1.4,
				},
			],
		} );

	assert.deepEqual( JSON.parse( JSON.stringify( store.get().selectedElementProps ) ), {
		fontFamily:  'Inter',
		fontSize:    64,
		fill:        '#ffffff',
		fontWeight:  'bold',
		fontStyle:   'italic',
			underline:   true,
			linethrough: true,
			textAlign:   'center',
			charSpacing: 120,
			lineHeight:  1.4,
		} );
	} );

test( 'adds editable text selects it and serializes the current slide', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
		createTextbox: ( options ) => Object.assign( { id: 'obj-text', type: 'i-text' }, options ),
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();
	adapter.addTextbox( { text: 'Lesson title', fontSize: 56 } );

	const instance = FakeFabricCanvas.instances[0];
	assert.equal( instance.activeObject.id, 'obj-text' );
	assert.equal( store.get().selectedElementId, 'obj-text' );
	assert.equal( store.get().selectedElementType, 'i-text' );
	assert.equal( store.get().dirty, true );
	assert.deepEqual( store.get().slides[0].content.objects, [
		{
			id:      'obj-text',
			type:    'i-text',
			text:    'Lesson title',
			fontSize: 56,
			left:    421,
			top:     297.5,
			originX: 'center',
			originY: 'center',
		},
	] );
} );

test( 'enters editing and selects all text when adding a textbox requests it', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	let receivedOptions = null;
	const textObject = {
		id:           'obj-text',
		type:         'i-text',
		text:         'The content of your text',
		enterEditing: () => {
			textObject.editingEntered = true;
		},
		selectAll: () => {
			textObject.allSelected = true;
		},
	};
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
		createTextbox: ( options ) => {
			receivedOptions = options;
			return Object.assign( textObject, options );
		},
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();
	adapter.addTextbox( {
		text:         'The content of your text',
		enterEditing: true,
		selectAll:    true,
	} );

	assert.equal( textObject.editingEntered, true );
	assert.equal( textObject.allSelected, true );
	assert.equal( receivedOptions.enterEditing, undefined );
	assert.equal( receivedOptions.selectAll, undefined );
} );

test( 'prepares inserted non-text objects with certificate-style center and target scale', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
		ELEMENT_SCALING: { TARGET_PERCENT: 0.2 },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const image = {
		id:        'obj-image',
		type:      'image',
		width:     1000,
		height:    500,
		setCoords: () => {
			image.coordsUpdated = true;
		},
	};

	adapter.prepareInsertedObject( image );

	assert.equal( image.scaleX, 0.1684 );
	assert.equal( image.scaleY, 0.1684 );
	assert.equal( image.left, 421 );
	assert.equal( image.top, 297.5 );
	assert.equal( image.originX, 'center' );
	assert.equal( image.originY, 'center' );
	assert.equal( image.coordsUpdated, true );
} );

test( 'updates the active text object and serializes the current slide', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
		createTextbox: ( options ) => Object.assign( { id: 'obj-text', type: 'i-text' }, options ),
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();
	adapter.addTextbox( { text: 'Lesson title', fontSize: 56 } );
	adapter.updateActiveObject( { fontSize: 64, fill: '#334155' } );

	assert.deepEqual( store.get().slides[0].content.objects, [
		{
			id:       'obj-text',
			type:     'i-text',
			text:     'Lesson title',
			fontSize: 64,
			fill:     '#334155',
			left:     421,
			top:      297.5,
			originX:  'center',
			originY:  'center',
		},
	] );
} );

test( 'text changes debounce slide serialization and editing exit flushes the final text', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const scheduled = [];
	const cleared = [];
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
		TIMING: { DEBOUNCE_SAVE: 500 },
		setTimeout: ( callback, delay ) => {
			const timerId = 'timer-' + ( scheduled.length + 1 );
			scheduled.push( { timerId, callback, delay } );
			return timerId;
		},
		clearTimeout: ( timerId ) => cleared.push( timerId ),
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();
	store.setState( { dirty: false } );

	const instance = FakeFabricCanvas.instances[0];
	const object = {
		id: 'obj-text',
		type: 'i-text',
		text: 'Draft text',
		setCoordsCalls: 0,
		setCoords() {
			this.setCoordsCalls += 1;
		},
	};
	instance.objects = [ object ];
	instance.toJSON = () => ( {
		version: '7.4.0',
		objects: [ { id: object.id, type: object.type, text: object.text } ],
	} );
	instance.toObject = instance.toJSON;

	instance.handlers[ 'text:changed' ]( { target: object } );
	assert.equal( scheduled.length, 1 );
	assert.equal( scheduled[0].delay, 500 );
	assert.equal( store.get().dirty, false );

	object.text = 'Final text';
	instance.handlers[ 'text:changed' ]( { target: object } );
	assert.deepEqual( cleared, [ 'timer-1' ] );
	assert.equal( scheduled.length, 2 );

	instance.handlers[ 'editing:exited' ]( { target: object } );
	assert.deepEqual( cleared, [ 'timer-1', 'timer-2' ] );
	assert.equal( object.setCoordsCalls, 3 );
	assert.equal( instance.rendered, true );
	assert.deepEqual( store.get().slides[0].content.objects, [
		{ id: 'obj-text', type: 'i-text', text: 'Final text' },
	] );
	assert.equal( store.get().selectedElementId, 'obj-text' );
} );

test( 'flushes pending text changes into the source slide before loading another slide', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const scheduled = [];
	const cleared = [];
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
		TIMING: { DEBOUNCE_SAVE: 500 },
		setTimeout: ( callback, delay ) => {
			const timerId = 'timer-' + ( scheduled.length + 1 );
			scheduled.push( { timerId, callback, delay } );
			return timerId;
		},
		clearTimeout: ( timerId ) => cleared.push( timerId ),
	} );
	const store = createStore( {
		slides: [
			{
				clientId: 's1',
				content: { version: '7.4.0', objects: [ { id: 'obj-text', type: 'i-text', text: 'Old text' } ] },
				background: '#ffffff',
			},
			{
				clientId: 's2',
				content: { version: '7.4.0', objects: [ { id: 'obj-2', type: 'i-text', text: 'Second' } ] },
				background: '#f8fafc',
			},
		],
		currentIdx: 0,
	} );
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();
	store.setState( { dirty: false } );

	const instance = FakeFabricCanvas.instances[0];
	const object = {
		id: 'obj-text',
		type: 'i-text',
		text: 'Final text',
		setCoordsCalls: 0,
		setCoords() {
			this.setCoordsCalls += 1;
		},
	};
	instance.objects = [ object ];
	instance.toJSON = () => ( {
		version: '7.4.0',
		objects: [ { id: object.id, type: object.type, text: object.text } ],
	} );
	instance.toObject = instance.toJSON;

	instance.handlers[ 'text:changed' ]( { target: object } );
	store.setState( { currentIdx: 1, selectedElementId: null, selectedElementType: null } );

	assert.deepEqual( cleared, [ 'timer-1' ] );
	assert.equal( object.setCoordsCalls, 2 );
	assert.deepEqual( store.get().slides[0].content.objects, [
		{ id: 'obj-text', type: 'i-text', text: 'Final text' },
	] );
	assert.deepEqual( store.get().slides[1].content.objects, [
		{ id: 'obj-2', type: 'i-text', text: 'Second' },
	] );
	assert.equal( store.get().selectedElementId, null );
	assert.equal( store.get().dirtySlideIndex, 0 );
} );

test( 'clears pending text changes when the canvas is destroyed', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const cleared = [];
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
		TIMING: { DEBOUNCE_SAVE: 500 },
		setTimeout: () => 'timer-1',
		clearTimeout: ( timerId ) => cleared.push( timerId ),
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const instance = FakeFabricCanvas.instances[0];
	instance.handlers[ 'text:changed' ]( {
		target: {
			id: 'obj-text',
			type: 'i-text',
		},
	} );
	adapter.destroy();

	assert.deepEqual( cleared, [ 'timer-1' ] );
	assert.equal( adapter.textChangeTimeout, null );
	assert.equal( instance.disposed, true );
} );

test( 'updates text objects with coordinates and resolves font family before serializing', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const loadedFonts = [];
	dom.window.document.fonts = {
		load: async ( descriptor ) => {
			loadedFonts.push( descriptor );
			return [];
		},
	};
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const instance = FakeFabricCanvas.instances[0];
	const object = {
		id: 'obj-text',
		type: 'i-text',
		text: 'Lesson title',
		fontFamily: 'Inter',
		setCoordsCalls: 0,
		initDimensionsCalls: 0,
		set( property, value ) {
			if ( typeof property === 'string' ) {
				this[ property ] = value;
				return;
			}
			Object.assign( this, property );
		},
		setCoords() {
			this.setCoordsCalls += 1;
		},
		initDimensions() {
			this.initDimensionsCalls += 1;
		},
	};
	instance.objects = [ object ];
	instance.activeObject = object;
	instance.toJSON = () => ( {
		version: '7.4.0',
		objects: [
			{
				id: object.id,
				type: object.type,
				text: object.text,
				fontFamily: object.fontFamily,
				fontSize: object.fontSize,
				dirty: object.dirty,
			},
		],
	} );
	instance.toObject = instance.toJSON;

	await adapter.updateActiveObject( { fontFamily: 'Georgia', fontSize: 64 } );

	assert.deepEqual( loadedFonts, [ 'normal 400 16px "Georgia"' ] );
	assert.equal( object.fontFamily, 'Georgia' );
	assert.equal( object.fontSize, 64 );
	assert.equal( object.initDimensionsCalls, 1 );
	assert.equal( object.dirty, true );
	assert.equal( object.setCoordsCalls, 1 );
	assert.deepEqual( store.get().slides[0].content.objects, [
		{ id: 'obj-text', type: 'i-text', text: 'Lesson title', fontFamily: 'Georgia', fontSize: 64, dirty: true },
	] );
	assert.equal( store.get().selectedElementProps.fontFamily, 'Georgia' );
	assert.equal( store.get().selectedElementProps.fontSize, 64 );
} );

test( 'updates the selected text object when toolbar focus clears the active Fabric object', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
		createTextbox: ( options ) => Object.assign( { id: 'obj-text', type: 'i-text' }, options ),
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();
	adapter.addTextbox( { text: 'Lesson title', fill: '#111111' } );

	const instance = FakeFabricCanvas.instances[0];
	instance.activeObject = null;
	adapter.updateActiveObject( { fill: '#ff0000' } );

	assert.deepEqual( store.get().slides[0].content.objects, [
		{
			id:      'obj-text',
			type:    'i-text',
			text:    'Lesson title',
			fill:    '#ff0000',
			left:    421,
			top:     297.5,
			originX: 'center',
			originY: 'center',
		},
	] );
} );

test( 'ignores stale async slide loads after a newer slide is selected', async () => {
	class DeferredFabricCanvas extends FakeFabricCanvas {
		loadFromJSON( json ) {
			const pending = {};
			pending.json = json;
			pending.promise = new Promise( ( resolve ) => {
				pending.resolve = () => {
					this.loadedJson = json;
					resolve();
				};
			} );
			this.pendingLoads.push( pending );
			return pending.promise;
		}
	}

	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: DeferredFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	store.setState( {
		slides: [
			{
				clientId: 's1',
				content: { version: '7.4.0', objects: [ { text: 'First' } ] },
				background: '#ffffff',
			},
			{
				clientId: 's2',
				content: { version: '7.4.0', objects: [ { text: 'Second' } ] },
				background: '#f8fafc',
			},
		],
		currentIdx: 0,
	} );
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	const instance = DeferredFabricCanvas.instances.at( -1 );

	store.setState( { currentIdx: 1 } );
	assert.equal( instance.pendingLoads.length, 2 );

	instance.pendingLoads[1].resolve();
	await instance.pendingLoads[1].promise;
	await new Promise( ( resolve ) => setTimeout( resolve, 0 ) );
	assert.deepEqual( instance.renderedJson, { version: '7.4.0', objects: [ { text: 'Second' } ] } );

	instance.pendingLoads[0].resolve();
	await instance.pendingLoads[0].promise;
	await new Promise( ( resolve ) => setTimeout( resolve, 0 ) );
	assert.deepEqual( instance.renderedJson, { version: '7.4.0', objects: [ { text: 'Second' } ] } );
} );

test( 'deleteActiveObject with multiple objects records exactly one history step', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const instance = FakeFabricCanvas.instances.at( -1 );
	const obj1 = { id: 'o1', type: 'textbox', setCoords: () => {} };
	const obj2 = { id: 'o2', type: 'textbox', setCoords: () => {} };
	instance.objects = [ obj1, obj2 ];
	instance.activeObject = { type: 'activeselection', _objects: [ obj1, obj2 ] };

	adapter._resetHistory();
	assert.equal( adapter._undoStack.length, 0 );

	adapter.deleteActiveObject();

	assert.equal( instance.objects.length, 0 );
	assert.equal( adapter._undoStack.length, 1, 'should record exactly one undo step for multi-delete' );
} );

test( 'undo restores _lastHistorySnapshot to pre-undo state when loadFromJSON throws', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );

	class ControllableFabricCanvas extends FakeFabricCanvas {
		constructor( el, opts ) {
			super( el, opts );
			this.failOnNextLoad = false;
		}
		async loadFromJSON( json ) {
			if ( this.failOnNextLoad ) {
				this.failOnNextLoad = false;
				throw new Error( 'bad json' );
			}
			return super.loadFromJSON( json );
		}
	}
	ControllableFabricCanvas.instances = [];

	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: ControllableFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const instance = FakeFabricCanvas.instances.at( -1 );

	// Record the current snapshot as baseline, then push a fake undo entry
	adapter._resetHistory();
	const baselineSnapshot = adapter._lastHistorySnapshot;
	adapter._undoStack.push( JSON.stringify( { version: '7', objects: [ { id: 'x' } ] } ) );

	// Make the next loadFromJSON fail
	instance.failOnNextLoad = true;
	const result = await adapter.undo();

	assert.equal( result, false );
	assert.equal( adapter._lastHistorySnapshot, baselineSnapshot, 'snapshot must be restored to pre-undo state on error' );
	assert.equal( adapter._undoStack.length, 1, 'undo stack must be restored on error' );
	assert.equal( adapter._redoStack.length, 0, 'redo stack must be rolled back on error' );
} );

test( 'duplicateActiveObject on activeselection records exactly one history step', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const instance = FakeFabricCanvas.instances.at( -1 );
	const obj1 = { id: 'o1', type: 'textbox', setCoords: () => {}, left: 0, top: 0 };
	const obj2 = { id: 'o2', type: 'textbox', setCoords: () => {}, left: 0, top: 0 };
	instance.objects = [ obj1, obj2 ];
	const selection = {
		type: 'activeselection',
		_objects: [ obj1, obj2 ],
		clone: async () => ( {
			type: 'activeselection',
			_objects: [
				{ id: 'o1', type: 'textbox', setCoords: () => {}, left: 0, top: 0 },
				{ id: 'o2', type: 'textbox', setCoords: () => {}, left: 0, top: 0 },
			],
		} ),
	};
	instance.activeObject = selection;

	adapter._resetHistory();
	assert.equal( adapter._undoStack.length, 0 );

	await adapter.duplicateActiveObject();

	assert.equal( instance.objects.length, 4, 'should add 2 cloned objects' );
	assert.equal( adapter._undoStack.length, 1, 'should record exactly one undo step for multi-duplicate' );
} );

test( 'pasteObject on activeselection records exactly one history step', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const instance = FakeFabricCanvas.instances.at( -1 );
	adapter._clipboard = {
		left: 10,
		top: 10,
		clone: async () => ( {
			type: 'activeselection',
			_objects: [
				{ id: 'p1', type: 'textbox', setCoords: () => {}, left: 0, top: 0 },
				{ id: 'p2', type: 'textbox', setCoords: () => {}, left: 0, top: 0 },
			],
		} ),
		set: function ( patch ) { Object.assign( this, patch ); },
	};

	adapter._resetHistory();
	assert.equal( adapter._undoStack.length, 0 );

	await adapter.pasteObject();

	assert.equal( instance.objects.length, 2, 'should add 2 pasted objects' );
	assert.equal( adapter._undoStack.length, 1, 'should record exactly one undo step for multi-paste' );
} );

test( '_batchingHistory is reset if remove throws inside delete', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );

	class ThrowOnRemoveCanvas extends FakeFabricCanvas {
		remove( object ) {
			if ( object && object.id === 'will-throw' ) {
				throw new Error( 'remove failed' );
			}
			return super.remove( object );
		}
	}
	ThrowOnRemoveCanvas.instances = [];

	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: ThrowOnRemoveCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const instance = FakeFabricCanvas.instances.at( -1 );
	const obj1 = { id: 'ok',         setCoords: () => {} };
	const obj2 = { id: 'will-throw', setCoords: () => {} };
	instance.objects = [ obj1, obj2 ];
	instance.activeObject = { type: 'activeselection', _objects: [ obj1, obj2 ] };

	adapter._resetHistory();

	assert.throws( () => adapter.deleteActiveObject(), /remove failed/ );
	assert.equal( adapter._batchingHistory, false, '_batchingHistory must be reset after throw' );
} );

test( 'redo restores state when loadFromJSON throws and does not drop the oldest undo entry', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );

	class ControllableFabricCanvas extends FakeFabricCanvas {
		constructor( el, opts ) {
			super( el, opts );
			this.failOnNextLoad = false;
		}
		async loadFromJSON( json ) {
			if ( this.failOnNextLoad ) {
				this.failOnNextLoad = false;
				throw new Error( 'bad json' );
			}
			return super.loadFromJSON( json );
		}
	}
	ControllableFabricCanvas.instances = [];

	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: ControllableFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	const instance = FakeFabricCanvas.instances.at( -1 );

	adapter._resetHistory();
	const baselineSnapshot = adapter._lastHistorySnapshot;

	// Fill undo stack to the max so any extra push would shift the oldest entry
	for ( let i = 0; i < adapter._maxHistorySteps; i++ ) {
		adapter._undoStack.push( JSON.stringify( { version: '7', objects: [ { id: 'u' + i } ] } ) );
	}
	const originalOldest = adapter._undoStack[ 0 ];
	adapter._redoStack.push( JSON.stringify( { version: '7', objects: [ { id: 'r' } ] } ) );

	instance.failOnNextLoad = true;
	const result = await adapter.redo();

	assert.equal( result, false );
	assert.equal( adapter._undoStack.length, adapter._maxHistorySteps, 'undo stack should keep all entries on failed redo' );
	assert.equal( adapter._undoStack[ 0 ], originalOldest, 'oldest undo entry must not be dropped on failed redo' );
	assert.equal( adapter._redoStack.length, 1, 'redo stack must be restored on error' );
	assert.equal( adapter._lastHistorySnapshot, baselineSnapshot, 'snapshot must be restored on error' );
} );

test( 'undo commits the history transition when a post-load step throws', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	adapter._resetHistory();
	const baseline = adapter._lastHistorySnapshot;
	const targetSnapshot = JSON.stringify( { version: '7', objects: [ { id: 'x' } ] } );
	adapter._undoStack.push( targetSnapshot );

	// Make a post-load step throw. loadObjectFonts is called after loadFromJSON,
	// so the canvas has already been mutated by the time this throws.
	const originalLoadFonts = adapter.loadObjectFonts.bind( adapter );
	adapter.loadObjectFonts = async () => {
		throw new Error( 'font load failed' );
	};

	const result = await adapter.undo();

	adapter.loadObjectFonts = originalLoadFonts;

	assert.equal( result, true, 'undo must report success when canvas was changed' );
	assert.equal( adapter._undoStack.length, 0, 'undo stack must be consumed' );
	assert.equal( adapter._redoStack.length, 1, 'redo stack must hold the pre-undo snapshot' );
	const lastObjects = JSON.parse( adapter._lastHistorySnapshot ).objects;
	assert.equal( lastObjects.length, 1, 'snapshot must reflect the loaded state' );
	assert.equal( lastObjects[ 0 ].id, 'x' );
	assert.notEqual( adapter._lastHistorySnapshot, baseline, 'snapshot must not be the pre-undo state' );
} );

test( 'redo commits the history transition when a post-load step throws', async () => {
	FakeFabricCanvas.instances = [];
	const dom = new JSDOM( '<!doctype html><html><body><div id="host"></div></body></html>' );
	const { FabricCanvas } = loadModule( {
		document: dom.window.document,
		FabricCanvasClass: FakeFabricCanvas,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	} );
	const store = createStore();
	const parent = dom.window.document.getElementById( 'host' );

	const adapter = new FabricCanvas( store );
	adapter.mount( parent );
	await adapter.loadCurrentSlide();

	adapter._resetHistory();
	const targetSnapshot = JSON.stringify( { version: '7', objects: [ { id: 'r' } ] } );
	adapter._redoStack.push( targetSnapshot );

	const originalLoadFonts = adapter.loadObjectFonts.bind( adapter );
	adapter.loadObjectFonts = async () => {
		throw new Error( 'font load failed' );
	};

	const result = await adapter.redo();

	adapter.loadObjectFonts = originalLoadFonts;

	assert.equal( result, true, 'redo must report success when canvas was changed' );
	assert.equal( adapter._redoStack.length, 0, 'redo stack must be consumed' );
	assert.equal( adapter._undoStack.length, 1, 'undo stack must hold the pre-redo snapshot' );
	const lastObjects = JSON.parse( adapter._lastHistorySnapshot ).objects;
	assert.equal( lastObjects.length, 1, 'snapshot must reflect the loaded state' );
	assert.equal( lastObjects[ 0 ].id, 'r' );
} );
