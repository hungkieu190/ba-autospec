import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadModule( context = {} ) {
	let source = fs.readFileSync(
		path.join( ROOT, 'assets/src/js/admin/builder/slide/canvas/FabricObjectFactory.js' ),
		'utf8'
	);

	source = source
		.replace( /^import .*;$/gm, '' )
		.replace( /export async function /g, 'async function ' )
		.replace( /export function /g, 'function ' );

	const script = new vm.Script( `${ source }\n( { createTextbox, createImageFromUrl, createShape } );` );
	return script.runInNewContext( Object.assign( {
		console,
		CANVAS_DEFAULTS: { WIDTH: 842, HEIGHT: 595, BACKGROUND: '#ffffff' },
	}, context ) );
}

class FakeTextbox {
	constructor( text, options ) {
		this.type = 'textbox';
		this.text = text;
		Object.assign( this, options );
	}
}

class FakeIText {
	constructor( text, options ) {
		this.type = 'i-text';
		this.text = text;
		Object.assign( this, options );
	}
}

class FakeRect {
	constructor( options ) {
		this.type = 'rect';
		Object.assign( this, options );
	}
}

class FakeCircle {
	constructor( options ) {
		this.type = 'circle';
		Object.assign( this, options );
	}
}

class FakeTriangle {
	constructor( options ) {
		this.type = 'triangle';
		Object.assign( this, options );
	}
}

const FakeFabricImage = {
	fromURL: async ( url, loadOptions, imageOptions ) => ( {
		type: 'image',
		url,
		loadOptions,
		...imageOptions,
	} ),
};

test( 'creates editable text with slide editor defaults and caller overrides', () => {
	const { createTextbox } = loadModule( {
		Textbox: FakeTextbox,
		IText: FakeIText,
		Rect: FakeRect,
		Circle: FakeCircle,
		Triangle: FakeTriangle,
		FabricImage: FakeFabricImage,
	} );

	const object = createTextbox( {
		text: 'Lesson title',
		left: 200,
		fill: '#334155',
	} );

	assert.equal( object.type, 'i-text' );
	assert.equal( object.text, 'Lesson title' );
	assert.equal( object.left, 200 );
	assert.equal( object.top, 297.5 );
	assert.equal( object.originX, 'center' );
	assert.equal( object.originY, 'center' );
	assert.equal( object.width, undefined );
	assert.equal( object.fontSize, 42 );
	assert.equal( object.fontFamily, 'Inter' );
	assert.equal( object.fill, '#334155' );
	assert.match( object.id, /^obj-/ );
} );

test( 'centers new editable text on the slide canvas by default', () => {
	const { createTextbox } = loadModule( {
		Textbox: FakeTextbox,
		IText: FakeIText,
		Rect: FakeRect,
		Circle: FakeCircle,
		Triangle: FakeTriangle,
		FabricImage: FakeFabricImage,
	} );

	const object = createTextbox( { text: 'Centered title' } );

	assert.equal( object.left, 421 );
	assert.equal( object.top, 297.5 );
	assert.equal( object.originX, 'center' );
	assert.equal( object.originY, 'center' );
} );

test( 'creates supported shapes with shared defaults', () => {
	const { createShape } = loadModule( {
		Textbox: FakeTextbox,
		IText: FakeIText,
		Rect: FakeRect,
		Circle: FakeCircle,
		Triangle: FakeTriangle,
		FabricImage: FakeFabricImage,
	} );

	const rect = createShape( 'rect', { height: 200 } );
	const circle = createShape( 'circle' );
	const triangle = createShape( 'triangle', { fill: '#22c55e' } );

	assert.equal( rect.type, 'rect' );
	assert.equal( rect.left, 160 );
	assert.equal( rect.width, 180 );
	assert.equal( rect.height, 200 );
	assert.equal( circle.type, 'circle' );
	assert.equal( circle.radius, 60 );
	assert.equal( triangle.type, 'triangle' );
	assert.equal( triangle.fill, '#22c55e' );
	assert.throws( () => createShape( 'line' ), /Unsupported shape/ );
} );

test( 'creates image from URL with default placement and cross-origin loading', async () => {
	const { createImageFromUrl } = loadModule( {
		Textbox: FakeTextbox,
		IText: FakeIText,
		Rect: FakeRect,
		Circle: FakeCircle,
		Triangle: FakeTriangle,
		FabricImage: FakeFabricImage,
	} );

	const image = await createImageFromUrl( 'https://example.test/image.jpg', { left: 20 } );

	assert.equal( image.type, 'image' );
	assert.equal( image.url, 'https://example.test/image.jpg' );
	assert.equal( image.loadOptions.crossOrigin, 'anonymous' );
	assert.equal( image.left, 20 );
	assert.equal( image.top, 140 );
	assert.equal( image.scaleX, 1 );
	assert.match( image.id, /^obj-/ );
} );
