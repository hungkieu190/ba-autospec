import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadModule( relativePath, exportNames, context = {} ) {
	let source = fs.readFileSync( path.join( ROOT, relativePath ), 'utf8' );

	source = source
		.replace( /^import .*;$/gm, '' )
		.replace( /export class /g, 'class ' )
		.replace( /export function /g, 'function ' );

	const script = new vm.Script( `${ source }\n( { ${ exportNames.join( ', ' ) } } );` );
	return script.runInNewContext( Object.assign( { console }, context ) );
}

function h( tag, attrs, children ) {
	return { tag, attrs: attrs || {}, children: children || [] };
}

function findByTag( node, tag ) {
	if ( node.tag === tag ) {
		return node;
	}

	const children = Array.isArray( node.children ) ? node.children : [ node.children ];
	for ( const child of children ) {
		if ( child && typeof child === 'object' ) {
			const found = findByTag( child, tag );
			if ( found ) {
				return found;
			}
		}
	}

	return null;
}

test( 'slide header marks the deck title as dirty when it changes', () => {
	let state = { deckTitle: 'Old title' };
	let lastPatch = null;
	const root = {
		children:    [],
		appendChild: ( child ) => root.children.push( child ),
	};

	const { Header } = loadModule(
		'assets/src/js/admin/builder/slide/ui/Header.js',
		[ 'Header' ],
		{
			clear: ( target ) => {
				target.children = [];
			},
			h,
			icon: ( name ) => h( 'icon', { name } ),
			__:   ( text ) => text,
		}
	);

	const header = new Header( {
		get:      () => state,
		setState: ( patch ) => {
			lastPatch = patch;
			state = Object.assign( {}, state, patch );
		},
	} );

	header.mount( root );

	const input = findByTag( { children: root.children }, 'input' );
	input.attrs.onInput( { target: { value: 'New title' } } );

	assert.equal( lastPatch.deckTitle, 'New title' );
	assert.equal( lastPatch.dirty, true );
} );
