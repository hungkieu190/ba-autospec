import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';
import { JSDOM } from 'jsdom';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadFrontendModule( context = {} ) {
	let renderSource = fs.readFileSync(
		path.join( ROOT, 'assets/src/js/shared/flash-card/render.js' ),
		'utf8'
	);
	renderSource = renderSource
		.replace( /^import .*;$/gm, '' )
		.replace( /export function /g, 'function ' );

	let frontendSource = fs.readFileSync(
		path.join( ROOT, 'assets/src/js/frontend/types/flash-card.js' ),
		'utf8'
	);
	frontendSource = frontendSource
		.replace( /import[\s\S]*?;\n/g, '' )
		.replace( 'LpInteractiveFlashCards.boot();', '' );

	const script = new vm.Script(
		`${ renderSource }\n${ frontendSource }\n( { LpInteractiveFlashCards } );`
	);

	return script.runInNewContext( Object.assign( {
		console,
		__,
		sprintf,
		isFaceTextEmpty,
		setTimeout,
		clearTimeout,
	}, context ) );
}

test( 'frontend slider renders title image and subtitle for each side', () => {
	const deck = [ {
		front: {
			title:     '<p>Front title</p>',
			image_url: 'http://example.test/front.jpg',
			subtitle:  '<p>Front subtitle</p>',
		},
		back:  {
			title:     '<p>Back title</p>',
			image_url: 'http://example.test/back.jpg',
			subtitle:  '<p>Back subtitle</p>',
		},
	} ];

	const dom = new JSDOM( `
		<!doctype html>
		<html>
			<body>
				<div class="lp-interactive-flash-cards" data-layout="slider" data-show-progress="1" data-shuffle="0" data-require-flip="0">
					<div class="lp-interactive-flash-cards__meta"></div>
					<div class="lp-interactive-flash-cards__progress-fill"></div>
					<div class="lp-interactive-flash-cards__progress-label"></div>
					<div class="lp-interactive-flash-cards__card-area">
						<div class="lp-interactive-flash-card" data-flip="0">
							<div class="lp-interactive-flash-card__face lp-interactive-flash-card__front">
								<div class="lp-interactive-flash-card__side-label"></div>
								<div class="lp-interactive-flash-card__title-content lp-interactive-flash-card__text"></div>
								<div class="lp-interactive-flash-card__image-wrap"></div>
								<div class="lp-interactive-flash-card__subtitle"></div>
							</div>
							<div class="lp-interactive-flash-card__face lp-interactive-flash-card__back">
								<div class="lp-interactive-flash-card__side-label"></div>
								<div class="lp-interactive-flash-card__title-content lp-interactive-flash-card__text"></div>
								<div class="lp-interactive-flash-card__image-wrap"></div>
								<div class="lp-interactive-flash-card__subtitle"></div>
							</div>
						</div>
						<button type="button" class="lp-interactive-flash-cards__prev"></button>
						<button type="button" class="lp-interactive-flash-cards__next"></button>
					</div>
					<div class="lp-interactive-flash-cards__done"></div>
					<button type="button" class="lp-interactive-flash-cards__restart"></button>
					<script type="application/json" class="lp-interactive-flash-cards__data">${ JSON.stringify( deck ) }</script>
				</div>
			</body>
		</html>
	` );

	const { LpInteractiveFlashCards } = loadFrontendModule( {
		document:         dom.window.document,
		window:           dom.window,
		MutationObserver: dom.window.MutationObserver,
		DOMParser:        dom.window.DOMParser,
	} );

	const root = dom.window.document.querySelector( '.lp-interactive-flash-cards' );
	new LpInteractiveFlashCards( root ).init();

	assert.equal(
		root.querySelector( '.lp-interactive-flash-cards__next' ).textContent.trim(),
		'Next →'
	);
	assert.equal(
		root.querySelector( '.lp-interactive-flash-card__front .lp-interactive-flash-card__text' ).textContent.trim(),
		'Front title'
	);
	assert.equal(
		root.querySelector( '.lp-interactive-flash-card__front .lp-interactive-flash-card__image' ).getAttribute( 'src' ),
		'http://example.test/front.jpg'
	);
	assert.equal(
		root.querySelector( '.lp-interactive-flash-card__front .lp-interactive-flash-card__subtitle' ).textContent.trim(),
		'Front subtitle'
	);
	assert.equal(
		root.querySelector( '.lp-interactive-flash-card__back .lp-interactive-flash-card__text' ).textContent.trim(),
		'Back title'
	);
	assert.equal(
		root.querySelector( '.lp-interactive-flash-card__back .lp-interactive-flash-card__image' ).getAttribute( 'src' ),
		'http://example.test/back.jpg'
	);
	assert.equal(
		root.querySelector( '.lp-interactive-flash-card__back .lp-interactive-flash-card__subtitle' ).textContent.trim(),
		'Back subtitle'
	);

	root.querySelector( '.lp-interactive-flash-card' ).click();

	assert.equal(
		root.querySelector( '.lp-interactive-flash-cards__next' ).textContent.trim(),
		'Finish →'
	);
} );

test( 'frontend slider shows Next after returning from a completed last card', () => {
	const deck = [
		{
			front: { title: '<p>Front 1</p>', image_url: '', subtitle: '' },
			back:  { title: '<p>Back 1</p>', image_url: '', subtitle: '' },
		},
		{
			front: { title: '<p>Front 2</p>', image_url: '', subtitle: '' },
			back:  { title: '<p>Back 2</p>', image_url: '', subtitle: '' },
		},
	];

	const dom = new JSDOM( `
		<!doctype html>
		<html>
			<body>
				<div class="lp-interactive-flash-cards" data-layout="slider" data-show-progress="1" data-shuffle="0" data-require-flip="1">
					<div class="lp-interactive-flash-cards__meta"></div>
					<div class="lp-interactive-flash-cards__progress-fill"></div>
					<div class="lp-interactive-flash-cards__progress-label"></div>
					<div class="lp-interactive-flash-cards__card-area">
						<div class="lp-interactive-flash-card" data-flip="0">
							<div class="lp-interactive-flash-card__face lp-interactive-flash-card__front">
								<div class="lp-interactive-flash-card__side-label"></div>
								<div class="lp-interactive-flash-card__title-content lp-interactive-flash-card__text"></div>
								<div class="lp-interactive-flash-card__image-wrap"></div>
								<div class="lp-interactive-flash-card__subtitle"></div>
							</div>
							<div class="lp-interactive-flash-card__face lp-interactive-flash-card__back">
								<div class="lp-interactive-flash-card__side-label"></div>
								<div class="lp-interactive-flash-card__title-content lp-interactive-flash-card__text"></div>
								<div class="lp-interactive-flash-card__image-wrap"></div>
								<div class="lp-interactive-flash-card__subtitle"></div>
							</div>
						</div>
						<button type="button" class="lp-interactive-flash-cards__prev"></button>
						<button type="button" class="lp-interactive-flash-cards__next"></button>
					</div>
					<div class="lp-interactive-flash-cards__done"></div>
					<button type="button" class="lp-interactive-flash-cards__restart"></button>
					<script type="application/json" class="lp-interactive-flash-cards__data">${ JSON.stringify( deck ) }</script>
				</div>
			</body>
		</html>
	` );

	const { LpInteractiveFlashCards } = loadFrontendModule( {
		document:         dom.window.document,
		window:           dom.window,
		MutationObserver: dom.window.MutationObserver,
		DOMParser:        dom.window.DOMParser,
	} );

	const root = dom.window.document.querySelector( '.lp-interactive-flash-cards' );
	new LpInteractiveFlashCards( root ).init();

	root.querySelector( '.lp-interactive-flash-card' ).click();
	root.querySelector( '.lp-interactive-flash-cards__next' ).click();
	root.querySelector( '.lp-interactive-flash-card' ).click();

	assert.equal(
		root.querySelector( '.lp-interactive-flash-cards__next' ).textContent.trim(),
		'Finish →'
	);

	root.querySelector( '.lp-interactive-flash-cards__prev' ).click();

	assert.equal(
		root.querySelector( '.lp-interactive-flash-cards__next' ).textContent.trim(),
		'Next →'
	);
	assert.equal(
		root.querySelector( '.lp-interactive-flash-cards__next' ).disabled,
		false
	);
} );

function __( text ) {
	return text;
}

function sprintf( format, ...args ) {
	let index = 0;
	return String( format ).replace( /%(?:(\d+)\$)?[sdf]/g, ( _match, position ) => {
		const argIndex = position ? parseInt( position, 10 ) - 1 : index++;
		return String( args[ argIndex ] ?? '' );
	} );
}

function isFaceTextEmpty( html ) {
	if ( typeof html !== 'string' || '' === html ) {
		return true;
	}
	return html
		.replace( /<[^>]*>/g, '' )
		.replace( /&nbsp;|&#160;|&#xa0;| /gi, ' ' )
		.replace( /\s+/g, ' ' )
		.trim() === '';
}
