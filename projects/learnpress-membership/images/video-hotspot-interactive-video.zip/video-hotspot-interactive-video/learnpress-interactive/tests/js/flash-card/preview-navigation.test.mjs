import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';
import { JSDOM } from 'jsdom';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadPreviewModule( context = {} ) {
	let source = fs.readFileSync(
		path.join( ROOT, 'assets/src/js/shared/flash-card/preview.js' ),
		'utf8'
	);

	source = source
		.replace( /^import .*;$/gm, '' )
		.replace( /export function /g, 'function ' );

	const script = new vm.Script( `${ source }\n( { mountFlashCardPreview } );` );
	return script.runInNewContext( Object.assign( {
		console,
		__,
		sprintf,
		iconNode: () => null,
		appendSafeHtml,
		isFaceTextEmpty,
		setTimeout,
		clearTimeout,
	}, context ) );
}

test( 'shared preview shows Finish only after slider progress reaches 100 percent', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="preview"></div></body></html>' );
	const document = dom.window.document;
	const { mountFlashCardPreview } = loadPreviewModule( {
		document,
		window:    dom.window,
		DOMParser: dom.window.DOMParser,
	} );

	const preview = mountFlashCardPreview( document.getElementById( 'preview' ), {
		getCards: () => [ {
			front: { title: '<p>Front</p>', image_url: '', subtitle: '' },
			back:  { title: '<p>Back</p>', image_url: '', subtitle: '' },
		} ],
		getSettings: () => ( {
			layout:        'slider',
			show_progress: 1,
			shuffle:       0,
			require_flip:  1,
		} ),
	} );
	preview.render();

	const nextButton = document.querySelector( '.lp-interactive-fc-preview__btn-next' );
	assert.equal( nextButton.textContent.trim(), 'Next' );
	assert.equal( nextButton.disabled, true );

	document.querySelector( '.lp-interactive-fc-preview__card' ).click();

	assert.equal( nextButton.textContent.trim(), 'Finish' );
	assert.equal( nextButton.disabled, false );
} );

test( 'shared preview shows Next after returning from a completed last card', () => {
	const dom = new JSDOM( '<!doctype html><html><body><div id="preview"></div></body></html>' );
	const document = dom.window.document;
	const { mountFlashCardPreview } = loadPreviewModule( {
		document,
		window:    dom.window,
		DOMParser: dom.window.DOMParser,
	} );

	const preview = mountFlashCardPreview( document.getElementById( 'preview' ), {
		getCards: () => [
			{
				front: { title: '<p>Front 1</p>', image_url: '', subtitle: '' },
				back:  { title: '<p>Back 1</p>', image_url: '', subtitle: '' },
			},
			{
				front: { title: '<p>Front 2</p>', image_url: '', subtitle: '' },
				back:  { title: '<p>Back 2</p>', image_url: '', subtitle: '' },
			},
		],
		getSettings: () => ( {
			layout:        'slider',
			show_progress: 1,
			shuffle:       0,
			require_flip:  1,
		} ),
	} );
	preview.render();

	document.querySelector( '.lp-interactive-fc-preview__card' ).click();
	document.querySelector( '.lp-interactive-fc-preview__btn-next' ).click();
	document.querySelector( '.lp-interactive-fc-preview__card' ).click();

	assert.equal(
		document.querySelector( '.lp-interactive-fc-preview__btn-next' ).textContent.trim(),
		'Finish'
	);

	document.querySelector( '.lp-interactive-fc-preview__btn-nav' ).click();

	assert.equal(
		document.querySelector( '.lp-interactive-fc-preview__btn-next' ).textContent.trim(),
		'Next'
	);
	assert.equal(
		document.querySelector( '.lp-interactive-fc-preview__btn-next' ).disabled,
		false
	);
} );

function __( text ) {
	return text;
}

function sprintf( format, ...args ) {
	let index = 0;
	return String( format ).replace( /%(?:(\d+)\$)?[sdf]/g, ( _match, position ) => {
		const argIndex = position ? parseInt( position, 10 ) - 1 : index++;
		return String( args[ argIndex ] ?? '' );
	} );
}

function appendSafeHtml( target, htmlString ) {
	while ( target.firstChild ) {
		target.removeChild( target.firstChild );
	}
	const Parser = target.ownerDocument.defaultView.DOMParser;
	const parsed = new Parser().parseFromString( htmlString || '', 'text/html' );
	while ( parsed.body.firstChild ) {
		target.appendChild( target.ownerDocument.adoptNode( parsed.body.firstChild ) );
	}
}

function isFaceTextEmpty( html ) {
	if ( typeof html !== 'string' || '' === html ) {
		return true;
	}
	return html
		.replace( /<[^>]*>/g, '' )
		.replace( /&nbsp;|&#160;|&#xa0;| /gi, ' ' )
		.replace( /\s+/g, ' ' )
		.trim() === '';
}
