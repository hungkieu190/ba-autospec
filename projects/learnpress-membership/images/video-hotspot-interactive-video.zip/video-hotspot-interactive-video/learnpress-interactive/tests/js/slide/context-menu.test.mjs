import assert from 'node:assert/strict';
import test from 'node:test';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { JSDOM } from 'jsdom';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadModule( dom ) {
	let source = fs.readFileSync(
		path.join( ROOT, 'assets/src/js/admin/builder/slide/services/ContextMenu.js' ),
		'utf8'
	);
	source = source.replace( /export class /g, 'class ' );
	const script = new vm.Script( `${ source }\n( { ContextMenu } );` );
	return script.runInNewContext( {
		document: dom.window.document,
		window:   dom.window,
		console,
	} );
}

function setViewport( dom, width, height ) {
	Object.defineProperty( dom.window, 'innerWidth',  { value: width,  configurable: true } );
	Object.defineProperty( dom.window, 'innerHeight', { value: height, configurable: true } );
}

function callsTracker() {
	const counts = {};
	const make = ( name ) => () => { counts[ name ] = ( counts[ name ] || 0 ) + 1; };
	return {
		counts,
		callbacks: {
			onCopy:      make( 'copy' ),
			onPaste:     make( 'paste' ),
			onDuplicate: make( 'duplicate' ),
			onDelete:    make( 'delete' ),
		},
	};
}

test( 'mount appends a hidden context menu element to document.body', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { ContextMenu } = loadModule( dom );
	const menu = new ContextMenu( callsTracker().callbacks );

	menu.mount();

	const el = dom.window.document.querySelector( '.lp-interactive-slide-editor__context-menu' );
	assert.ok( el, 'menu element must be in DOM' );
	assert.ok( ! el.classList.contains( 'is-open' ), 'menu must start hidden (no is-open class)' );

	const items = el.querySelectorAll( '.lp-interactive-slide-editor__context-menu-item' );
	assert.equal( items.length, 4, 'must render four action items' );
	const labels = Array.from( items ).map( ( it ) => it.querySelector( '.lp-interactive-slide-editor__context-menu-item-label' ).textContent );
	assert.deepEqual( labels, [ 'Copy', 'Paste', 'Duplicate', 'Delete' ] );

	const separators = el.querySelectorAll( '.lp-interactive-slide-editor__context-menu-separator' );
	assert.equal( separators.length, 1, 'must render one separator' );

	menu.destroy();
} );

test( 'mount is idempotent (calling twice does not duplicate the element)', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { ContextMenu } = loadModule( dom );
	const menu = new ContextMenu( callsTracker().callbacks );

	menu.mount();
	menu.mount();

	const all = dom.window.document.querySelectorAll( '.lp-interactive-slide-editor__context-menu' );
	assert.equal( all.length, 1 );

	menu.destroy();
} );

test( 'show with hasTarget shows all items', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	setViewport( dom, 1024, 768 );
	const { ContextMenu } = loadModule( dom );
	const menu = new ContextMenu( callsTracker().callbacks );
	menu.mount();

	menu.show( 100, 100, false );

	const el = dom.window.document.querySelector( '.lp-interactive-slide-editor__context-menu' );
	assert.ok( el.classList.contains( 'is-open' ), 'must add is-open class' );
	const items = el.querySelectorAll( '.lp-interactive-slide-editor__context-menu-item, .lp-interactive-slide-editor__context-menu-separator' );
	items.forEach( ( it ) => {
		assert.ok( ! it.classList.contains( 'is-hidden' ), 'no item should be hidden' );
	} );

	menu.destroy();
} );

test( 'show with pasteOnly hides selection-requiring items', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	setViewport( dom, 1024, 768 );
	const { ContextMenu } = loadModule( dom );
	const menu = new ContextMenu( callsTracker().callbacks );
	menu.mount();

	menu.show( 100, 100, true );

	const el = dom.window.document.querySelector( '.lp-interactive-slide-editor__context-menu' );
	const labelOf = ( item ) => item.querySelector( '.lp-interactive-slide-editor__context-menu-item-label' )?.textContent || '';
	const items = Array.from( el.querySelectorAll( '.lp-interactive-slide-editor__context-menu-item' ) );

	const visibility = items.reduce( ( acc, it ) => {
		acc[ labelOf( it ) ] = ! it.classList.contains( 'is-hidden' );
		return acc;
	}, {} );

	assert.equal( visibility.Copy,      false );
	assert.equal( visibility.Paste,     true );
	assert.equal( visibility.Duplicate, false );
	assert.equal( visibility.Delete,    false );

	const separator = el.querySelector( '.lp-interactive-slide-editor__context-menu-separator' );
	assert.ok( separator.classList.contains( 'is-hidden' ), 'separator is hidden in paste-only mode' );

	menu.destroy();
} );

test( 'clicking a menu item invokes the matching callback and hides menu', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	setViewport( dom, 1024, 768 );
	const { ContextMenu } = loadModule( dom );
	const tracker = callsTracker();
	const menu = new ContextMenu( tracker.callbacks );
	menu.mount();
	menu.show( 100, 100, false );

	const el = dom.window.document.querySelector( '.lp-interactive-slide-editor__context-menu' );
	const items = Array.from( el.querySelectorAll( '.lp-interactive-slide-editor__context-menu-item' ) );
	const labelOf = ( item ) => item.querySelector( '.lp-interactive-slide-editor__context-menu-item-label' )?.textContent || '';

	items.find( ( it ) => labelOf( it ) === 'Copy' ).dispatchEvent( new dom.window.MouseEvent( 'click', { bubbles: true } ) );
	assert.equal( tracker.counts.copy, 1 );
	assert.ok( ! el.classList.contains( 'is-open' ), 'menu must hide after action' );

	menu.show( 100, 100, false );
	items.find( ( it ) => labelOf( it ) === 'Delete' ).dispatchEvent( new dom.window.MouseEvent( 'click', { bubbles: true } ) );
	assert.equal( tracker.counts.delete, 1 );

	menu.destroy();
} );

test( 'show repositions when menu overflows viewport edges', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	setViewport( dom, 200, 200 );
	const { ContextMenu } = loadModule( dom );
	const menu = new ContextMenu( callsTracker().callbacks );
	menu.mount();

	const el = dom.window.document.querySelector( '.lp-interactive-slide-editor__context-menu' );
	// JSDOM gives 0×0 layout — stub getBoundingClientRect so reposition branches trigger.
	el.getBoundingClientRect = () => ( {
		right:  300, // > innerWidth (200)
		bottom: 300, // > innerHeight (200)
		width:  140,
		height: 150,
	} );

	menu.show( 180, 180, false );

	assert.equal( el.style.left, ( 180 - 140 ) + 'px', 'left must flip to fit horizontally' );
	assert.equal( el.style.top,  ( 180 - 150 ) + 'px', 'top must flip to fit vertically' );

	menu.destroy();
} );

test( 'hide removes the is-open class but keeps the element mounted', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	setViewport( dom, 1024, 768 );
	const { ContextMenu } = loadModule( dom );
	const menu = new ContextMenu( callsTracker().callbacks );
	menu.mount();
	menu.show( 50, 50, false );

	const el = dom.window.document.querySelector( '.lp-interactive-slide-editor__context-menu' );
	assert.ok( el.classList.contains( 'is-open' ) );

	menu.hide();
	assert.ok( ! el.classList.contains( 'is-open' ) );
	assert.ok( el.isConnected, 'element should remain in DOM after hide' );

	menu.destroy();
} );

test( 'destroy removes element and detaches global listeners', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { ContextMenu } = loadModule( dom );
	const tracker = callsTracker();
	const menu = new ContextMenu( tracker.callbacks );
	menu.mount();

	menu.destroy();

	assert.equal( dom.window.document.querySelector( '.lp-interactive-slide-editor__context-menu' ), null );

	// After destroy, a document click would crash if listener still attached AND tried to use this.element.
	// The handler is { hide }, and hide guards on this.element; ensure no throw.
	assert.doesNotThrow( () => {
		dom.window.document.dispatchEvent( new dom.window.MouseEvent( 'click', { bubbles: true } ) );
	} );
} );

test( 'show with missing callbacks does not throw on click', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	setViewport( dom, 1024, 768 );
	const { ContextMenu } = loadModule( dom );
	const menu = new ContextMenu( {} ); // no callbacks at all
	menu.mount();
	menu.show( 100, 100, false );

	const el = dom.window.document.querySelector( '.lp-interactive-slide-editor__context-menu' );
	const copyItem = Array.from( el.querySelectorAll( '.lp-interactive-slide-editor__context-menu-item' ) )
		.find( ( it ) => it.querySelector( '.lp-interactive-slide-editor__context-menu-item-label' ).textContent === 'Copy' );

	assert.doesNotThrow( () => {
		copyItem.dispatchEvent( new dom.window.MouseEvent( 'click', { bubbles: true } ) );
	} );
	assert.ok( ! el.classList.contains( 'is-open' ), 'menu still hides after no-op click' );

	menu.destroy();
} );
