import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadModule( context = {} ) {
	let source = fs.readFileSync(
		path.join( ROOT, 'assets/src/js/admin/builder/slide/services/GoogleFontService.js' ),
		'utf8'
	);

	source = source
		.replace( /^import .*;$/gm, "const GG_FONTS_API_KEY = 'test-key';" )
		.replace( /export class /g, 'class ' );

	const script = new vm.Script( `${ source }\n( { GoogleFontService } );` );
	return script.runInNewContext( Object.assign( { console }, context ) );
}

test( 'google font service keeps JetBrains Mono out of bundled system defaults', async () => {
	const { GoogleFontService } = loadModule( {
		fetch: () => Promise.resolve( {
			json: () => Promise.resolve( {
				items: [
					{
						family:   'JetBrains Mono',
						category: 'monospace',
						variants: [ '100', '200', '300', 'regular', '500', '600', '700', '800' ],
						files:    {},
					},
				],
			} ),
		} ),
	} );

	const service = new GoogleFontService();
	const fonts = await service.listFonts();
	const jetBrainsFonts = fonts.filter( ( font ) => font.family === 'JetBrains Mono' );

	assert.equal( jetBrainsFonts.length, 1 );
	assert.equal( jetBrainsFonts[0].category, 'monospace' );
	assert.deepEqual(
		JSON.parse( JSON.stringify( jetBrainsFonts[0].variants ) ),
		[ '100', '200', '300', 'regular', '500', '600', '700', '800' ]
	);
	assert.deepEqual(
		JSON.parse( JSON.stringify( fonts.slice( 0, 3 ).map( ( font ) => font.family ) ) ),
		[ 'Inter', 'Arial', 'Georgia' ]
	);
} );

test( 'google font service keeps system fonts when the Google API request fails', async () => {
	const { GoogleFontService } = loadModule( {
		fetch: () => Promise.reject( new Error( 'quota exceeded' ) ),
	} );

	const service = new GoogleFontService();
	const fonts = await service.listFonts();

	assert.deepEqual(
		JSON.parse( JSON.stringify( fonts.map( ( font ) => font.family ) ) ),
		[ 'Inter', 'Arial', 'Georgia' ]
	);
} );

test( 'google font service adds a cached system copy without removing the current Google font row', async () => {
	const { GoogleFontService } = loadModule( {
		fetch: () => Promise.resolve( {
			json: () => Promise.resolve( {
				items: [
					{
						family:   'Roboto',
						category: 'sans-serif',
						variants: [ 'regular', '700' ],
						files:    { regular: 'https://fonts.gstatic.com/s/roboto/v30/regular.woff2' },
					},
				],
			} ),
		} ),
	} );

	const service = new GoogleFontService();
	await service.listFonts();
	service.rememberCachedFont( {
		family:   'Roboto',
		variants: [ 'regular', '700' ],
		fonts:    {
			regular: {
				url:    '/uploads/interactive-fonts/roboto/regular.woff2',
				weight: 400,
				style:  'normal',
			},
		},
	} );

	const fonts = await service.listFonts();
	const robotoFonts = fonts.filter( ( font ) => font.family === 'Roboto' );

	assert.equal( robotoFonts.length, 2 );
	assert.equal( robotoFonts[0].category, 'system' );
	assert.equal( robotoFonts[0].cached, true );
	assert.equal( robotoFonts[1].category, 'sans-serif' );
} );

test( 'google font service refreshes stale cached fonts when Google source format changes', async () => {
	const actions = [];
	const { GoogleFontService } = loadModule( {
		FormData,
		document: {
			fonts: {
				add: () => {},
				load: () => Promise.resolve( [] ),
				ready: Promise.resolve(),
			},
		},
		FontFace: class {
			constructor( family, source ) {
				this.family = family;
				this.source = source;
			}

			load() {
				return Promise.resolve( this );
			}
		},
		fetch: ( url, options = {} ) => {
			if ( String( url ).includes( 'googleapis.com/webfonts' ) ) {
				return Promise.resolve( {
					json: () => Promise.resolve( {
						items: [
							{
								family:   'Italianno',
								category: 'handwriting',
								variants: [ 'regular' ],
								files:    { regular: 'https://fonts.gstatic.com/s/italianno/v18/italianno-regular.ttf' },
							},
						],
					} ),
				} );
			}

			const action = options.body && typeof options.body.get === 'function' ? options.body.get( 'action' ) : '';
			actions.push( action );
			if ( action === 'lp_interactive_list_cached_google_fonts' ) {
				return Promise.resolve( {
					json: () => Promise.resolve( {
						success: true,
						data:    {
							fonts: [
								{
									family:   'Italianno',
									variants: [ 'regular' ],
									fonts:    {
										regular: {
											url:    '/uploads/interactive-fonts/italianno/regular.woff2',
											weight: 400,
											style:  'normal',
											format: 'woff2',
										},
									},
								},
							],
						},
					} ),
				} );
			}

			if ( action === 'lp_interactive_cache_google_font' ) {
				return Promise.resolve( {
					json: () => Promise.resolve( {
						success: true,
						data:    {
							family:   'Italianno',
							variants: [ 'regular' ],
							fonts:    {
								regular: {
									url:    '/uploads/interactive-fonts/italianno/regular.ttf',
									weight: 400,
									style:  'normal',
									format: 'truetype',
								},
							},
						},
					} ),
				} );
			}

			return Promise.reject( new Error( 'Unexpected request' ) );
		},
	} );

	const service = new GoogleFontService( { nonce: 'nonce', ajaxUrl: '/ajax' } );
	await service.listFonts();
	await service.loadFontVariant( 'Italianno', 'regular' );

	assert.deepEqual(
		actions,
		[
			'lp_interactive_list_cached_google_fonts',
			'lp_interactive_cache_google_font',
		]
	);
} );

test( 'google font service refreshes cached Google fonts that do not have local CSS yet', async () => {
	const actions = [];
	const { GoogleFontService } = loadModule( {
		FormData,
		document: {
			head: {
				appendChild: ( element ) => {
					element.onload();
				},
			},
			createElement: () => ( {} ),
			fonts: {
				load: () => Promise.resolve( [] ),
				ready: Promise.resolve(),
			},
		},
		fetch: ( url, options = {} ) => {
			if ( String( url ).includes( 'googleapis.com/webfonts' ) ) {
				return Promise.resolve( {
					json: () => Promise.resolve( {
						items: [
							{
								family:   'Roboto',
								category: 'sans-serif',
								variants: [ 'regular' ],
								files:    { regular: 'https://fonts.gstatic.com/s/roboto/v30/regular.woff2' },
							},
						],
					} ),
				} );
			}

			const action = options.body && typeof options.body.get === 'function' ? options.body.get( 'action' ) : '';
			actions.push( action );
			if ( action === 'lp_interactive_list_cached_google_fonts' ) {
				return Promise.resolve( {
					json: () => Promise.resolve( {
						success: true,
						data:    {
							fonts: [
								{
									family:   'Roboto',
									variants: [ 'regular' ],
									fonts:    {
										regular: {
											url:    '/uploads/interactive-fonts/roboto/regular.woff2',
											weight: 400,
											style:  'normal',
											format: 'woff2',
										},
									},
								},
							],
						},
					} ),
				} );
			}

			if ( action === 'lp_interactive_cache_google_font' ) {
				return Promise.resolve( {
					json: () => Promise.resolve( {
						success: true,
						data:    {
							family:   'Roboto',
							cssUrl:   '/uploads/interactive-fonts/roboto/font.css',
							variants: [ 'regular' ],
							fonts:    {
								regular: {
									url:    '/uploads/interactive-fonts/roboto/regular-local.woff2',
									weight: 400,
									style:  'normal',
									format: 'woff2',
								},
							},
						},
					} ),
				} );
			}

			return Promise.reject( new Error( 'Unexpected request' ) );
		},
	} );

	const service = new GoogleFontService( { nonce: 'nonce', ajaxUrl: '/ajax' } );
	await service.listFonts();
	await service.loadFontVariant( 'Roboto', 'regular' );

	assert.deepEqual(
		actions,
		[
			'lp_interactive_list_cached_google_fonts',
			'lp_interactive_cache_google_font',
		]
	);
} );

test( 'google font service caches missing variants even when a cached CSS file already exists', async () => {
	const actions = [];
	const { GoogleFontService } = loadModule( {
		FormData,
		document: {
			head: {
				appendChild: ( element ) => {
					element.onload();
				},
			},
			createElement: () => ( {} ),
			fonts: {
				load: () => Promise.resolve( [] ),
				ready: Promise.resolve(),
			},
		},
		fetch: ( url, options = {} ) => {
			if ( String( url ).includes( 'googleapis.com/webfonts' ) ) {
				return Promise.resolve( {
					json: () => Promise.resolve( {} ),
				} );
			}

			const action = options.body && typeof options.body.get === 'function' ? options.body.get( 'action' ) : '';
			actions.push( action );
			if ( action === 'lp_interactive_list_cached_google_fonts' ) {
				return Promise.resolve( {
					json: () => Promise.resolve( {
						success: true,
						data:    {
							fonts: [
								{
									family:   'Roboto',
									cssUrl:   '/uploads/interactive-fonts/roboto/font.css',
									variants: [ 'regular', '700' ],
									fonts:    {
										regular: {
											url:    '/uploads/interactive-fonts/roboto/regular-local.woff2',
											weight: 400,
											style:  'normal',
											format: 'woff2',
										},
									},
								},
							],
						},
					} ),
				} );
			}

			if ( action === 'lp_interactive_cache_google_font' ) {
				return Promise.resolve( {
					json: () => Promise.resolve( {
						success: true,
						data:    {
							family:   'Roboto',
							cssUrl:   '/uploads/interactive-fonts/roboto/font.css',
							variants: [ 'regular', '700' ],
							fonts:    {
								regular: {
									url:    '/uploads/interactive-fonts/roboto/regular-local.woff2',
									weight: 400,
									style:  'normal',
									format: 'woff2',
								},
								700: {
									url:    '/uploads/interactive-fonts/roboto/700-local.woff2',
									weight: 700,
									style:  'normal',
									format: 'woff2',
								},
							},
						},
					} ),
				} );
			}

			return Promise.reject( new Error( 'Unexpected request' ) );
		},
	} );

	const service = new GoogleFontService( { nonce: 'nonce', ajaxUrl: '/ajax' } );
	await service.ensureCachedFonts();
	await service.loadFontVariant( 'Roboto', '700' );

	assert.deepEqual(
		actions,
		[
			'lp_interactive_list_cached_google_fonts',
			'lp_interactive_cache_google_font',
		]
	);
} );

test( 'google font service does not reuse completed cache promises', async () => {
	let cacheCalls = 0;
	const { GoogleFontService } = loadModule( {
		FormData,
		fetch: ( url, options = {} ) => {
			const action = options.body && typeof options.body.get === 'function' ? options.body.get( 'action' ) : '';
			if ( action !== 'lp_interactive_cache_google_font' ) {
				return Promise.reject( new Error( 'Unexpected request' ) );
			}

			cacheCalls += 1;
			return Promise.resolve( {
				json: () => Promise.resolve( {
					success: true,
					data:    {
						family:   'Italianno',
						variants: [ 'regular' ],
						fonts:    {
							regular: {
								url:    '/uploads/interactive-fonts/italianno/regular.ttf',
								weight: 400,
								style:  'normal',
								format: 'truetype',
							},
						},
					},
				} ),
			} );
		},
	} );
	const service = new GoogleFontService( { nonce: 'nonce', ajaxUrl: '/ajax' } );
	const font = {
		family:   'Italianno',
		variants: [ 'regular' ],
		files:    { regular: 'https://fonts.gstatic.com/s/italianno/v18/italianno-regular.ttf' },
	};

	await service.cacheFontVariant( font, 'regular' );
	await service.cacheFontVariant( font, 'regular' );

	assert.equal( cacheCalls, 2 );
} );

test( 'google font service trusts loaded FontFace without an extra document font load', async () => {
	let fontLoads = 0;
	let readyAwaited = false;
	const ready = Promise.resolve().then( () => {
		readyAwaited = true;
	} );
	const { GoogleFontService } = loadModule( {
		document: {
			fonts: {
				add: () => {},
				load: () => {
					fontLoads += 1;
					return Promise.resolve( [] );
				},
				ready,
			},
		},
		FontFace: class {
			load() {
				return Promise.resolve( this );
			}
		},
		fetch: () => Promise.reject( new Error( 'Unexpected request' ) ),
	} );
	const service = new GoogleFontService();

	await service.loadFontFace(
		'Italianno',
		'regular',
		{
			url:    '/uploads/interactive-fonts/italianno/regular.ttf',
			weight: 400,
			style:  'normal',
			format: 'truetype',
		}
	);

	assert.equal( fontLoads, 0 );
	assert.equal( readyAwaited, true );
} );

test( 'google font service injects cached font CSS before using FontFace entries', async () => {
	let appendedHref = '';
	let fontFaceCreated = false;
	let readyAwaited = false;
	const ready = Promise.resolve().then( () => {
		readyAwaited = true;
	} );
	const { GoogleFontService } = loadModule( {
		document: {
			head: {
				appendChild: ( element ) => {
					appendedHref = element.href;
					element.onload();
				},
			},
			createElement: ( tag ) => ( { tagName: tag } ),
			fonts: {
				load: () => Promise.resolve( [] ),
				ready,
			},
		},
		FontFace: class {
			constructor() {
				fontFaceCreated = true;
			}
		},
		fetch: () => Promise.reject( new Error( 'Unexpected request' ) ),
	} );
	const service = new GoogleFontService();

	await service.loadCachedFont( {
		family: 'Italianno',
		cssUrl: '/uploads/interactive-fonts/italianno/font.css',
		fonts:  {
			regular: {
				url:    '/uploads/interactive-fonts/italianno/latin.woff2',
				weight: 400,
				style:  'normal',
			},
		},
	} );

	assert.equal( appendedHref, '/uploads/interactive-fonts/italianno/font.css' );
	assert.equal( fontFaceCreated, false );
	assert.equal( readyAwaited, true );
} );
