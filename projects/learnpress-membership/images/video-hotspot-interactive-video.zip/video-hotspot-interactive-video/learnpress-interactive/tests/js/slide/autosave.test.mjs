import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadModule( relativePath, exportNames, context = {} ) {
	let source = fs.readFileSync( path.join( ROOT, relativePath ), 'utf8' );

	source = source
		.replace( /^import .*;$/gm, '' )
		.replace( /export class /g, 'class ' )
		.replace( /export function /g, 'function ' );

	const script = new vm.Script( `${ source }\n( { ${ exportNames.join( ', ' ) } } );` );
	return script.runInNewContext( Object.assign( { console }, context ) );
}

function createStore( initialState ) {
	let state = Object.assign(
		{
			deckTitle:     'Deck title',
			status:        'publish',
			dirty:         true,
			dirtyRevision: 1,
		},
		initialState || {}
	);

	return {
		get: () => state,
		setState: ( patch ) => {
			state = Object.assign( {}, state, patch );
		},
	};
}

function createAutosave( stateOverrides = {}, optionOverrides = {} ) {
	const store = createStore( stateOverrides );
	const { SlideAutosave } = loadModule(
		'assets/src/js/admin/builder/slide/services/SlideAutosave.js',
		[ 'SlideAutosave' ],
		{
			__,
			fetch: () => Promise.resolve( {
				json: () => Promise.resolve( { success: true, data: {} } ),
			} ),
			FormData,
			TIMING: { DEBOUNCE_SAVE: 10 },
			STATUS_DEFAULTS: {
				DEFAULT: 'draft',
				ALLOWED: [ 'draft', 'publish' ],
			},
			window: {
				ajaxurl: '/wp-admin/admin-ajax.php',
				clearTimeout,
				setTimeout,
			},
		}
	);

	return new SlideAutosave( Object.assign(
		{
			wrap: {
				dataset: {
					ajaxAction: 'lp_interactive_save',
					nonce:      'nonce',
				},
			},
			bootstrap:            { id: 10 },
			store,
			buildSlidesForSave:    () => [ { content: { version: '', objects: [] }, extra_data: { width: 842, height: 595 } } ],
			buildSettingsForSave: () => ( {} ),
			buildCurrentSlideContentForSave: () => ( {
				slideId:     123,
				content:    { version: '7.0.0', objects: [] },
				extra_data: { width: 842, height: 595 },
			} ),
		},
		optionOverrides
	) );
}

test( 'slide autosave builds a parent meta payload without child rows', () => {
	const autosave = createAutosave( { deckTitle: 'Deck title', status: 'draft' } );
	const body = autosave.metaFormData();

	assert.equal( body.get( 'action' ), 'lp_interactive_save_meta' );
	assert.equal( body.get( 'title' ), 'Deck title' );
	assert.equal( body.get( 'status' ), 'draft' );
	assert.equal( body.get( 'settings' ), '{}' );
	assert.equal( body.has( 'items' ), false );
	assert.equal( body.has( 'slide' ), false );
} );

test( 'slide autosave builds a current slide content payload for only the active slide', () => {
	const autosave = createAutosave();
	const body = autosave.currentSlideContentFormData();

	assert.equal( body.get( 'action' ), 'lp_interactive_save_slide_content' );
	assert.equal( body.get( 'slide_id' ), '123' );
	assert.deepEqual(
		JSON.parse( body.get( 'slide' ) ),
		{
			content:    { version: '7.0.0', objects: [] },
			extra_data: { width: 842, height: 595 },
		}
	);
	assert.equal( body.has( 'items' ), false );
	assert.equal( body.has( 'title' ), false );
} );

test( 'slide autosave keeps full slide list payload for structural changes', () => {
	const autosave = createAutosave( { deckTitle: 'Deck title', status: 'publish' } );
	const body = autosave.slideListFormData();

	assert.equal( body.get( 'action' ), 'lp_interactive_save' );
	assert.equal( body.get( 'title' ), 'Deck title' );
	assert.equal( body.has( 'items' ), true );
	assert.deepEqual(
		JSON.parse( body.get( 'items' ) ),
		[ { content: { version: '', objects: [] }, extra_data: { width: 842, height: 595 } } ]
	);
} );

test( 'slide autosave builds a create-slide payload for a newly added slide', () => {
	const autosave = createAutosave(
		{
			slides: [
				{ clientId: 's1', slideId: 11, content: { version: '', objects: [] } },
				{ clientId: 's2', content: { version: '7.0.0', objects: [] } },
			],
		},
		{
			buildCurrentSlideContentForSave: ( args ) => ( {
				slideId:     0,
				content:    { version: '7.0.0', objects: [] },
				extra_data: { width: 842, height: 595 },
				clientId:   's2',
				sortOrder:  args.slideIndex,
			} ),
		}
	);
	const body = autosave.createSlideFormData( { slideIndex: 1, targetSlideClientId: 's2' } );

	assert.equal( body.get( 'action' ), 'lp_interactive_create_slide' );
	assert.equal( body.get( 'sort_order' ), '1' );
	assert.deepEqual(
		JSON.parse( body.get( 'slide' ) ),
		{
			content:    { version: '7.0.0', objects: [] },
			extra_data: { width: 842, height: 595 },
		}
	);
	assert.equal( body.has( 'items' ), false );
} );

test( 'slide autosave builds a create-slide payload from the target slide client ID', () => {
	let receivedArgs = null;
	const autosave = createAutosave(
		{
			slides: [
				{ clientId: 's2', content: { version: '7.0.0', objects: [ { text: 'Target' } ] } },
				{ clientId: 's1', slideId: 11, content: { version: '', objects: [] } },
			],
		},
		{
			buildCurrentSlideContentForSave: ( args ) => {
				receivedArgs = args;
				return {
					slideId:     0,
					content:    { version: '7.0.0', objects: [ { text: args.targetSlideClientId } ] },
					extra_data: { width: 842, height: 595 },
				};
			},
		}
	);
	const body = autosave.createSlideFormData( { slideIndex: 1, targetSlideClientId: 's2' } );

	assert.equal( receivedArgs.targetSlideClientId, 's2' );
	assert.deepEqual(
		JSON.parse( body.get( 'slide' ) ).content.objects,
		[ { text: 's2' } ]
	);
} );

test( 'slide autosave builds a delete-slide payload for one removed slide', () => {
	const autosave = createAutosave();
	const body = autosave.deleteSlideFormData( { slideId: 44 } );

	assert.equal( body.get( 'action' ), 'lp_interactive_delete_slide' );
	assert.equal( body.get( 'slide_id' ), '44' );
	assert.equal( body.has( 'items' ), false );
	assert.equal( body.has( 'slide' ), false );
} );

test( 'slide autosave builds a reorder-slides payload with slide IDs only', () => {
	const autosave = createAutosave( {
		slides: [
			{ clientId: 's2', slideId: 22 },
			{ clientId: 's1', slideId: 11 },
		],
	} );
	const body = autosave.reorderSlidesFormData();

	assert.equal( body.get( 'action' ), 'lp_interactive_reorder_slides' );
	assert.deepEqual( JSON.parse( body.get( 'slide_ids' ) ), [ 22, 11 ] );
	assert.equal( body.has( 'items' ), false );
} );

test( 'slide autosave routes create list action to one slide endpoint', async () => {
	let requestBody;
	const store = createStore( {
		slides: [
			{ clientId: 's1', slideId: 11, content: { version: '', objects: [] } },
			{ clientId: 's2', content: { version: '7.0.0', objects: [] } },
		],
	} );
	const { SlideAutosave } = loadModule(
		'assets/src/js/admin/builder/slide/services/SlideAutosave.js',
		[ 'SlideAutosave' ],
		{
			__,
			fetch: ( _url, options ) => {
				requestBody = options.body;
				return Promise.resolve( {
					json: () => Promise.resolve( {
						success: true,
						data:    {
							slide: { ID: 44 },
						},
					} ),
				} );
			},
			FormData,
			TIMING: { DEBOUNCE_SAVE: 10 },
			STATUS_DEFAULTS: {
				DEFAULT: 'draft',
				ALLOWED: [ 'draft', 'publish' ],
			},
			window: { ajaxurl: '/wp-admin/admin-ajax.php' },
		}
	);
	const autosave = new SlideAutosave( {
		wrap: {
			dataset: {
				ajaxAction: 'lp_interactive_save',
				nonce:      'nonce',
			},
		},
		bootstrap:            { id: 10 },
		store,
		buildSlidesForSave:    () => [],
		buildSettingsForSave: () => ( {} ),
		buildCurrentSlideContentForSave: () => ( {
			slideId:     0,
			content:    { version: '7.0.0', objects: [] },
			extra_data: { width: 842, height: 595 },
		} ),
	} );

	await autosave.saveSlideListNow( {
		silent:     true,
		listAction: {
			type:                'create',
			slideIndex:          1,
			targetSlideClientId: 's2',
			reorderAfterSuccess: false,
		},
	} );

	assert.equal( requestBody.get( 'action' ), 'lp_interactive_create_slide' );
	assert.equal( requestBody.has( 'items' ), false );
	assert.equal( store.get().slides[1].slideId, 44 );
} );

test( 'slide autosave syncs slide IDs returned after a full slide list save', async () => {
	const store = createStore( {
		slides: [
			{ clientId: 's1', content: { version: '', objects: [] } },
			{ clientId: 's2', content: { version: '', objects: [] } },
		],
	} );
	const { SlideAutosave } = loadModule(
		'assets/src/js/admin/builder/slide/services/SlideAutosave.js',
		[ 'SlideAutosave' ],
		{
			__,
			fetch: () => Promise.resolve( {
				json: () => Promise.resolve( {
					success: true,
					data:    {
						items: [
							{ ID: 101 },
							{ ID: 102 },
						],
					},
				} ),
			} ),
			FormData,
			TIMING: { DEBOUNCE_SAVE: 10 },
			STATUS_DEFAULTS: {
				DEFAULT: 'draft',
				ALLOWED: [ 'draft', 'publish' ],
			},
			window: { ajaxurl: '/wp-admin/admin-ajax.php' },
		}
	);
	const autosave = new SlideAutosave( {
		wrap: {
			dataset: {
				ajaxAction: 'lp_interactive_save',
				nonce:      'nonce',
			},
		},
		bootstrap:            { id: 10 },
		store,
		buildSlidesForSave:    () => [],
		buildSettingsForSave: () => ( {} ),
		buildCurrentSlideContentForSave: () => null,
	} );

	await autosave.saveSlideListNow( { silent: true } );

	assert.equal( store.get().slides[0].slideId, 101 );
	assert.equal( store.get().slides[1].slideId, 102 );
} );

test( 'slide autosave skips stale slide ID sync when slide order changed during list save', async () => {
	let resolveResponse;
	const responsePromise = new Promise( ( resolve ) => {
		resolveResponse = resolve;
	} );
	const store = createStore( {
		slides: [
			{ clientId: 's1', content: { version: '', objects: [] } },
			{ clientId: 's2', content: { version: '', objects: [] } },
		],
	} );
	const { SlideAutosave } = loadModule(
		'assets/src/js/admin/builder/slide/services/SlideAutosave.js',
		[ 'SlideAutosave' ],
		{
			__,
			fetch: () => responsePromise,
			FormData,
			TIMING: { DEBOUNCE_SAVE: 10 },
			STATUS_DEFAULTS: {
				DEFAULT: 'draft',
				ALLOWED: [ 'draft', 'publish' ],
			},
			window: {
				ajaxurl: '/wp-admin/admin-ajax.php',
				clearTimeout,
				setTimeout,
			},
		}
	);
	const autosave = new SlideAutosave( {
		wrap: {
			dataset: {
				ajaxAction: 'lp_interactive_save',
				nonce:      'nonce',
			},
		},
		bootstrap:            { id: 10 },
		store,
		buildSlidesForSave:    () => [],
		buildSettingsForSave: () => ( {} ),
		buildCurrentSlideContentForSave: () => null,
	} );

	const savePromise = autosave.saveSlideListNow( { silent: true } );
	store.setState( {
		slides: [
			store.get().slides[1],
			store.get().slides[0],
		],
	} );
	resolveResponse( {
		json: () => Promise.resolve( {
			success: true,
			data:    {
				items: [
					{ ID: 101 },
					{ ID: 102 },
				],
			},
		} ),
	} );
	await savePromise;

	assert.equal( store.get().slides[0].clientId, 's2' );
	assert.equal( store.get().slides[0].slideId, undefined );
	assert.equal( store.get().slides[1].clientId, 's1' );
	assert.equal( store.get().slides[1].slideId, undefined );
} );

test( 'slide autosave keeps multiple queued save types while one request is running', async () => {
	const requests = [];
	let resolveFirst;
	const firstResponse = new Promise( ( resolve ) => {
		resolveFirst = resolve;
	} );
	const fetch = ( _url, options ) => {
		requests.push( options.body.get( 'action' ) );
		if ( 1 === requests.length ) {
			return firstResponse;
		}
		return Promise.resolve( {
			json: () => Promise.resolve( { success: true, data: {} } ),
		} );
	};
	const store = createStore( { dirtyRevision: 1 } );
	const { SlideAutosave } = loadModule(
		'assets/src/js/admin/builder/slide/services/SlideAutosave.js',
		[ 'SlideAutosave' ],
		{
			__,
			fetch,
			FormData,
			TIMING: { DEBOUNCE_SAVE: 10 },
			STATUS_DEFAULTS: {
				DEFAULT: 'draft',
				ALLOWED: [ 'draft', 'publish' ],
			},
			window: { ajaxurl: '/wp-admin/admin-ajax.php' },
		}
	);
	const autosave = new SlideAutosave( {
		wrap: {
			dataset: {
				ajaxAction: 'lp_interactive_save',
				nonce:      'nonce',
			},
		},
		bootstrap:            { id: 10 },
		store,
		buildSlidesForSave:    () => [],
		buildSettingsForSave: () => ( {} ),
		buildCurrentSlideContentForSave: () => ( {
			slideId:     123,
			content:    { version: '7.0.0', objects: [] },
			extra_data: { width: 842, height: 595 },
		} ),
	} );

	const firstSave = autosave.saveMetaNow( { silent: true } );
	autosave.saveCurrentSlideNow( { silent: true } );
	autosave.saveSlideListNow( { silent: true } );

	resolveFirst( {
		json: () => Promise.resolve( { success: true, data: {} } ),
	} );
	await firstSave;
	await new Promise( ( resolve ) => setTimeout( resolve, 0 ) );
	await new Promise( ( resolve ) => setTimeout( resolve, 0 ) );

	assert.deepEqual(
		requests,
		[
			'lp_interactive_save_meta',
			'lp_interactive_save_slide_content',
			'lp_interactive_save',
		]
	);
} );

test( 'slide autosave keeps separate debounce timers per slide index', async () => {
	const savedIndexes = [];
	const autosave = createAutosave(
		{},
		{
			debounceMs: 1,
			buildCurrentSlideContentForSave: ( args ) => {
				savedIndexes.push( args.slideIndex );
				return {
					slideId:     100 + args.slideIndex,
					content:    { version: '7.0.0', objects: [] },
					extra_data: { width: 842, height: 595 },
				};
			},
		}
	);

	autosave.saveCurrentSlideDebounced( { slideIndex: 0 } );
	autosave.saveCurrentSlideDebounced( { slideIndex: 1 } );
	await new Promise( ( resolve ) => setTimeout( resolve, 20 ) );

	assert.deepEqual( savedIndexes, [ 0, 1 ] );
} );

test( 'slide autosave builds queued current slide payload after list save syncs slide IDs', async () => {
	const requests = [];
	let resolveFirst;
	const firstResponse = new Promise( ( resolve ) => {
		resolveFirst = resolve;
	} );
	const store = createStore( {
		slides: [
			{ clientId: 's1', slideId: 10, content: { version: '', objects: [] } },
		],
		dirtyRevision: 1,
	} );
	const { SlideAutosave } = loadModule(
		'assets/src/js/admin/builder/slide/services/SlideAutosave.js',
		[ 'SlideAutosave' ],
		{
			__,
			fetch: ( _url, options ) => {
				requests.push( options.body );
				if ( 1 === requests.length ) {
					return firstResponse;
				}
				return Promise.resolve( {
					json: () => Promise.resolve( { success: true, data: {} } ),
				} );
			},
			FormData,
			TIMING: { DEBOUNCE_SAVE: 10 },
			STATUS_DEFAULTS: {
				DEFAULT: 'draft',
				ALLOWED: [ 'draft', 'publish' ],
			},
			window: {
				ajaxurl: '/wp-admin/admin-ajax.php',
				clearTimeout,
				setTimeout,
			},
		}
	);
	const autosave = new SlideAutosave( {
		wrap: {
			dataset: {
				ajaxAction: 'lp_interactive_save',
				nonce:      'nonce',
			},
		},
		bootstrap:            { id: 10 },
		store,
		buildSlidesForSave:    () => [],
		buildSettingsForSave: () => ( {} ),
		buildCurrentSlideContentForSave: () => ( {
			slideId:     store.get().slides[0].slideId,
			content:    { version: '7.0.0', objects: [] },
			extra_data: { width: 842, height: 595 },
		} ),
	} );

	const listSave = autosave.saveSlideListNow( { silent: true } );
	autosave.saveCurrentSlideNow( { silent: true, slideIndex: 0 } );

	resolveFirst( {
		json: () => Promise.resolve( {
			success: true,
			data:    { items: [ { ID: 200 } ] },
		} ),
	} );
	await listSave;
	await new Promise( ( resolve ) => setTimeout( resolve, 0 ) );

	assert.equal( requests[1].get( 'action' ), 'lp_interactive_save_slide_content' );
	assert.equal( requests[1].get( 'slide_id' ), '200' );
} );

test( 'slide autosave does not clear dirty state when a newer revision exists', async () => {
	let resolveResponse;
	const fetchPromise = new Promise( ( resolve ) => {
		resolveResponse = resolve;
	} );

	const store = createStore();
	const { SlideAutosave } = loadModule(
		'assets/src/js/admin/builder/slide/services/SlideAutosave.js',
		[ 'SlideAutosave' ],
		{
			__,
			fetch: () => fetchPromise,
			FormData,
			TIMING: { DEBOUNCE_SAVE: 10 },
			STATUS_DEFAULTS: {
				DEFAULT: 'draft',
				ALLOWED: [ 'draft', 'publish' ],
			},
			window: { ajaxurl: '/wp-admin/admin-ajax.php' },
		}
	);

	const autosave = new SlideAutosave( {
		wrap: {
			dataset: {
				ajaxAction: 'lp_interactive_save',
				nonce:      'nonce',
			},
		},
		bootstrap:         { id: 10 },
		store,
		buildSlidesForSave: () => [],
		buildSettingsForSave: () => ( {} ),
	} );

	const savePromise = autosave.saveSlideListNow( { silent: true } );
	store.setState( { dirty: true, dirtyRevision: 2 } );

	resolveResponse( {
		json: () => Promise.resolve( { success: true, data: {} } ),
	} );

	await savePromise;

	assert.equal( store.get().dirty, true );
	assert.equal( store.get().dirtyRevision, 2 );
} );

function __( text ) {
	return text;
}
