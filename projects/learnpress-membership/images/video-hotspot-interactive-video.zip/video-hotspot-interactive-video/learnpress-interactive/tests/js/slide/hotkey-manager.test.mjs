import assert from 'node:assert/strict';
import test from 'node:test';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { JSDOM } from 'jsdom';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadModule( dom ) {
	let source = fs.readFileSync(
		path.join( ROOT, 'assets/src/js/admin/builder/slide/services/HotkeyManager.js' ),
		'utf8'
	);
	source = source.replace( /export class /g, 'class ' );
	const script = new vm.Script( `${ source }\n( { HotkeyManager } );` );
	return script.runInNewContext( { document: dom.window.document, console } );
}

function makeCallbacks() {
	const calls = {};
	const track = ( name ) => () => { calls[ name ] = ( calls[ name ] || 0 ) + 1; };
	return {
		onSelectAll: track( 'selectAll' ),
		onDelete:    track( 'delete' ),
		onDuplicate: track( 'duplicate' ),
		onCopy:      track( 'copy' ),
		onPaste:     track( 'paste' ),
		onUndo:      track( 'undo' ),
		onRedo:      track( 'redo' ),
		onNudge:     ( key, shift ) => { calls.nudge = { key, shift }; },
		calls,
	};
}

function fire( dom, key, mods = {} ) {
	const event = new dom.window.KeyboardEvent( 'keydown', {
		key,
		ctrlKey:  mods.ctrl  || false,
		metaKey:  mods.meta  || false,
		shiftKey: mods.shift || false,
		bubbles: true,
	} );
	dom.window.document.dispatchEvent( event );
	return event;
}

test( 'Ctrl+Z fires onUndo', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { HotkeyManager } = loadModule( dom );
	const cb = makeCallbacks();
	const hk = new HotkeyManager( cb );

	fire( dom, 'z', { ctrl: true } );
	assert.equal( cb.calls.undo, 1 );
	hk.destroy();
} );

test( 'Ctrl+Shift+Z fires onRedo', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { HotkeyManager } = loadModule( dom );
	const cb = makeCallbacks();
	const hk = new HotkeyManager( cb );

	fire( dom, 'z', { ctrl: true, shift: true } );
	assert.equal( cb.calls.redo, 1 );
	hk.destroy();
} );

test( 'Ctrl+Y fires onRedo', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { HotkeyManager } = loadModule( dom );
	const cb = makeCallbacks();
	const hk = new HotkeyManager( cb );

	fire( dom, 'y', { ctrl: true } );
	assert.equal( cb.calls.redo, 1 );
	hk.destroy();
} );

test( 'Ctrl+D fires onDuplicate', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { HotkeyManager } = loadModule( dom );
	const cb = makeCallbacks();
	const hk = new HotkeyManager( cb );

	fire( dom, 'd', { ctrl: true } );
	assert.equal( cb.calls.duplicate, 1 );
	hk.destroy();
} );

test( 'Ctrl+A fires onSelectAll', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { HotkeyManager } = loadModule( dom );
	const cb = makeCallbacks();
	const hk = new HotkeyManager( cb );

	fire( dom, 'a', { ctrl: true } );
	assert.equal( cb.calls.selectAll, 1 );
	hk.destroy();
} );

test( 'Ctrl+C fires onCopy', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { HotkeyManager } = loadModule( dom );
	const cb = makeCallbacks();
	const hk = new HotkeyManager( cb );

	fire( dom, 'c', { ctrl: true } );
	assert.equal( cb.calls.copy, 1 );
	hk.destroy();
} );

test( 'Ctrl+V fires onPaste', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { HotkeyManager } = loadModule( dom );
	const cb = makeCallbacks();
	const hk = new HotkeyManager( cb );

	fire( dom, 'v', { ctrl: true } );
	assert.equal( cb.calls.paste, 1 );
	hk.destroy();
} );

test( 'Delete fires onDelete when no input focused', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { HotkeyManager } = loadModule( dom );
	const cb = makeCallbacks();
	const hk = new HotkeyManager( cb );

	fire( dom, 'Delete' );
	assert.equal( cb.calls.delete, 1 );
	hk.destroy();
} );

test( 'Arrow key fires onNudge with correct key and shift state', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { HotkeyManager } = loadModule( dom );
	const cb = makeCallbacks();
	const hk = new HotkeyManager( cb );

	fire( dom, 'ArrowLeft', { shift: true } );
	assert.deepEqual( cb.calls.nudge, { key: 'ArrowLeft', shift: true } );
	hk.destroy();
} );

test( 'hotkeys are suppressed when an INPUT is focused', () => {
	const dom = new JSDOM( '<!doctype html><html><body><input id="ti"/></body></html>' );
	const { HotkeyManager } = loadModule( dom );
	const cb = makeCallbacks();
	const hk = new HotkeyManager( cb );

	const input = dom.window.document.getElementById( 'ti' );
	input.focus();
	Object.defineProperty( dom.window.document, 'activeElement', { get: () => input, configurable: true } );

	fire( dom, 'z', { ctrl: true } );
	fire( dom, 'Delete' );
	fire( dom, 'ArrowLeft' );

	assert.equal( cb.calls.undo,   undefined );
	assert.equal( cb.calls.delete, undefined );
	assert.equal( cb.calls.nudge,  undefined );
	hk.destroy();
} );

test( 'hotkeys are suppressed when a TEXTAREA is focused', () => {
	const dom = new JSDOM( '<!doctype html><html><body><textarea id="ta"></textarea></body></html>' );
	const { HotkeyManager } = loadModule( dom );
	const cb = makeCallbacks();
	const hk = new HotkeyManager( cb );

	const ta = dom.window.document.getElementById( 'ta' );
	Object.defineProperty( dom.window.document, 'activeElement', { get: () => ta, configurable: true } );

	fire( dom, 'd', { ctrl: true } );
	assert.equal( cb.calls.duplicate, undefined );
	hk.destroy();
} );

test( 'hotkeys are suppressed when contentEditable is focused', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { HotkeyManager } = loadModule( dom );
	const cb = makeCallbacks();
	const hk = new HotkeyManager( cb );

	// Simulate a contentEditable element being the active element
	const fakeContentEditable = { tagName: 'DIV', isContentEditable: true };
	Object.defineProperty( dom.window.document, 'activeElement', {
		get: () => fakeContentEditable,
		configurable: true,
	} );

	fire( dom, 'c', { ctrl: true } );
	fire( dom, 'Delete' );
	assert.equal( cb.calls.copy,   undefined );
	assert.equal( cb.calls.delete, undefined );

	// Restore
	Object.defineProperty( dom.window.document, 'activeElement', {
		get: () => dom.window.document.body,
		configurable: true,
	} );
	hk.destroy();
} );

test( 'destroy removes the keydown listener', () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const { HotkeyManager } = loadModule( dom );
	const cb = makeCallbacks();
	const hk = new HotkeyManager( cb );

	hk.destroy();
	fire( dom, 'z', { ctrl: true } );
	assert.equal( cb.calls.undo, undefined );
} );
