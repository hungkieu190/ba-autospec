import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import vm from 'node:vm';
import { JSDOM } from 'jsdom';

const ROOT = path.resolve( import.meta.dirname, '../../..' );

function loadListPage( context = {} ) {
	let source = fs.readFileSync(
		path.join( ROOT, 'assets/src/js/admin/list-page/ListPage.js' ),
		'utf8'
	);

	source = source
		.replace( /import[\s\S]*?;\n/g, '' )
		.replace( /export class ListPage/g, 'class ListPage' );

	const script = new vm.Script( `${ source }\n( { ListPage } );` );
	return script.runInNewContext( Object.assign( {
		console,
		setTimeout,
		clearTimeout,
		FormData,
		URLSearchParams,
	}, context ) );
}

test( 'interactive list row renders shortcode copy control and flashes copied state', async () => {
	const dom = new JSDOM( '<!doctype html><html><body></body></html>' );
	const document = dom.window.document;
	let copiedText = '';

	const { ListPage } = loadListPage( {
		document,
		window: dom.window,
		navigator: {
			clipboard: {
				writeText: ( text ) => {
					copiedText = text;
					return Promise.resolve();
				},
			},
		},
		DOMParser: dom.window.DOMParser,
		lpiConfirm: () => Promise.resolve( { isConfirmed: false } ),
		showToast: () => {},
		SWAL_ICON_DUPLICATE: '',
		SWAL_ICON_TRASH_DRAFT: '',
		SWAL_ICON_DELETE: '',
	} );

	const page = new ListPage();
	const body = document.createElement( 'ul' );
	body.className = 'lp-interactive-list__body';
	const wrap = document.createElement( 'div' );
	wrap.className = 'lp-interactive-list-wrap';
	wrap.appendChild( body );
	document.body.appendChild( wrap );

	page.wrap = wrap;
	body.addEventListener( 'click', ( event ) => page._onRowClick( event ) );

	body.appendChild( page._renderRow( {
		id:         37,
		title:      'Deck',
		type:       'flash_card',
		type_label: 'Flash Card',
		status:     'publish',
		shortcode:  '[learnpress_single_interactive id=37]',
		edit_url:   '/wp-admin/admin.php?page=lp-interactive&action=edit&id=37',
	} ) );

	const shortcode = body.querySelector( '.lp-interactive-fc-library__card-shortcode' );
	const code = shortcode.querySelector( '.lp-interactive-fc-library__card-shortcode-text' );
	const copy = shortcode.querySelector( '.lp-interactive-list-row__shortcode-copy' );

	assert.ok( shortcode );
	assert.equal( shortcode.dataset.shortcode, '[learnpress_single_interactive id=37]' );
	assert.equal( code.textContent, '[learnpress_single_interactive id=37]' );
	assert.equal( copy.textContent, 'Copy' );

	copy.click();
	await new Promise( ( resolve ) => setTimeout( resolve, 0 ) );

	assert.equal( copiedText, '[learnpress_single_interactive id=37]' );
	assert.equal( copy.textContent, 'Copied!' );
	assert.equal( copy.classList.contains( 'is-copied' ), true );
} );
