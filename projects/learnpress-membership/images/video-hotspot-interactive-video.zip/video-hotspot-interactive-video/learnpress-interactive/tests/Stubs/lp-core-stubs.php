<?php
/**
 * Minimal stubs of LearnPress core classes used by learnpress-interactive.
 *
 * Used ONLY in PHPUnit context — production code loads the real classes via
 * LearnPress's autoloader. These stubs mirror just the surface area our addon
 * touches (properties + method signatures), so tests can instantiate our
 * subclasses without depending on a running WP/LP install.
 *
 * @package LearnPress\Interactive\Tests\Stubs
 */

declare( strict_types=1 );

namespace LearnPress\Helpers {

	if ( ! class_exists( __NAMESPACE__ . '\\Template' ) ) {
		/**
		 * Stub of LearnPress\Helpers\Template.
		 * Mirrors combine_components() — concatenates array values in order.
		 */
		final class Template {
			public static function combine_components( array $elms = array() ): string {
				$html = '';
				foreach ( $elms as $val ) {
					$html .= (string) $val;
				}
				return $html;
			}
		}
	}

	if ( ! trait_exists( __NAMESPACE__ . '\\Singleton' ) ) {
		/**
		 * Stub of LearnPress\Helpers\Singleton trait.
		 * Provides static instance() + private constructor that calls init().
		 */
		trait Singleton {
			private static $instance = null;

			final public static function instance(): self {
				if ( is_null( static::$instance ) ) {
					static::$instance = new static();
				}
				return static::$instance;
			}

			final private function __construct() {
				$this->init();
			}

			abstract function init();

			/** Test-only helper to clear the singleton so each test gets a fresh instance. */
			public static function reset_for_tests(): void {
				static::$instance = null;
			}
		}
	}
}

namespace LearnPress\Filters {

	if ( ! class_exists( __NAMESPACE__ . '\\FilterBase' ) ) {
		/**
		 * Stub of LearnPress\Filters\FilterBase.
		 * Mirrors public properties used by InteractiveFilter / InteractiveItemFilter.
		 */
		class FilterBase {
			public $limit               = 10;
			public $max_limit           = 100;
			public $sort_by             = array();
			public $group_by            = '';
			public $order_by            = '';
			public $order               = '';
			public $key_word            = '';
			public $page                = 1;
			public $collection          = '';
			public $collection_alias    = '';
			public $fields              = array();
			public $only_fields         = array();
			public $exclude_fields      = array();
			public $set                 = array();
			public $where               = array();
			public $join                = array();
			public $union               = array();
			public $run_query_count     = true;
			public $query_count         = false;
			public $field_count         = 'ID';
			public $return_string_query = false;
			public $debug_string_query  = false;
			public $query_type          = 'get_results';
			public $filter_extra;
		}
	}
}

namespace LearnPress\Shortcodes {

	if ( ! class_exists( __NAMESPACE__ . '\\AbstractShortcode' ) ) {
		/**
		 * Stub of LearnPress\Shortcodes\AbstractShortcode.
		 * Real init() registers the shortcode tag via add_shortcode; tests
		 * bypass via ReflectionClass::newInstanceWithoutConstructor().
		 */
		abstract class AbstractShortcode {
			protected $prefix = 'learn_press_';
			protected $shortcode_name;

			protected function init() {
				// No-op in tests — production code registers via add_shortcode.
			}

			abstract public function render( $attrs ): string;
		}
	}
}

namespace LearnPress\Databases {

	if ( ! class_exists( __NAMESPACE__ . '\\DataBase' ) ) {
		/**
		 * Stub of LearnPress\Databases\DataBase.
		 * Subclasses (InteractiveDB) call parent::__construct() and use $this->wpdb.
		 * Tests inject a Mockery $wpdb via the global before instantiating.
		 */
		class DataBase {
			/** @var mixed wpdb-like object set in tests via $GLOBALS['wpdb'] */
			public $wpdb;

			protected function __construct() {
				$this->wpdb = $GLOBALS['wpdb'] ?? null;
			}

			/**
			 * Stub of execute() — real impl runs the SQL. Tests should override
			 * via Mockery on the InteractiveDB instance, OR rely on this returning [].
			 *
			 * @param object $filter
			 * @param int $total_rows
			 * @return array
			 */
			public function execute( $filter, int &$total_rows = 0 ) {
				return array();
			}
		}
	}
}
