<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Install;

use Brain\Monkey\Functions;
use LearnPress\Interactive\Install\Installer;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use Mockery;

/**
 * @covers \LearnPress\Interactive\Install\Installer
 */
class InstallerTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();

		$wpdb         = Mockery::mock();
		$wpdb->prefix = 'wp_';
		$wpdb->shouldReceive( 'get_charset_collate' )->andReturn( 'DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' );
		$GLOBALS['wpdb'] = $wpdb;
	}

	public function test_db_version_constant_is_semver_one_zero_zero(): void {
		$this->assertSame( '1.0.0', Installer::DB_VERSION );
	}

	public function test_option_key_constant_is_namespaced(): void {
		$this->assertSame( 'lp_addon_interactive_db_version', Installer::OPT_DB_VERSION );
	}

	public function test_activate_calls_dbDelta_for_both_tables_and_stores_version(): void {
		$captured = [];
		Functions\when( 'dbDelta' )->alias(
			static function ( $sql ) use ( &$captured ) {
				$captured[] = $sql;
				return [];
			}
		);
		Functions\expect( 'update_option' )
			->once()
			->with( Installer::OPT_DB_VERSION, Installer::DB_VERSION );

		Installer::activate();

		$this->assertCount( 2, $captured, 'dbDelta should be called twice (parent + items)' );
		$this->assertStringContainsString(
			'CREATE TABLE wp_learnpress_interactive ',
			$captured[0],
			'First dbDelta should target parent table'
		);
		$this->assertStringContainsString(
			'CREATE TABLE wp_learnpress_interactive_items ',
			$captured[1],
			'Second dbDelta should target items table'
		);
	}

	public function test_parent_table_sql_includes_all_required_columns(): void {
		$captured = [];
		Functions\when( 'dbDelta' )->alias(
			static function ( $sql ) use ( &$captured ) {
				$captured[] = $sql;
				return [];
			}
		);
		Functions\when( 'update_option' )->justReturn( true );

		Installer::activate();

		$parent_sql = $captured[0];
		foreach ( [ 'ID', 'title', 'type', 'status', 'extra_data', 'author', 'created_at', 'updated_at' ] as $col ) {
			$this->assertStringContainsString( $col, $parent_sql, "Parent table SQL must declare column: $col" );
		}
		$this->assertStringContainsString( 'KEY title_idx (title(191))', $parent_sql, 'Parent must use 191 prefix on title index for utf8mb4 safety' );
	}

	public function test_items_table_sql_includes_interactive_id_fk_index(): void {
		$captured = [];
		Functions\when( 'dbDelta' )->alias(
			static function ( $sql ) use ( &$captured ) {
				$captured[] = $sql;
				return [];
			}
		);
		Functions\when( 'update_option' )->justReturn( true );

		Installer::activate();

		$items_sql = $captured[1];
		$this->assertStringContainsString( 'interactive_id bigint(20) UNSIGNED NOT NULL', $items_sql );
		$this->assertStringContainsString( 'KEY interactive_sort_idx (interactive_id, sort_order)', $items_sql );
	}
}
