<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Services;

use Brain\Monkey\Functions;
use LearnPress\Interactive\Databases\InteractiveDB;
use LearnPress\Interactive\Models\InteractiveItemModel;
use LearnPress\Interactive\Models\InteractiveModel;
use LearnPress\Interactive\Services\InteractiveService;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use LearnPress\Interactive\Tests\Helpers\FakeServiceType;
use LearnPress\Interactive\Types\FlashCardType;
use LearnPress\Interactive\Types\SlideType;
use LearnPress\Interactive\Types\TypeRegistry;
use Mockery;
use ReflectionClass;

/**
 * @covers \LearnPress\Interactive\Services\InteractiveService
 */
class InteractiveServiceTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();

		// Reset singletons between tests.
		InteractiveService::reset_for_tests();
		TypeRegistry::reset_for_tests();
		TypeRegistry::register( new FakeServiceType() );
		$this->reset_interactive_db_singleton();

		Functions\when( 'current_time' )->justReturn( '2026-05-06 10:00:00' );
		Functions\when( 'wp_json_encode' )->alias(
			static fn( $data, $flags = 0 ) => json_encode( $data, (int) $flags )
		);

		$wpdb            = Mockery::mock();
		$wpdb->prefix    = 'wp_';
		$wpdb->insert_id = 0;
		$GLOBALS['wpdb'] = $wpdb;
	}

	/** Replace InteractiveDB::$_instance so InteractiveModel::find delegates to a mock. */
	private function inject_interactive_db_returning( array $rows, array $item_rows = array() ): void {
		$db_mock = Mockery::mock( InteractiveDB::class );
		$db_mock->shouldReceive( 'get_interactives' )->andReturn( $rows );
		$db_mock->shouldReceive( 'get_interactive_items' )->andReturn( $item_rows );
		$this->set_interactive_db_singleton( $db_mock );
	}

	private function set_interactive_db_singleton( $instance ): void {
		$ref  = new ReflectionClass( InteractiveDB::class );
		$prop = $ref->getProperty( '_instance' );
		$prop->setAccessible( true );
		$prop->setValue( null, $instance );
	}

	private function reset_interactive_db_singleton(): void {
		$this->set_interactive_db_singleton( null );
	}

	/** Build a parent row stdClass for find() mocks. */
	private function make_row( array $overrides = array() ): object {
		return (object) array_merge(
			array(
				'ID'         => 5,
				'title'      => 'Existing',
				'type'       => 'fake',
				'status'     => 'publish',
				'extra_data' => '{}',
				'author'     => 1,
				'created_at' => '2026-05-06 10:00:00',
				'updated_at' => '2026-05-06 10:00:00',
			),
			$overrides
		);
	}

	public function test_create_with_items_inserts_parent_then_replaces_items(): void {
		$wpdb = $GLOBALS['wpdb'];

		$inserted_parent = null;
		$inserted_items  = array();
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$inserted_parent, &$inserted_items ) {
				if ( 'wp_learnpress_interactive' === $table ) {
					$inserted_parent  = $row;
					$wpdb->insert_id  = 42;
				} else {
					$inserted_items[] = $row;
					$wpdb->insert_id  = count( $inserted_items );
				}
				return true;
			}
		);
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );

		$service = InteractiveService::instance();
		$id      = $service->create_with_items(
			array(
				'title'    => 'Hello',
				'type'     => 'fake',
				'author'   => 7,
				'settings' => array( 'flag' => true ),
				'items'    => array(
					array( 'content' => 'A', 'note' => 'first' ),
					array( 'content' => 'B', 'note' => 'second' ),
				),
			)
		);

		$this->assertSame( 42, $id );
		$this->assertSame( 'Hello', $inserted_parent['title'] );
		$this->assertSame( 'fake', $inserted_parent['type'] );
		$this->assertSame( 'publish', $inserted_parent['status'] );
		$this->assertSame( 7, $inserted_parent['author'] );
		$this->assertSame( '{"flag":true}', $inserted_parent['extra_data'] );

		$this->assertCount( 2, $inserted_items );
		$this->assertSame( 0, $inserted_items[0]['sort_order'] );
		$this->assertSame( 1, $inserted_items[1]['sort_order'] );
		$this->assertSame( 'A', $inserted_items[0]['content'] );
		$this->assertStringContainsString( '"note":"first"', $inserted_items[0]['extra_data'] );
	}

	public function test_create_with_items_uses_default_settings_when_none_provided(): void {
		$wpdb           = $GLOBALS['wpdb'];
		$captured_extra = '';
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$captured_extra ) {
				if ( 'wp_learnpress_interactive' === $table ) {
					$captured_extra  = $row['extra_data'];
					$wpdb->insert_id = 1;
				}
				return true;
			}
		);
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );

		InteractiveService::instance()->create_with_items(
			array( 'title' => 'X', 'type' => 'fake', 'author' => 1 )
		);

		$this->assertSame( '{"flag":false}', $captured_extra, 'Default settings should be applied when settings key omitted' );
	}

	public function test_create_slide_without_child_rows_seeds_blank_canvas_slide_row(): void {
		TypeRegistry::register( new SlideType() );

		$wpdb           = $GLOBALS['wpdb'];
		$inserted_parent = null;
		$inserted_items  = array();
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$inserted_parent, &$inserted_items ) {
				if ( 'wp_learnpress_interactive' === $table ) {
					$inserted_parent = $row;
					$wpdb->insert_id = 17;
				} elseif ( 'wp_learnpress_interactive_items' === $table ) {
					$inserted_items[] = $row;
					$wpdb->insert_id  = count( $inserted_items );
				}
				return true;
			}
		);
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );

		$id = InteractiveService::instance()->create_with_items(
			array(
				'title'  => 'Blank slide',
				'type'   => 'slide',
				'author' => 7,
			)
		);

		$this->assertSame( 17, $id );
		$this->assertSame( '{}', $inserted_parent['extra_data'] );
		$this->assertCount( 1, $inserted_items );
		$this->assertSame( '{"version":"","objects":[]}', $inserted_items[0]['content'] );
		$this->assertSame( 0, $inserted_items[0]['sort_order'] );

		$extra = json_decode( $inserted_items[0]['extra_data'], true );
		$this->assertSame(
			array(
				'width'  => 842,
				'height' => 595,
			),
			$extra
		);
	}

	public function test_create_slide_without_title_uses_default_title_immediately(): void {
		TypeRegistry::register( new SlideType() );

		$wpdb            = $GLOBALS['wpdb'];
		$inserted_parent = null;
		$inserted_items  = array();
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$inserted_parent, &$inserted_items ) {
				if ( 'wp_learnpress_interactive' === $table ) {
					$inserted_parent = $row;
					$wpdb->insert_id = 18;
				} elseif ( 'wp_learnpress_interactive_items' === $table ) {
					$inserted_items[] = $row;
					$wpdb->insert_id  = count( $inserted_items );
				}
				return true;
			}
		);
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );

		$id = InteractiveService::instance()->create_with_items(
			array(
				'type'   => 'slide',
				'author' => 7,
			)
		);

		$this->assertSame( 18, $id );
		$this->assertSame( 'Untitled deck', $inserted_parent['title'] );
		$this->assertSame( '{}', $inserted_parent['extra_data'] );
		$this->assertCount( 1, $inserted_items );
		$this->assertSame( '{"version":"","objects":[]}', $inserted_items[0]['content'] );
		$this->assertSame( '{"width":842,"height":595}', $inserted_items[0]['extra_data'] );
	}

	public function test_create_with_items_throws_on_unknown_type(): void {
		$this->expectException( \InvalidArgumentException::class );
		$this->expectExceptionMessage( 'Unknown interactive type: nope' );

		InteractiveService::instance()->create_with_items( array( 'type' => 'nope', 'title' => 'X', 'author' => 1 ) );
	}

	public function test_save_returns_false_when_entry_not_found(): void {
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'esc_like' )->andReturnUsing( static fn( $s ) => $s );
		$wpdb->shouldReceive( 'prepare' )->andReturnUsing( static fn( $sql ) => $sql );

		$this->assertFalse( InteractiveService::instance()->save( 999, array( 'title' => 'X' ) ) );
	}

	public function test_create_with_items_rolls_back_parent_when_bulk_replace_fails(): void {
		$wpdb              = $GLOBALS['wpdb'];
		$inserted_parent   = null;
		$delete_called_for = null;

		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$inserted_parent ) {
				if ( 'wp_learnpress_interactive' === $table ) {
					$inserted_parent  = $row;
					$wpdb->insert_id  = 99;
					return true;
				}
				return false;
			}
		);
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturnUsing(
			static function ( $table, $where ) use ( &$delete_called_for ) {
				$delete_called_for[ $table ] = $where;
				return 0;
			}
		);

		$id = InteractiveService::instance()->create_with_items(
			array(
				'title'  => 'Will fail',
				'type'   => 'fake',
				'author' => 1,
				'items'  => array( array( 'content' => 'X' ) ),
			)
		);

		$this->assertSame( 0, $id, 'service should return 0 when items fail to persist' );
		$this->assertNotNull( $inserted_parent, 'parent insert should have been attempted' );
		$this->assertArrayHasKey( 'wp_learnpress_interactive', $delete_called_for, 'parent must be force-deleted to avoid orphan' );
		$this->assertSame( array( 'ID' => 99 ), $delete_called_for['wp_learnpress_interactive'] );
	}

	public function test_save_succeeds_and_replaces_items_when_persistence_ok(): void {
		$this->inject_interactive_db_returning( array( $this->make_row() ) );

		$wpdb           = $GLOBALS['wpdb'];
		$update_calls   = array();
		$insert_calls   = array();
		$wpdb->shouldReceive( 'update' )->andReturnUsing(
			static function ( $table, $row, $where ) use ( &$update_calls ) {
				$update_calls[] = compact( 'table', 'row', 'where' );
				return 1;
			}
		);
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$insert_calls ) {
				$insert_calls[]  = $row;
				$wpdb->insert_id = count( $insert_calls );
				return true;
			}
		);

		$ok = InteractiveService::instance()->save(
			5,
			array(
				'title'  => 'Renamed',
				'status' => 'draft',
				'items'  => array(
					array( 'content' => 'A', 'note' => 'one' ),
					array( 'content' => 'B', 'note' => 'two' ),
				),
			)
		);

		$this->assertTrue( $ok );
		$this->assertNotEmpty( $update_calls );
		$this->assertSame( 'Renamed', $update_calls[0]['row']['title'] );
		$this->assertSame( 'draft', $update_calls[0]['row']['status'] );
		$this->assertCount( 2, $insert_calls );
		$this->assertSame( 0, $insert_calls[0]['sort_order'] );
		$this->assertSame( 1, $insert_calls[1]['sort_order'] );
	}

	public function test_save_slide_settings_only_keeps_parent_extra_data_empty(): void {
		TypeRegistry::register( new SlideType() );
		$this->inject_interactive_db_returning(
			array(
				$this->make_row(
					array(
						'title'      => 'Existing deck',
						'type'       => 'slide',
						'extra_data' => '{}',
					)
				),
			)
		);

		$wpdb         = $GLOBALS['wpdb'];
		$update_calls = array();
		$wpdb->shouldReceive( 'update' )->andReturnUsing(
			static function ( $table, $row, $where ) use ( &$update_calls ) {
				$update_calls[] = compact( 'table', 'row', 'where' );
				return 1;
			}
		);

		$ok = InteractiveService::instance()->save( 5, array( 'settings' => array() ) );

		$this->assertTrue( $ok );
		$this->assertSame( '{}', $update_calls[0]['row']['extra_data'] );
	}

	public function test_save_slide_content_updates_only_the_matching_slide_row(): void {
		TypeRegistry::register( new SlideType() );
		$this->inject_interactive_db_returning(
			array(
				$this->make_row(
					array(
						'ID'   => 5,
						'type' => 'slide',
					)
				),
			),
			array(
				(object) array(
					'ID'             => 12,
					'interactive_id' => 5,
					'content'        => '{"version":"","objects":[]}',
					'sort_order'     => 2,
					'extra_data'     => '{"width":842,"height":595}',
				),
			)
		);

		$wpdb         = $GLOBALS['wpdb'];
		$update_calls = array();
		$wpdb->shouldReceive( 'update' )->andReturnUsing(
			static function ( $table, $row, $where ) use ( &$update_calls ) {
				$update_calls[] = compact( 'table', 'row', 'where' );
				return 1;
			}
		);

		$ok = InteractiveService::instance()->save_slide_content(
			5,
			12,
			array(
				'content'    => array(
					'version' => '7.0.0',
					'objects' => array(
						array(
							'type' => 'textbox',
							'text' => 'Hello',
						),
					),
				),
				'extra_data' => array(
					'width'  => 900,
					'height' => 600,
				),
			)
		);

		$this->assertTrue( $ok );
		$this->assertCount( 1, $update_calls );
		$this->assertSame( 'wp_learnpress_interactive_items', $update_calls[0]['table'] );
		$this->assertSame( array( 'ID' => 12 ), $update_calls[0]['where'] );
		$this->assertSame( 5, $update_calls[0]['row']['interactive_id'] );
		$this->assertSame( 2, $update_calls[0]['row']['sort_order'] );
		$this->assertSame(
			'{"version":"7.0.0","objects":[{"type":"textbox","text":"Hello"}]}',
			$update_calls[0]['row']['content']
		);
		$this->assertSame( '{"width":900,"height":600}', $update_calls[0]['row']['extra_data'] );
	}

	public function test_save_slide_content_rejects_slide_row_from_another_parent(): void {
		TypeRegistry::register( new SlideType() );
		$this->inject_interactive_db_returning(
			array(
				$this->make_row(
					array(
						'ID'   => 5,
						'type' => 'slide',
					)
				),
			),
			array(
				(object) array(
					'ID'             => 12,
					'interactive_id' => 99,
					'content'        => '{"version":"","objects":[]}',
					'sort_order'     => 0,
					'extra_data'     => '{}',
				),
			)
		);

		$this->assertFalse(
			InteractiveService::instance()->save_slide_content(
				5,
				12,
				array(
					'content'    => array(),
					'extra_data' => array(),
				)
			)
		);
	}

	public function test_create_slide_inserts_one_child_row(): void {
		TypeRegistry::register( new SlideType() );
		$this->inject_interactive_db_returning(
			array(
				$this->make_row(
					array(
						'ID'   => 5,
						'type' => 'slide',
					)
				),
			)
		);

		$wpdb        = $GLOBALS['wpdb'];
		$insert_call = null;
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$insert_call ) {
				$insert_call     = compact( 'table', 'row' );
				$wpdb->insert_id = 33;
				return true;
			}
		);

		$slide_id = InteractiveService::instance()->create_slide(
			5,
			array(
				'content'    => array(
					'version' => '7.0.0',
					'objects' => array(),
				),
				'extra_data' => array(
					'width'  => 842,
					'height' => 595,
				),
			),
			2
		);

		$this->assertSame( 33, $slide_id );
		$this->assertSame( 'wp_learnpress_interactive_items', $insert_call['table'] );
		$this->assertSame( 5, $insert_call['row']['interactive_id'] );
		$this->assertSame( 2, $insert_call['row']['sort_order'] );
		$this->assertSame( '{"version":"7.0.0","objects":[]}', $insert_call['row']['content'] );
		$this->assertSame( '{"width":842,"height":595}', $insert_call['row']['extra_data'] );
	}

	public function test_delete_slide_removes_only_matching_child_row(): void {
		TypeRegistry::register( new SlideType() );
		$this->inject_interactive_db_returning(
			array(
				$this->make_row(
					array(
						'ID'   => 5,
						'type' => 'slide',
					)
				),
			),
			array(
				(object) array(
					'ID'             => 12,
					'interactive_id' => 5,
					'content'        => '{"version":"","objects":[]}',
					'sort_order'     => 0,
					'extra_data'     => '{}',
				),
			)
		);

		$wpdb        = $GLOBALS['wpdb'];
		$delete_call = null;
		$wpdb->shouldReceive( 'delete' )->andReturnUsing(
			static function ( $table, $where ) use ( &$delete_call ) {
				$delete_call = compact( 'table', 'where' );
				return 1;
			}
		);

		$this->assertTrue( InteractiveService::instance()->delete_slide( 5, 12 ) );
		$this->assertSame( 'wp_learnpress_interactive_items', $delete_call['table'] );
		$this->assertSame( array( 'ID' => 12 ), $delete_call['where'] );
	}

	public function test_reorder_slides_updates_sort_order_only_for_existing_children(): void {
		TypeRegistry::register( new SlideType() );
		$this->inject_interactive_db_returning(
			array(
				$this->make_row(
					array(
						'ID'   => 5,
						'type' => 'slide',
					)
				),
			),
			array(
				(object) array(
					'ID'             => 11,
					'interactive_id' => 5,
					'content'        => '{"version":"","objects":[]}',
					'sort_order'     => 0,
					'extra_data'     => '{"width":842,"height":595}',
				),
				(object) array(
					'ID'             => 12,
					'interactive_id' => 5,
					'content'        => '{"version":"7.0.0","objects":[]}',
					'sort_order'     => 1,
					'extra_data'     => '{"width":842,"height":595}',
				),
			)
		);

		$wpdb        = $GLOBALS['wpdb'];
		$update_calls = array();
		$wpdb->shouldReceive( 'update' )->andReturnUsing(
			static function ( $table, $row, $where ) use ( &$update_calls ) {
				$update_calls[] = compact( 'table', 'row', 'where' );
				return 1;
			}
		);

		$this->assertTrue( InteractiveService::instance()->reorder_slides( 5, array( 12, 11 ) ) );
		$this->assertCount( 2, $update_calls );
		$this->assertSame( array( 'ID' => 12 ), $update_calls[0]['where'] );
		$this->assertSame( 0, $update_calls[0]['row']['sort_order'] );
		$this->assertSame( '{"version":"7.0.0","objects":[]}', $update_calls[0]['row']['content'] );
		$this->assertSame( array( 'ID' => 11 ), $update_calls[1]['where'] );
		$this->assertSame( 1, $update_calls[1]['row']['sort_order'] );
	}

	public function test_reorder_slides_rejects_partial_slide_list(): void {
		TypeRegistry::register( new SlideType() );
		$this->inject_interactive_db_returning(
			array(
				$this->make_row(
					array(
						'ID'   => 5,
						'type' => 'slide',
					)
				),
			),
			array(
				(object) array(
					'ID'             => 11,
					'interactive_id' => 5,
					'content'        => '{"version":"","objects":[]}',
					'sort_order'     => 0,
					'extra_data'     => '{}',
				),
				(object) array(
					'ID'             => 12,
					'interactive_id' => 5,
					'content'        => '{"version":"7.0.0","objects":[]}',
					'sort_order'     => 1,
					'extra_data'     => '{}',
				),
			)
		);

		$GLOBALS['wpdb']->shouldReceive( 'update' )->never();

		$this->assertFalse( InteractiveService::instance()->reorder_slides( 5, array( 12 ) ) );
	}

	public function test_save_returns_false_when_bulk_replace_fails(): void {
		$this->inject_interactive_db_returning( array( $this->make_row() ) );

		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'update' )->andReturn( 1 );
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );
		$wpdb->shouldReceive( 'insert' )->andReturn( false );

		$ok = InteractiveService::instance()->save(
			5,
			array( 'items' => array( array( 'content' => 'X' ) ) )
		);

		$this->assertFalse( $ok, 'save() must propagate bulk_replace failure to caller' );
	}

	public function test_render_returns_html_via_type_strategy_when_publish(): void {
		$this->inject_interactive_db_returning(
			array( $this->make_row( array( 'title' => 'Hello' ) ) ),
			array()
		);

		$html = InteractiveService::instance()->render( 5 );

		$this->assertStringContainsString( '<div class="fake">Hello (0 items)</div>', $html );
	}

	public function test_render_passes_items_to_type_render(): void {
		$this->inject_interactive_db_returning(
			array( $this->make_row( array( 'title' => 'Multi' ) ) ),
			array(
				(object) array( 'ID' => 1, 'interactive_id' => 5, 'content' => 'A', 'sort_order' => 0, 'extra_data' => '{}' ),
				(object) array( 'ID' => 2, 'interactive_id' => 5, 'content' => 'B', 'sort_order' => 1, 'extra_data' => '{}' ),
			)
		);

		$html = InteractiveService::instance()->render( 5 );

		$this->assertStringContainsString( '<div class="fake">Multi (2 items)</div>', $html );
	}

	public function test_render_returns_empty_when_status_not_publish(): void {
		$this->inject_interactive_db_returning( array( $this->make_row( array( 'status' => 'draft' ) ) ) );

		$this->assertSame( '', InteractiveService::instance()->render( 5 ) );
	}

	public function test_render_returns_empty_when_entry_not_found(): void {
		$this->inject_interactive_db_returning( array() );

		$this->assertSame( '', InteractiveService::instance()->render( 999 ) );
	}

	public function test_duplicate_returns_zero_when_source_missing(): void {
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'esc_like' )->andReturnUsing( static fn( $s ) => $s );
		$wpdb->shouldReceive( 'prepare' )->andReturnUsing( static fn( $sql ) => $sql );

		$this->assertSame( 0, InteractiveService::instance()->duplicate( 9999 ) );
	}

	public function test_duplicate_creates_draft_copy_with_suffix_and_items(): void {
		$source_row   = $this->make_row( array( 'ID' => 5, 'title' => 'Original', 'status' => 'publish' ) );
		$source_items = array(
			(object) array( 'ID' => 11, 'interactive_id' => 5, 'content' => 'A', 'sort_order' => 0, 'extra_data' => '{"note":"first"}' ),
			(object) array( 'ID' => 12, 'interactive_id' => 5, 'content' => 'B', 'sort_order' => 1, 'extra_data' => '{"note":"second"}' ),
		);
		$this->inject_interactive_db_returning( array( $source_row ), $source_items );

		\Brain\Monkey\Functions\when( 'get_current_user_id' )->justReturn( 42 );

		$wpdb           = $GLOBALS['wpdb'];
		$inserted_parent = null;
		$inserted_items  = array();
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$inserted_parent, &$inserted_items ) {
				if ( 'wp_learnpress_interactive' === $table ) {
					$inserted_parent = $row;
					$wpdb->insert_id = 77;
				} else {
					$inserted_items[] = $row;
					$wpdb->insert_id  = count( $inserted_items );
				}
				return true;
			}
		);
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );

		$new_id = InteractiveService::instance()->duplicate( 5 );

		$this->assertSame( 77, $new_id );
		$this->assertSame( 'Original (Copy)', $inserted_parent['title'] );
		$this->assertSame( 'draft', $inserted_parent['status'], 'duplicate must start as draft' );
		$this->assertSame( 'fake', $inserted_parent['type'] );
		$this->assertSame( 42, $inserted_parent['author'], 'author should be the acting user, not the source author' );
		$this->assertCount( 2, $inserted_items, 'all source items must be cloned' );
		$this->assertSame( 'A', $inserted_items[0]['content'] );
		$this->assertSame( 'B', $inserted_items[1]['content'] );
		$this->assertSame( 0, $inserted_items[0]['sort_order'] );
		$this->assertSame( 1, $inserted_items[1]['sort_order'] );
	}

	public function test_duplicate_flash_card_preserves_title_image_and_subtitle(): void {
		TypeRegistry::register( new FlashCardType() );

		$source_row   = $this->make_row( array(
			'ID'     => 10,
			'title'  => 'Verbs',
			'type'   => 'flash_card',
			'status' => 'publish',
		) );
		$source_items = array(
			(object) array(
				'ID'             => 21,
				'interactive_id' => 10,
				'sort_order'     => 0,
				'content'        => json_encode( array(
					'front' => array(
						'title'    => 'front A',
						'image_id' => 7,
						'subtitle' => '',
					),
					'back'  => array(
						'title'    => 'back A',
						'image_id' => 9,
						'subtitle' => '',
					),
				) ),
				'extra_data'     => '{}',
			),
			(object) array(
				'ID'             => 22,
				'interactive_id' => 10,
				'sort_order'     => 1,
				'content'        => json_encode( array(
					'front' => array(
						'title'    => 'front B',
						'image_id' => 0,
						'subtitle' => '',
					),
					'back'  => array(
						'title'    => 'back B',
						'image_id' => 42,
						'subtitle' => '',
					),
				) ),
				'extra_data'     => '{}',
			),
		);
		$this->inject_interactive_db_returning( array( $source_row ), $source_items );

		Functions\when( 'get_current_user_id' )->justReturn( 99 );

		$wpdb            = $GLOBALS['wpdb'];
		$inserted_parent = null;
		$inserted_items  = array();
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$inserted_parent, &$inserted_items ) {
				if ( 'wp_learnpress_interactive' === $table ) {
					$inserted_parent = $row;
					$wpdb->insert_id = 88;
				} else {
					$inserted_items[] = $row;
					$wpdb->insert_id  = count( $inserted_items );
				}
				return true;
			}
		);
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );

		$new_id = InteractiveService::instance()->duplicate( 10 );

		$this->assertSame( 88, $new_id );
		$this->assertSame( 'flash_card', $inserted_parent['type'] );
		$this->assertSame( 'draft',      $inserted_parent['status'] );
		$this->assertSame( 'Verbs (Copy)', $inserted_parent['title'] );
		$this->assertCount( 2, $inserted_items, 'both source cards must be duplicated' );

		$card1_content = json_decode( $inserted_items[0]['content'], true );
		$card1_extra   = json_decode( $inserted_items[0]['extra_data'], true );
		$this->assertSame( 'front A', $card1_content['front']['title'], 'front title must survive duplicate' );
		$this->assertSame( 7,         $card1_content['front']['image_id'], 'front image must survive duplicate' );
		$this->assertSame( '',        $card1_content['front']['subtitle'] );
		$this->assertSame( 'back A',  $card1_content['back']['title'], 'back title must survive duplicate' );
		$this->assertSame( 9,         $card1_content['back']['image_id'], 'back image must survive duplicate' );
		$this->assertSame( '',        $card1_content['back']['subtitle'] );
		$this->assertSame( array(), $card1_extra, 'flash card item extra_data must not store image data' );

		$card2_content = json_decode( $inserted_items[1]['content'], true );
		$card2_extra   = json_decode( $inserted_items[1]['extra_data'], true );
		$this->assertSame( 'front B', $card2_content['front']['title'] );
		$this->assertSame( 0,  $card2_content['front']['image_id'], 'zero image_id must stay zero, not corrupted' );
		$this->assertSame( 42, $card2_content['back']['image_id'] );
		$this->assertSame( array(), $card2_extra );
	}

	public function test_sanitize_items_skips_non_array_entries(): void {
		$wpdb            = $GLOBALS['wpdb'];
		$inserted_items  = array();
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$inserted_items ) {
				if ( 'wp_learnpress_interactive' === $table ) {
					$wpdb->insert_id = 1;
				} else {
					$inserted_items[] = $row;
					$wpdb->insert_id  = count( $inserted_items );
				}
				return true;
			}
		);
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );

		InteractiveService::instance()->create_with_items(
			array(
				'title'  => 'X',
				'type'   => 'fake',
				'author' => 1,
				'items'  => array(
					array( 'content' => 'valid' ),
					'not-an-array',
					null,
					array( 'content' => 'also valid' ),
				),
			)
		);

		$this->assertCount( 2, $inserted_items, 'non-array entries must be dropped' );
		$this->assertSame( 'valid', $inserted_items[0]['content'] );
		$this->assertSame( 'also valid', $inserted_items[1]['content'] );
	}
}
