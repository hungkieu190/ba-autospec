<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Shortcodes;

use Brain\Monkey\Functions;
use LearnPress\Interactive\Shortcodes\SingleInteractiveShortcode;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;

/**
 * @covers \LearnPress\Interactive\Shortcodes\SingleInteractiveShortcode
 *
 * Focused on the early-guard branches of render() that can be exercised
 * without DB. Happy-path (publish gate, type lookup, asset enqueue, item
 * hydration) requires InteractiveModel/InteractiveItemModel mocks and is
 * exercised by integration tests in a WP-loaded context.
 */
class SingleInteractiveShortcodeTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();
		// InteractiveFilter::__construct reads $wpdb->prefix — stub it.
		if ( ! isset( $GLOBALS['wpdb'] ) || ! is_object( $GLOBALS['wpdb'] ) ) {
			$GLOBALS['wpdb'] = (object) array( 'prefix' => 'wp_' );
		}
	}

	private function sc(): SingleInteractiveShortcode {
		$ref = new \ReflectionClass( SingleInteractiveShortcode::class );
		return $ref->newInstanceWithoutConstructor();
	}

	// Early guards — these run before any DB access, so safe to unit-test.

	public function test_render_returns_empty_when_attrs_is_not_array(): void {
		$this->assertSame( '', $this->sc()->render( '' ) );
	}

	public function test_render_returns_empty_when_id_missing(): void {
		$this->assertSame( '', $this->sc()->render( array() ) );
	}

	public function test_render_returns_empty_when_id_is_zero(): void {
		$this->assertSame( '', $this->sc()->render( array( 'id' => 0 ) ) );
	}

	public function test_render_returns_empty_when_id_is_non_numeric(): void {
		$this->assertSame( '', $this->sc()->render( array( 'id' => 'abc' ) ) );
	}

	public function test_render_returns_empty_when_id_is_negative(): void {
		Functions\when( 'apply_filters' )->returnArg( 2 );
		$this->assertSame( '', $this->sc()->render( array( 'id' => -5 ) ) );
	}

	public function test_render_swallows_throwable_and_returns_empty(): void {
		$this->assertSame( '', $this->sc()->render( array( 'id' => 99999 ) ) );
	}
}
