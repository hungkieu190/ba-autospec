<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Shortcodes;

use Brain\Monkey\Functions;
use LearnPress\Interactive\Databases\InteractiveDB;
use LearnPress\Interactive\Shortcodes\InteractivesListShortcode;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use LearnPress\Interactive\Types\TypeRegistry;
use Mockery;

/**
 * @covers \LearnPress\Interactive\Shortcodes\InteractivesListShortcode
 *
 * Note: tests target the pure helpers (build_filter / wrap_item). The full
 * render() path touches DB and is exercised by integration tests.
 */
class InteractivesListShortcodeTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();
		$wpdb         = Mockery::mock();
		$wpdb->prefix = 'wp_';
		$GLOBALS['wpdb'] = $wpdb;

		Functions\when( 'wp_style_is' )->justReturn( false );
		Functions\when( 'wp_script_is' )->justReturn( false );
	}

	private function sc(): InteractivesListShortcode {
		$ref = new \ReflectionClass( InteractivesListShortcode::class );
		return $ref->newInstanceWithoutConstructor();
	}

	// -------------------------------------------------------------------------
	// build_filter — limit clamping
	// -------------------------------------------------------------------------

	public function test_limit_defaults_to_ten_when_missing(): void {
		$f = $this->sc()->build_filter( [] );
		$this->assertSame( 10, $f->limit );
	}

	public function test_limit_is_clamped_to_max_fifty(): void {
		$f = $this->sc()->build_filter( [ 'limit' => '999' ] );
		$this->assertSame( 50, $f->limit );
	}

	public function test_limit_floor_is_one(): void {
		$f = $this->sc()->build_filter( [ 'limit' => '0' ] );
		$this->assertSame( 10, $f->limit, 'zero falls back to default 10' );
	}

	public function test_limit_negative_falls_back_to_default(): void {
		$f = $this->sc()->build_filter( [ 'limit' => '-5' ] );
		$this->assertGreaterThanOrEqual( 1, $f->limit );
		$this->assertLessThanOrEqual( 50, $f->limit );
	}

	// -------------------------------------------------------------------------
	// build_filter — orderby whitelist
	// -------------------------------------------------------------------------

	public function test_orderby_defaults_to_created_at(): void {
		$f = $this->sc()->build_filter( [] );
		$this->assertSame( 'created_at', $f->order_by );
	}

	public function test_orderby_accepts_whitelisted_values(): void {
		foreach ( [ 'title', 'type', 'created_at', 'updated_at' ] as $col ) {
			$f = $this->sc()->build_filter( [ 'orderby' => $col ] );
			$this->assertSame( $col, $f->order_by );
		}
	}

	public function test_orderby_rejects_non_whitelisted_value(): void {
		$f = $this->sc()->build_filter( [ 'orderby' => 'random_column' ] );
		$this->assertSame( 'created_at', $f->order_by );
	}

	public function test_orderby_rejects_sql_injection_attempt(): void {
		$f = $this->sc()->build_filter( [ 'orderby' => 'title; DROP TABLE wp_posts' ] );
		$this->assertSame( 'created_at', $f->order_by );
	}

	// -------------------------------------------------------------------------
	// build_filter — order direction
	// -------------------------------------------------------------------------

	public function test_order_defaults_to_desc(): void {
		$f = $this->sc()->build_filter( [] );
		$this->assertSame( 'DESC', $f->order );
	}

	public function test_order_accepts_asc_case_insensitive(): void {
		$f = $this->sc()->build_filter( [ 'order' => 'asc' ] );
		$this->assertSame( 'ASC', $f->order );
	}

	public function test_order_rejects_invalid_value(): void {
		$f = $this->sc()->build_filter( [ 'order' => 'RANDOM' ] );
		$this->assertSame( 'DESC', $f->order );
	}

	// -------------------------------------------------------------------------
	// build_filter — type + status
	// -------------------------------------------------------------------------

	public function test_status_is_always_forced_to_publish(): void {
		$f = $this->sc()->build_filter( [ 'status' => 'draft' ] );
		$this->assertSame( 'publish', $f->status, 'shortcode must never expose drafts' );
	}

	public function test_type_is_sanitized_via_sanitize_key(): void {
		$f = $this->sc()->build_filter( [ 'type' => 'FLASH_CARD!!@@' ] );
		$this->assertSame( 'flash_card', $f->type );
	}

	public function test_empty_type_leaves_filter_type_unset_or_null(): void {
		$f = $this->sc()->build_filter( [] );
		$this->assertTrue( null === $f->type || '' === $f->type );
	}

	// -------------------------------------------------------------------------
	// wrap_item — markup
	// -------------------------------------------------------------------------

	public function test_wrap_item_wraps_inner_html_in_typed_container(): void {
		$html = $this->sc()->wrap_item( 'flash_card', '<p>inner</p>' );
		$this->assertStringContainsString( 'lp-interactive-list__item', $html );
		$this->assertStringContainsString( 'lp-interactive-list__item--flash_card', $html );
		$this->assertStringContainsString( '<p>inner</p>', $html );
	}

	public function test_wrap_item_escapes_type_key_in_class_attribute(): void {
		$html = $this->sc()->wrap_item( 'evil"key', '' );
		$this->assertStringNotContainsString( 'evil"key', $html, 'type key must be esc_attr-encoded' );
	}

	// -------------------------------------------------------------------------
	// render() — full path with batched item loading
	// -------------------------------------------------------------------------

	private function inject_interactive_db( array $rows ): void {
		$db = Mockery::mock( InteractiveDB::class );
		$db->shouldReceive( 'get_interactives' )->andReturnUsing(
			static function ( $filter, &$total ) use ( $rows ) {
				$total = count( $rows );
				return $rows;
			}
		);
		$ref  = new \ReflectionClass( InteractiveDB::class );
		$prop = $ref->getProperty( '_instance' );
		$prop->setAccessible( true );
		$prop->setValue( null, $db );
	}

	private function inject_fake_type( string $key ): void {
		TypeRegistry::reset_for_tests();
		$fake = new class( $key ) implements \LearnPress\Interactive\Types\TypeInterface {
			public function __construct( private string $key_value ) {}
			public function key(): string { return $this->key_value; }
			public function label(): string { return 'Fake'; }
			public function default_settings(): array { return array(); }
			public function sanitize_settings( array $raw ): array { return $raw; }
			public function sanitize_item( array $raw ): array { return $raw; }
			public function render( array $entity, array $items ): string {
				return '[RENDERED ' . $entity['title'] . ' items=' . count( $items ) . ']';
			}
			public function frontend_handles(): array { return array(); }
		};
		TypeRegistry::register( $fake );
	}

	public function test_render_returns_empty_when_db_returns_no_rows(): void {
		$this->inject_interactive_db( array() );
		$html = $this->sc()->render( array() );
		$this->assertSame( '', $html );
	}

	public function test_render_wraps_each_entry_and_calls_type_render_with_batched_items(): void {
		Functions\when( 'apply_filters' )->returnArg( 2 ); // pass through filtered value untouched
		$this->inject_fake_type( 'fake' );

		$rows = array(
			(object) array(
				'ID'         => 1,
				'title'      => 'Alpha',
				'type'       => 'fake',
				'status'     => 'publish',
				'extra_data' => '',
				'author'     => 1,
				'created_at' => '',
				'updated_at' => '',
			),
			(object) array(
				'ID'         => 2,
				'title'      => 'Beta',
				'type'       => 'fake',
				'status'     => 'publish',
				'extra_data' => '',
				'author'     => 1,
				'created_at' => '',
				'updated_at' => '',
			),
		);
		$this->inject_interactive_db( $rows );

		// Stub the batched item-loading SQL path used by find_by_parent_ids().
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'prepare' )->andReturn( 'SELECT_STUB' );
		$wpdb->shouldReceive( 'get_results' )->andReturn(
			array(
				(object) array( 'ID' => 11, 'interactive_id' => 1, 'content' => 'a1', 'sort_order' => 1, 'extra_data' => '' ),
				(object) array( 'ID' => 12, 'interactive_id' => 1, 'content' => 'a2', 'sort_order' => 2, 'extra_data' => '' ),
				(object) array( 'ID' => 21, 'interactive_id' => 2, 'content' => 'b1', 'sort_order' => 1, 'extra_data' => '' ),
			)
		);

		$html = $this->sc()->render( array() );

		$this->assertStringContainsString( '<div class="lp-interactive-list">', $html );
		$this->assertStringContainsString( '[RENDERED Alpha items=2]', $html );
		$this->assertStringContainsString( '[RENDERED Beta items=1]', $html );
		// Order preserved (Alpha before Beta).
		$this->assertLessThan(
			strpos( $html, '[RENDERED Beta' ),
			strpos( $html, '[RENDERED Alpha' )
		);
	}

	public function test_render_skips_rows_whose_type_is_not_registered(): void {
		Functions\when( 'apply_filters' )->returnArg( 2 );
		TypeRegistry::reset_for_tests(); // no types registered → all rows skipped

		$this->inject_interactive_db( array(
			(object) array(
				'ID'         => 1,
				'title'      => 'X',
				'type'       => 'unknown_type',
				'status'     => 'publish',
				'extra_data' => '',
				'author'     => 1,
				'created_at' => '',
				'updated_at' => '',
			),
		) );

		$this->assertSame( '', $this->sc()->render( array() ) );
	}

	protected function tearDown(): void {
		TypeRegistry::reset_for_tests();
		$ref  = new \ReflectionClass( InteractiveDB::class );
		$prop = $ref->getProperty( '_instance' );
		$prop->setAccessible( true );
		$prop->setValue( null, null );
		parent::tearDown();
	}
}
