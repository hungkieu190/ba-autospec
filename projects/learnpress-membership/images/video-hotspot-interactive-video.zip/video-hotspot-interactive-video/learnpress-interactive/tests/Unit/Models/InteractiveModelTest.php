<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Models;

use Brain\Monkey\Functions;
use LearnPress\Interactive\Models\InteractiveModel;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use Mockery;
use stdClass;

/**
 * @covers \LearnPress\Interactive\Models\InteractiveModel
 */
class InteractiveModelTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();

		Functions\when( 'current_time' )->justReturn( '2026-05-06 10:00:00' );
		Functions\when( 'wp_json_encode' )->alias(
			static fn( $data, $flags = 0 ) => json_encode( $data, (int) $flags )
		);

		$wpdb            = Mockery::mock();
		$wpdb->prefix    = 'wp_';
		$wpdb->insert_id = 0;
		$GLOBALS['wpdb'] = $wpdb;
	}

	public function test_construct_with_data_populates_properties(): void {
		$row = (object) [
			'ID'         => '5',
			'title'      => 'Learn programming',
			'type'       => 'flash_card',
			'status'     => 'publish',
			'extra_data' => '{"open_first_by_default":true}',
			'author'     => '3',
			'created_at' => '2026-05-06 09:00:00',
			'updated_at' => '2026-05-06 09:00:00',
		];

		$model = new InteractiveModel( $row );

		$this->assertSame( 5, $model->ID );
		$this->assertSame( 'Learn programming', $model->title );
		$this->assertSame( 'flash_card', $model->type );
		$this->assertSame( 3, $model->author );
		$this->assertIsArray( $model->extra_data );
		$this->assertTrue( $model->extra_data['open_first_by_default'] );
	}

	public function test_map_to_object_decodes_extra_data_string_to_array(): void {
		$model = new InteractiveModel();
		$model->map_to_object( [ 'extra_data' => '{"a":1,"b":"x"}' ] );

		$this->assertSame( [ 'a' => 1, 'b' => 'x' ], $model->extra_data );
	}

	public function test_map_to_object_falls_back_to_empty_array_on_invalid_json(): void {
		$model = new InteractiveModel();
		$model->map_to_object( [ 'extra_data' => '{invalid json' ] );

		$this->assertSame( [], $model->extra_data );
	}

	public function test_save_inserts_when_id_zero_and_sets_created_at(): void {
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'insert' )
			->once()
			->with(
				'wp_learnpress_interactive',
				Mockery::on(
					static function ( $row ) {
						return 'New' === $row['title']
							&& 'flash_card' === $row['type']
							&& '2026-05-06 10:00:00' === $row['created_at']
							&& '2026-05-06 10:00:00' === $row['updated_at']
							&& '{"k":1}' === $row['extra_data'];
					}
				)
			)
			->andReturn( true );
		$wpdb->insert_id = 42;

		$model             = new InteractiveModel();
		$model->title      = 'New';
		$model->type       = 'flash_card';
		$model->extra_data = [ 'k' => 1 ];

		$id = $model->save();

		$this->assertSame( 42, $id );
		$this->assertSame( 42, $model->ID );
		$this->assertSame( '2026-05-06 10:00:00', $model->created_at );
	}

	public function test_save_updates_when_id_positive(): void {
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldNotReceive( 'insert' );
		$wpdb->shouldReceive( 'update' )
			->once()
			->with(
				'wp_learnpress_interactive',
				Mockery::on( static fn( $row ) => 'Renamed' === $row['title'] ),
				[ 'ID' => 99 ]
			)
			->andReturn( 1 );

		$model        = new InteractiveModel();
		$model->ID    = 99;
		$model->title = 'Renamed';

		$this->assertSame( 99, $model->save() );
	}

	public function test_save_uses_unescaped_json_for_extra_data(): void {
		$captured_row = null;
		$wpdb         = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( &$captured_row ) {
				$captured_row = $row;
				return true;
			}
		);
		$wpdb->insert_id = 1;

		$model             = new InteractiveModel();
		$model->title      = 'X';
		$model->extra_data = [ 'note' => 'Learn programming' ];
		$model->save();

		$this->assertNotNull( $captured_row );
		$this->assertStringContainsString( 'Learn programming', $captured_row['extra_data'], 'JSON text must be stored literally, not escaped' );
		$this->assertStringNotContainsString( '\\u00', $captured_row['extra_data'] );
	}

	public function test_soft_delete_sets_status_trash_and_calls_save(): void {
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'update' )
			->once()
			->with(
				'wp_learnpress_interactive',
				Mockery::on( static fn( $row ) => 'trash' === $row['status'] ),
				[ 'ID' => 7 ]
			)
			->andReturn( 1 );

		$model     = new InteractiveModel();
		$model->ID = 7;

		$this->assertTrue( $model->soft_delete() );
		$this->assertSame( 'trash', $model->status );
	}

	public function test_force_delete_returns_false_when_no_id(): void {
		$model = new InteractiveModel();
		$this->assertFalse( $model->force_delete() );
	}
}
