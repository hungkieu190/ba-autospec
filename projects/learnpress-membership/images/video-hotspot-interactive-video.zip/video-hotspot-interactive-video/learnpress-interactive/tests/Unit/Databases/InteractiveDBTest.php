<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Databases;

use LearnPress\Interactive\Databases\InteractiveDB;
use LearnPress\Interactive\Filters\InteractiveFilter;
use LearnPress\Interactive\Filters\InteractiveItemFilter;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use Mockery;
use ReflectionClass;

/**
 * @covers \LearnPress\Interactive\Databases\InteractiveDB
 */
class InteractiveDBTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();

		// Reset the singleton between tests so each gets a fresh wpdb.
		$ref = new ReflectionClass( InteractiveDB::class );
		$prop = $ref->getProperty( '_instance' );
		$prop->setAccessible( true );
		$prop->setValue( null, null );

		$wpdb         = Mockery::mock();
		$wpdb->prefix = 'wp_';
		$wpdb->shouldReceive( 'esc_like' )->byDefault()->andReturnUsing( static fn( $s ) => $s );
		$wpdb->shouldReceive( 'prepare' )->byDefault()->andReturnUsing(
			static fn( $sql, ...$args ) => 'PREPARED:' . $sql . ':' . implode( ',', $args )
		);
		$GLOBALS['wpdb'] = $wpdb;
	}

	/** @return InteractiveFilter */
	private function fresh_filter(): InteractiveFilter {
		return new InteractiveFilter();
	}

	public function test_get_interactives_adds_id_where_clause_when_filter_has_id(): void {
		$db        = InteractiveDB::getInstance();
		$filter    = $this->fresh_filter();
		$filter->ID = 42;

		$db->get_interactives( $filter );

		$this->assertNotEmpty( $filter->where, 'where clauses should be populated' );
		$found = false;
		foreach ( $filter->where as $clause ) {
			if ( str_contains( $clause, 'i.ID = %d' ) || str_contains( $clause, 'AND i.ID = %d' ) ) {
				$found = true;
				break;
			}
		}
		$this->assertTrue( $found, 'where clauses must include i.ID predicate' );
	}

	public function test_get_interactives_uses_LIKE_with_esc_like_for_title_search(): void {
		$db = InteractiveDB::getInstance();
		$GLOBALS['wpdb']->shouldReceive( 'esc_like' )->once()->with( 'Learn' )->andReturn( 'Learn' );

		$filter        = $this->fresh_filter();
		$filter->title = 'Learn';

		$db->get_interactives( $filter );

		$found = false;
		foreach ( $filter->where as $clause ) {
			if ( str_contains( $clause, 'title LIKE' ) ) {
				$found = true;
				break;
			}
		}
		$this->assertTrue( $found, 'title filter should produce a LIKE predicate' );
	}

	public function test_get_interactives_filters_by_type_and_status_and_author(): void {
		$db             = InteractiveDB::getInstance();
		$filter         = $this->fresh_filter();
		$filter->type   = 'flash_card';
		$filter->status = 'publish';
		$filter->author = 7;

		$db->get_interactives( $filter );

		$joined = implode( ' || ', $filter->where );
		$this->assertStringContainsString( 'i.type = %s', $joined );
		$this->assertStringContainsString( 'i.status = %s', $joined );
		$this->assertStringContainsString( 'i.author = %d', $joined );
	}

	public function test_get_interactives_skips_filters_when_properties_empty(): void {
		$db     = InteractiveDB::getInstance();
		$filter = $this->fresh_filter();

		$db->get_interactives( $filter );

		$this->assertSame( [], $filter->where, 'no domain filter set → no where clauses' );
	}

	public function test_get_interactive_items_filters_by_interactive_id(): void {
		$db                     = InteractiveDB::getInstance();
		$filter                 = new InteractiveItemFilter();
		$filter->interactive_id = 99;

		$db->get_interactive_items( $filter );

		$joined = implode( ' || ', $filter->where );
		$this->assertStringContainsString( 'ii.interactive_id = %d', $joined );
	}

	public function test_get_interactive_items_filters_by_id_when_set(): void {
		$db        = InteractiveDB::getInstance();
		$filter    = new InteractiveItemFilter();
		$filter->ID = 5;

		$db->get_interactive_items( $filter );

		$joined = implode( ' || ', $filter->where );
		$this->assertStringContainsString( 'ii.ID = %d', $joined );
	}
}
