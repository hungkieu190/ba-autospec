<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Types;

use Brain\Monkey\Functions;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use LearnPress\Interactive\Types\FlashCardType;
use LearnPress\Interactive\Types\TypeInterface;

/**
 * @covers \LearnPress\Interactive\Types\FlashCardType
 */
class FlashCardTypeTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();
		Functions\when( 'wp_get_attachment_image_url' )->alias(
			static fn( $id, $size = 'medium' ) => $id > 0 ? 'http://example.test/img/' . (int) $id . '.jpg' : ''
		);
		Functions\when( 'wp_json_encode' )->alias(
			static fn( $data, $flags = 0 ) => json_encode( $data, $flags )
		);
	}

	public function test_implements_interface_and_key_is_flash_card(): void {
		$t = new FlashCardType();
		$this->assertInstanceOf( TypeInterface::class, $t );
		$this->assertSame( 'flash_card', $t->key() );
	}

	public function test_default_settings_has_layout_progress_shuffle_require_flip(): void {
		$defaults = ( new FlashCardType() )->default_settings();
		$this->assertSame( 'slider', $defaults['layout'] );
		$this->assertTrue(  $defaults['show_progress'] );
		$this->assertFalse( $defaults['shuffle'] );
		$this->assertTrue(  $defaults['require_flip'], 'new decks default to require-flip ON for active recall' );
		$this->assertSame( '#111827', $defaults['text_color'] );
		$this->assertSame( '#ffffff', $defaults['background_color'] );
	}

	public function test_sanitize_settings_whitelists_layout_enum(): void {
		$clean = ( new FlashCardType() )->sanitize_settings( array( 'layout' => 'grid' ) );
		$this->assertSame( 'grid', $clean['layout'] );

		$clean = ( new FlashCardType() )->sanitize_settings( array( 'layout' => 'random_value' ) );
		$this->assertSame( 'slider', $clean['layout'], 'invalid layout falls back to slider' );
	}

	public function test_sanitize_settings_casts_bools(): void {
		$clean = ( new FlashCardType() )->sanitize_settings( array(
			'show_progress' => '1',
			'shuffle'       => '',
			'require_flip'  => '1',
		) );
		$this->assertTrue(  $clean['show_progress'] );
		$this->assertFalse( $clean['shuffle'] );
		$this->assertTrue(  $clean['require_flip'] );
	}

	public function test_sanitize_settings_keeps_valid_hex_colors(): void {
		$clean = ( new FlashCardType() )->sanitize_settings( array(
			'text_color'       => '#1f2937',
			'background_color' => '#f8fafc',
		) );

		$this->assertSame( '#1f2937', $clean['text_color'] );
		$this->assertSame( '#f8fafc', $clean['background_color'] );
	}

	public function test_sanitize_settings_falls_back_for_invalid_colors(): void {
		$clean = ( new FlashCardType() )->sanitize_settings( array(
			'text_color'       => 'red',
			'background_color' => 'javascript:alert(1)',
		) );

		$this->assertSame( '#111827', $clean['text_color'] );
		$this->assertSame( '#ffffff', $clean['background_color'] );
	}

	public function test_sanitize_settings_falls_back_to_defaults_when_keys_omitted(): void {
		$defaults = ( new FlashCardType() )->default_settings();
		$clean    = ( new FlashCardType() )->sanitize_settings( array() );
		$this->assertSame( $defaults['layout'],        $clean['layout'] );
		$this->assertSame( $defaults['show_progress'], $clean['show_progress'] );
		$this->assertSame( $defaults['shuffle'],       $clean['shuffle'] );
		$this->assertSame( $defaults['require_flip'],  $clean['require_flip'] );
		$this->assertSame( $defaults['text_color'],    $clean['text_color'] );
		$this->assertSame( $defaults['background_color'], $clean['background_color'] );
	}

	public function test_sanitize_settings_preserves_explicit_false(): void {
		$clean = ( new FlashCardType() )->sanitize_settings( array(
			'layout'        => 'slider',
			'show_progress' => false,
			'require_flip'  => false,
		) );
		$this->assertFalse( $clean['show_progress'] );
		$this->assertFalse( $clean['require_flip'] );
	}

	public function test_render_emits_data_require_flip_attribute(): void {
		$html = ( new FlashCardType() )->render(
			array( 'extra_data' => array( 'require_flip' => true ) ),
			array( $this->makeItemRow( 'A', 'B' ) )
		);
		$this->assertStringContainsString( 'data-require-flip="1"', $html );
	}

	public function test_render_emits_data_require_flip_zero_when_disabled(): void {
		$html = ( new FlashCardType() )->render(
			array( 'extra_data' => array( 'require_flip' => false ) ),
			array( $this->makeItemRow( 'A', 'B' ) )
		);
		$this->assertStringContainsString( 'data-require-flip="0"', $html );
	}

	public function test_render_emits_data_layout_attribute(): void {
		$html = ( new FlashCardType() )->render(
			array( 'extra_data' => array( 'layout' => 'grid' ) ),
			array( $this->makeItemRow( 'A', 'B' ) )
		);
		$this->assertStringContainsString( 'data-layout="grid"', $html );
	}

	public function test_render_emits_color_css_variables(): void {
		$html = ( new FlashCardType() )->render(
			array( 'extra_data' => array(
				'text_color'       => '#1f2937',
				'background_color' => '#f8fafc',
			) ),
			array( $this->makeItemRow( 'A', 'B' ) )
		);

		$this->assertStringContainsString( '--lp-interactive-fc-text-color:#1f2937;', $html );
		$this->assertStringContainsString( '--lp-interactive-fc-background-color:#f8fafc;', $html );
	}

	public function test_render_defaults_to_slider_layout(): void {
		$html = ( new FlashCardType() )->render(
			array(),
			array( $this->makeItemRow( 'A', 'B' ) )
		);
		$this->assertStringContainsString( 'data-layout="slider"', $html );
	}

	public function test_frontend_handles_returns_flash_card_handle(): void {
		$this->assertSame( array( 'lp-interactive-flash-card' ), ( new FlashCardType() )->frontend_handles() );
	}

	public function test_sanitize_item_returns_storage_shape(): void {
		$clean = ( new FlashCardType() )->sanitize_item( array() );
		$this->assertArrayHasKey( 'content', $clean );
		$this->assertArrayHasKey( 'extra_data', $clean );
		$this->assertIsString( $clean['content'] );
		$this->assertIsArray(  $clean['extra_data'] );
	}

	public function test_sanitize_item_emits_title_image_and_subtitle_in_content_per_side(): void {
		$clean = ( new FlashCardType() )->sanitize_item( array(
			'front' => array(
				'title'    => 'Front title',
				'image_id' => 42,
				'subtitle' => 'Front subtitle',
			),
			'back'  => array(
				'title'    => 'Back title',
				'image_id' => 43,
				'subtitle' => 'Back subtitle',
			),
		) );

		$content_decoded = json_decode( $clean['content'], true );
		$this->assertIsArray( $content_decoded );
		$this->assertSame( 'Front title',    $content_decoded['front']['title'] );
		$this->assertSame( 42,               $content_decoded['front']['image_id'] );
		$this->assertSame( 'Front subtitle', $content_decoded['front']['subtitle'] );
		$this->assertSame( 'Back title',     $content_decoded['back']['title'] );
		$this->assertSame( 43,               $content_decoded['back']['image_id'] );
		$this->assertSame( 'Back subtitle',  $content_decoded['back']['subtitle'] );
	}

	public function test_sanitize_item_emits_empty_extra_data_for_flash_card_items(): void {
		$clean = ( new FlashCardType() )->sanitize_item( array(
			'front' => array( 'title' => '<p>Hi</p>', 'image_id' => 42 ),
			'back'  => array( 'title' => '<p>Bye</p>', 'image_id' => 43 ),
		) );

		$this->assertIsArray( $clean['extra_data'] );
		$this->assertSame( array(), $clean['extra_data'] );
	}

	public function test_sanitize_item_strips_unsafe_html_via_kses(): void {
		$clean = ( new FlashCardType() )->sanitize_item( array(
			'front' => array(
				'title'    => '<p>Hi</p><script>alert(1)</script>',
				'subtitle' => '<p>Sub</p><script>alert(2)</script>',
			),
		) );
		$content_decoded = json_decode( $clean['content'], true );
		$this->assertStringNotContainsString( '<script>', $content_decoded['front']['title'] );
		$this->assertStringNotContainsString( '<script>', $content_decoded['front']['subtitle'] );
		$this->assertSame( 'Hi', $content_decoded['front']['title'] );
		$this->assertSame( 'Sub', $content_decoded['front']['subtitle'] );
	}

	public function test_sanitize_item_casts_image_id_to_absint(): void {
		$clean = ( new FlashCardType() )->sanitize_item( array(
			'front' => array( 'image_id' => '-5' ),
			'back'  => array( 'image_id' => '42' ),
		) );
		$content_decoded = json_decode( $clean['content'], true );
		$this->assertSame( 5,  $content_decoded['front']['image_id'] );
		$this->assertSame( 42, $content_decoded['back']['image_id'] );
	}

	/**
	 * Round-trip a stored DB row (content carries all card fields) back through
	 * sanitize_item. Mirrors what InteractiveService::duplicate() does: rows
	 * are decoded to canonical shape first, then re-sanitized for the copy.
	 * Title, image_id, and subtitle must survive.
	 */
	public function test_decode_then_sanitize_preserves_title_image_and_subtitle(): void {
		$stored = array(
			'content'    => json_encode( array(
				'front' => array(
					'title'    => '<p>front</p>',
					'image_id' => 7,
					'subtitle' => '<p>front sub</p>',
				),
				'back'  => array(
					'title'    => '<p>back</p>',
					'image_id' => 9,
					'subtitle' => '<p>back sub</p>',
				),
			) ),
			'extra_data' => '{}',
		);

		$canonical = FlashCardType::decode_card( $stored );
		$clean     = ( new FlashCardType() )->sanitize_item( $canonical );

		$content_decoded = json_decode( $clean['content'], true );

		$this->assertSame( 'front',     $content_decoded['front']['title'] );
		$this->assertSame( 7,           $content_decoded['front']['image_id'] );
		$this->assertSame( 'front sub', $content_decoded['front']['subtitle'] );
		$this->assertSame( 'back',      $content_decoded['back']['title'] );
		$this->assertSame( 9,           $content_decoded['back']['image_id'] );
		$this->assertSame( 'back sub',  $content_decoded['back']['subtitle'] );
		$this->assertSame( array(), $clean['extra_data'] );
	}

	public function test_sanitize_item_defaults_missing_sides_to_empty(): void {
		$clean = ( new FlashCardType() )->sanitize_item( array() );

		$content_decoded = json_decode( $clean['content'], true );

		$this->assertSame( '', $content_decoded['front']['title'] );
		$this->assertSame( 0,  $content_decoded['front']['image_id'] );
		$this->assertSame( '', $content_decoded['front']['subtitle'] );
		$this->assertSame( '', $content_decoded['back']['title'] );
		$this->assertSame( 0,  $content_decoded['back']['image_id'] );
		$this->assertSame( '', $content_decoded['back']['subtitle'] );
		$this->assertSame( array(), $clean['extra_data'] );
	}

	public function test_decode_card_reads_structured_content(): void {
		$item = array(
			'content'    => json_encode( array(
				'front' => array( 'title' => 'F', 'image_id' => 11, 'subtitle' => 'FS' ),
				'back'  => array( 'title' => 'B', 'image_id' => 22, 'subtitle' => 'BS' ),
			) ),
			'extra_data' => '{}',
		);
		$card = FlashCardType::decode_card( $item );

		$this->assertSame( 'F',  $card['front']['title'] );
		$this->assertSame( 11,   $card['front']['image_id'] );
		$this->assertSame( 'FS', $card['front']['subtitle'] );
		$this->assertSame( 'B',  $card['back']['title'] );
		$this->assertSame( 22,   $card['back']['image_id'] );
		$this->assertSame( 'BS', $card['back']['subtitle'] );
	}

	public function test_decode_card_ignores_removed_legacy_text_and_background_shape(): void {
		$item = array(
			'content'    => json_encode( array( 'front' => '<p>F</p>', 'back' => '<p>B</p>' ) ),
			'extra_data' => json_encode( array(
				'front' => array( 'background_id' => 11 ),
				'back'  => array( 'background_id' => 22 ),
			) ),
		);
		$card = FlashCardType::decode_card( $item );

		$this->assertSame( '', $card['front']['title'] );
		$this->assertSame( 0,  $card['front']['image_id'] );
		$this->assertSame( '', $card['front']['subtitle'] );
		$this->assertSame( '', $card['back']['title'] );
		$this->assertSame( 0,  $card['back']['image_id'] );
		$this->assertSame( '', $card['back']['subtitle'] );
	}

	public function test_decode_card_tolerates_empty_row(): void {
		$card = FlashCardType::decode_card( array() );
		$this->assertSame( '', $card['front']['title'] );
		$this->assertSame( 0,  $card['front']['image_id'] );
		$this->assertSame( '', $card['front']['subtitle'] );
		$this->assertSame( '', $card['back']['title'] );
		$this->assertSame( 0,  $card['back']['image_id'] );
		$this->assertSame( '', $card['back']['subtitle'] );
	}

	public function test_decode_card_tolerates_missing_extra_data(): void {
		$item = array(
			'content'    => json_encode( array(
				'front' => array( 'title' => '<p>A</p>', 'image_id' => 3, 'subtitle' => '<p>AS</p>' ),
				'back'  => array( 'title' => '<p>B</p>', 'image_id' => 4, 'subtitle' => '<p>BS</p>' ),
			) ),
			'extra_data' => '',
		);
		$card = FlashCardType::decode_card( $item );
		$this->assertSame( '<p>A</p>',  $card['front']['title'] );
		$this->assertSame( 3,           $card['front']['image_id'] );
		$this->assertSame( '<p>AS</p>', $card['front']['subtitle'] );
		$this->assertSame( '<p>B</p>',  $card['back']['title'] );
		$this->assertSame( 4,           $card['back']['image_id'] );
		$this->assertSame( '<p>BS</p>', $card['back']['subtitle'] );
	}

	public function test_decode_card_tolerates_garbage_extra_data(): void {
		$item = array(
			'content'    => json_encode( array(
				'front' => array( 'title' => '<p>A</p>', 'image_id' => 3 ),
				'back'  => array( 'title' => '<p>B</p>', 'image_id' => 4 ),
			) ),
			'extra_data' => '{not valid json',
		);
		$card = FlashCardType::decode_card( $item );
		$this->assertSame( 3, $card['front']['image_id'] );
		$this->assertSame( 4, $card['back']['image_id']  );
	}

	public function test_render_wraps_in_root_container(): void {
		$html = ( new FlashCardType() )->render( array(), array() );
		$this->assertStringContainsString( 'class="lp-interactive-flash-cards"', $html );
	}

	public function test_render_emits_single_card_slot_regardless_of_item_count(): void {
		$html = ( new FlashCardType() )->render(
			array(),
			array(
				$this->makeItemRow( 'F1', 'B1' ),
				$this->makeItemRow( 'F2', 'B2' ),
				$this->makeItemRow( 'F3', 'B3' ),
			)
		);
		$this->assertSame( 1, substr_count( $html, 'class="lp-interactive-flash-card"' ) );
	}

	public function test_render_emits_header_progress_nav_done_sections(): void {
		$html = ( new FlashCardType() )->render( array(), array( $this->makeItemRow( 'A', 'B' ) ) );
		$this->assertStringContainsString( 'lp-interactive-flash-cards__header',        $html );
		$this->assertStringContainsString( 'lp-interactive-flash-cards__progress-wrap', $html );
		$this->assertStringContainsString( 'lp-interactive-flash-cards__progress-fill', $html );
		$this->assertStringContainsString( 'lp-interactive-flash-cards__nav',           $html );
		$this->assertStringContainsString( 'lp-interactive-flash-cards__prev',          $html );
		$this->assertStringContainsString( 'lp-interactive-flash-cards__next',          $html );
		$this->assertStringContainsString( 'lp-interactive-flash-cards__done',          $html );
		$this->assertStringContainsString( 'lp-interactive-flash-cards__restart',       $html );
	}

	public function test_render_emits_front_and_back_face_slots(): void {
		$html = ( new FlashCardType() )->render( array(), array( $this->makeItemRow( 'A', 'B' ) ) );
		$this->assertStringContainsString( 'lp-interactive-flash-card__front', $html );
		$this->assertStringContainsString( 'lp-interactive-flash-card__back',  $html );
		$this->assertStringContainsString( 'lp-interactive-flash-card__text',  $html );
	}

	public function test_render_includes_total_in_data_attribute_and_meta_label(): void {
		$html = ( new FlashCardType() )->render(
			array(),
			array(
				$this->makeItemRow( 'A', 'B' ),
				$this->makeItemRow( 'C', 'D' ),
			)
		);
		$this->assertStringContainsString( 'data-total="2"',  $html );
		$this->assertStringContainsString( 'Card 1 of 2',     $html );
		$this->assertStringContainsString( '0 / 2 completed', $html );
	}

	public function test_render_embeds_deck_as_inline_json(): void {
		$html = ( new FlashCardType() )->render(
			array(),
			array(
				$this->makeItemRow( 'Apple', 'Apple translation' ),
			)
		);
		$this->assertStringContainsString( '<script type="application/json"', $html );
		$this->assertStringContainsString( 'lp-interactive-flash-cards__data', $html );
		$this->assertStringContainsString( '"front":{', $html );
		$this->assertStringContainsString( '"back":{',  $html );
		$this->assertStringContainsString( 'Apple', $html );
		$this->assertStringContainsString( 'Apple translation', $html );
	}

	public function test_render_includes_image_urls_when_image_id_set(): void {
		$html = ( new FlashCardType() )->render(
			array(),
			array(
				$this->makeItemRow( 'Q', 'A', 7, 9 ),
			)
		);
		$this->assertStringContainsString( 'img\/7.jpg', $html );
		$this->assertStringContainsString( 'img\/9.jpg', $html );
	}

	public function test_render_uses_entity_title_in_header(): void {
		$html = ( new FlashCardType() )->render(
			array( 'title' => 'Everyday Words' ),
			array( $this->makeItemRow( 'A', 'B' ) )
		);
		$this->assertStringContainsString( 'Everyday Words', $html );
	}

	/**
	 * Helper: build a stored-row shape for FlashCardType::render().
	 */
	private function makeItemRow(
		string $front_title,
		string $back_title,
		int $front_image_id = 0,
		int $back_image_id = 0,
		string $front_subtitle = '',
		string $back_subtitle = ''
	): array {
		return array(
			'content'    => json_encode( array(
				'front' => array(
					'title'    => $front_title,
					'image_id' => $front_image_id,
					'subtitle' => $front_subtitle,
				),
				'back'  => array(
					'title'    => $back_title,
					'image_id' => $back_image_id,
					'subtitle' => $back_subtitle,
				),
			) ),
			'extra_data' => '{}',
		);
	}
}
