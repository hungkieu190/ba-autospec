<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Helpers;

use Brain\Monkey\Functions;
use LearnPress\Interactive\Helpers\Icon;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;

/**
 * @covers \LearnPress\Interactive\Helpers\Icon
 */
class IconTest extends BrainMonkeyTestCase {

	/**
	 * Temp directory whose `assets/images/svg/` subfolder holds fixture SVGs.
	 * `plugin_dir_path()` is stubbed per-test to return this directory, so
	 * Icon::load() reads from here instead of the real plugin assets.
	 */
	private static string $fixture_root = '';

	public static function setUpBeforeClass(): void {
		parent::setUpBeforeClass();

		self::$fixture_root = sys_get_temp_dir() . '/lp-interactive-icon-test-' . uniqid();
		mkdir( self::$fixture_root . '/assets/images/svg', 0777, true );

		file_put_contents(
			self::$fixture_root . '/assets/images/svg/ico-pencil.svg',
			'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="16" height="16"><path d="M0 0" stroke="currentColor"/></svg>'
		);

		file_put_contents(
			self::$fixture_root . '/assets/images/svg/ico-confetti.svg',
			'<?xml version="1.0"?>' . "\n"
			. '<svg xmlns="http://www.w3.org/2000/svg" class="existing-class" viewBox="0 0 32 32"><circle cx="16" cy="16" r="4"/></svg>'
		);
	}

	public static function tearDownAfterClass(): void {
		parent::tearDownAfterClass();

		$it = new \RecursiveIteratorIterator(
			new \RecursiveDirectoryIterator( self::$fixture_root, \FilesystemIterator::SKIP_DOTS ),
			\RecursiveIteratorIterator::CHILD_FIRST
		);
		foreach ( $it as $f ) {
			$f->isDir() ? rmdir( $f->getRealPath() ) : unlink( $f->getRealPath() );
		}
		rmdir( self::$fixture_root );
	}

	protected function setUp(): void {
		parent::setUp();
		Icon::reset_cache();

		// Override the default stub from BrainMonkeyTestCase so Icon::load()
		// resolves against our fixture root instead of the real plugin dir
		// (LP_ADDON_INTERACTIVE_FILE is locked by tests/bootstrap.php).
		$root = self::$fixture_root;
		Functions\when( 'plugin_dir_path' )->alias(
			static fn( $file = '' ) => $root . '/'
		);
	}

	public function test_renders_inline_svg_by_name(): void {
		$out = Icon::render( 'pencil' );

		$this->assertStringStartsWith( '<svg', $out );
		$this->assertStringContainsString( 'viewBox="0 0 16 16"', $out );
		$this->assertStringContainsString( '<path d="M0 0"', $out );
	}

	public function test_returns_empty_string_for_missing_icon(): void {
		$this->assertSame( '', Icon::render( 'does-not-exist' ) );
	}

	public function test_returns_empty_string_for_blank_name(): void {
		$this->assertSame( '', Icon::render( '' ) );
		$this->assertSame( '', Icon::render( '   ' ) );
	}

	public function test_strips_xml_declaration(): void {
		$out = Icon::render( 'confetti' );

		$this->assertStringStartsWith( '<svg', $out );
		$this->assertStringNotContainsString( '<?xml', $out );
	}

	public function test_appends_class_attribute_without_replacing_existing(): void {
		$out = Icon::render( 'confetti', array( 'class' => 'my-added' ) );

		$this->assertStringContainsString( 'class="existing-class my-added"', $out );
	}

	public function test_adds_new_attribute_when_not_present(): void {
		$out = Icon::render( 'pencil', array( 'aria-label' => 'Edit pencil' ) );

		$this->assertStringContainsString( 'aria-label="Edit pencil"', $out );
	}

	public function test_overwrites_existing_non_class_attribute(): void {
		$out = Icon::render( 'pencil', array( 'viewBox' => '0 0 32 32' ) );

		$this->assertStringContainsString( 'viewBox="0 0 32 32"', $out );
		$this->assertStringNotContainsString( 'viewBox="0 0 16 16"', $out );
	}

	public function test_escapes_attribute_values(): void {
		$out = Icon::render( 'pencil', array( 'data-x' => '"><script>x</script>' ) );

		$this->assertStringNotContainsString( '<script>', $out );
		$this->assertStringContainsString( 'data-x="', $out );
	}

	public function test_caches_within_single_request(): void {
		$first  = Icon::render( 'pencil' );
		$second = Icon::render( 'pencil' );

		$this->assertSame( $first, $second );
		$this->assertNotSame( '', $first );
	}

	public function test_reset_cache_forces_reload(): void {
		Icon::render( 'pencil' );
		Icon::reset_cache();
		$after = Icon::render( 'pencil' );

		$this->assertStringContainsString( '<svg', $after );
	}
}
