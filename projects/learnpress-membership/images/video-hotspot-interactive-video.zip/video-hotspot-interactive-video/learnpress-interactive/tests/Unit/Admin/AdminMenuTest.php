<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Admin;

use Brain\Monkey\Functions;
use LearnPress\Interactive\Admin\AdminMenu;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use LearnPress\Interactive\Tests\Helpers\FakeServiceType;
use LearnPress\Interactive\Types\TypeRegistry;

/**
 * @covers \LearnPress\Interactive\Admin\AdminMenu
 */
class AdminMenuTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();
		AdminMenu::reset_for_tests();
		TypeRegistry::reset_for_tests();
		TypeRegistry::register( new FakeServiceType() );
	}

	public function test_constants_match_spec(): void {
		$this->assertSame( 'lp-interactive', AdminMenu::SLUG );
		$this->assertSame( 'edit_lp_courses', AdminMenu::CAPABILITY );
		$this->assertSame( 'learn_press', AdminMenu::PARENT_SLUG );
	}

	public function test_init_hooks_register_menu_to_admin_menu_action(): void {
		$hooked   = null;
		$priority = null;
		Functions\when( 'add_action' )->alias(
			static function ( $hook, $callback, $prio = 10 ) use ( &$hooked, &$priority ) {
				if ( 'admin_menu' === $hook ) {
					$hooked   = $callback;
					$priority = $prio;
				}
				return true;
			}
		);

		AdminMenu::instance();

		$this->assertIsArray( $hooked, 'admin_menu hook must be registered' );
		$this->assertInstanceOf( AdminMenu::class, $hooked[0] );
		$this->assertSame( 'register_menu', $hooked[1] );
		$this->assertSame( 60, $priority, 'must hook after LP core admin menu registers' );
	}

	public function test_register_menu_calls_add_submenu_page_under_learnpress(): void {
		Functions\when( 'add_action' )->justReturn( true );
		$captured = array();
		Functions\when( 'add_submenu_page' )->alias(
			static function ( $parent, $page_title, $menu_title, $cap, $slug, $callback ) use ( &$captured ) {
				$captured = compact( 'parent', 'page_title', 'menu_title', 'cap', 'slug', 'callback' );
				return 'lp-interactive';
			}
		);

		AdminMenu::instance()->register_menu();

		$this->assertSame( 'learn_press', $captured['parent'], 'parent slug must be the LearnPress top-level menu' );
		$this->assertSame( 'Interactive', $captured['menu_title'] );
		$this->assertSame( 'edit_lp_courses', $captured['cap'] );
		$this->assertSame( 'lp-interactive', $captured['slug'] );
		$this->assertIsArray( $captured['callback'] );
		$this->assertSame( 'render', $captured['callback'][1] );
	}

	public function test_render_dispatches_to_list_when_no_action(): void {
		Functions\when( 'add_action' )->justReturn( true );
		$_GET = array();

		// Capture output to verify list page rendered (looks for the wrap class).
		ob_start();
		AdminMenu::instance()->render();
		$output = ob_get_clean();

		$this->assertStringContainsString( 'lp-interactive-list-wrap', $output );
	}

	public function test_render_dispatches_to_create_form_when_action_is_new(): void {
		Functions\when( 'add_action' )->justReturn( true );
		$_GET = array( 'action' => 'new' );

		ob_start();
		AdminMenu::instance()->render();
		$output = ob_get_clean();

		$this->assertStringContainsString( 'lp-interactive-create', $output );
	}

	public function test_render_falls_back_to_list_for_unknown_action(): void {
		Functions\when( 'add_action' )->justReturn( true );
		$_GET = array( 'action' => 'nonexistent' );

		ob_start();
		AdminMenu::instance()->render();
		$output = ob_get_clean();

		$this->assertStringContainsString( 'lp-interactive-list-wrap', $output );
	}
}
