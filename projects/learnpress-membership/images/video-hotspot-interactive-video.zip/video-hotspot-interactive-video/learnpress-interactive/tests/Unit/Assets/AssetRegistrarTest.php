<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Assets;

use Brain\Monkey\Actions;
use Brain\Monkey\Functions;
use LearnPress\Interactive\Assets\AssetRegistrar;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;

/**
 * @covers \LearnPress\Interactive\Assets\AssetRegistrar
 */
class AssetRegistrarTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();
		AssetRegistrar::reset_for_tests();

		Functions\when( 'plugins_url' )->alias(
			static fn( $path, $file ) => 'http://example.test/wp-content/plugins/learnpress-interactive/' . ltrim( $path, '/' )
		);
		Functions\when( 'plugin_dir_path' )->alias(
			static fn( $file ) => '/fake/wp/wp-content/plugins/learnpress-interactive/'
		);

		Functions\when( 'wp_enqueue_media' )->justReturn( null );
		Functions\when( 'wp_localize_script' )->justReturn( true );
		Functions\when( 'learn_press_is_course' )->justReturn( false );

		if ( ! defined( 'LP_ADDON_INTERACTIVE_FILE' ) ) {
			define( 'LP_ADDON_INTERACTIVE_FILE', '/fake/wp/wp-content/plugins/learnpress-interactive/learnpress-interactive.php' );
		}
	}

	public function test_register_hooks_and_is_idempotent_when_called_twice(): void {
		$frontend_count = 0;
		$admin_count    = 0;
		Functions\when( 'add_action' )->alias(
			static function ( $hook, $callback ) use ( &$frontend_count, &$admin_count ) {
				if ( ! is_array( $callback ) || AssetRegistrar::class !== $callback[0] ) {
					return true;
				}
				if ( 'wp_enqueue_scripts' === $hook && 'register_handles' === $callback[1] ) {
					$frontend_count++;
				}
				if ( 'admin_enqueue_scripts' === $hook && 'register_admin_handles' === $callback[1] ) {
					$admin_count++;
				}
				return true;
			}
		);

		AssetRegistrar::register();
		AssetRegistrar::register();
		AssetRegistrar::register();

		$this->assertSame( 1, $frontend_count, 'wp_enqueue_scripts must be hooked exactly once' );
		$this->assertSame( 1, $admin_count, 'admin_enqueue_scripts must be hooked exactly once' );
	}

	public function test_register_admin_handles_skips_when_page_query_is_not_lp_interactive(): void {
		$_GET = array( 'page' => 'some-other-page' );

		$registered = false;
		Functions\when( 'wp_register_script' )->alias( static function () use ( &$registered ) {
			$registered = true;
		} );
		Functions\when( 'wp_register_style' )->justReturn( null );
		Functions\when( 'wp_enqueue_script' )->justReturn( null );
		Functions\when( 'wp_enqueue_style' )->justReturn( null );

		AssetRegistrar::register_admin_handles();

		$this->assertFalse( $registered, 'admin bundle must not register on unrelated admin pages' );
	}

	public function test_register_admin_handles_skips_when_no_page_query_at_all(): void {
		$_GET = array();

		$registered = false;
		Functions\when( 'wp_register_script' )->alias( static function () use ( &$registered ) {
			$registered = true;
		} );
		Functions\when( 'wp_register_style' )->justReturn( null );
		Functions\when( 'wp_enqueue_script' )->justReturn( null );
		Functions\when( 'wp_enqueue_style' )->justReturn( null );

		AssetRegistrar::register_admin_handles();

		$this->assertFalse( $registered );
	}

	public function test_register_admin_handles_registers_and_enqueues_on_lp_interactive_page(): void {
		$_GET = array( 'page' => 'lp-interactive' );

		$registered     = array();
		$enqueued       = array();
		$style_enqueued = array();
		$media_enqueued = false;
		Functions\when( 'wp_register_script' )->alias(
			static function ( $handle, $src, $deps, $ver, $in_footer ) use ( &$registered ) {
				$registered[ $handle ] = compact( 'src', 'deps', 'ver', 'in_footer' );
				return true;
			}
		);
		Functions\when( 'wp_register_style' )->justReturn( null );
		Functions\when( 'wp_enqueue_script' )->alias(
			static function ( $handle ) use ( &$enqueued ) {
				$enqueued[] = $handle;
			}
		);
		Functions\when( 'wp_enqueue_style' )->alias(
			static function ( $handle ) use ( &$style_enqueued ) {
				$style_enqueued[] = $handle;
			}
		);
		Functions\when( 'wp_enqueue_media' )->alias(
			static function () use ( &$media_enqueued ) {
				$media_enqueued = true;
			}
		);

		AssetRegistrar::register_admin_handles();

		$this->assertArrayHasKey( 'lp-admin-interactive', $registered );
		$this->assertContains( 'lp-admin-interactive', $enqueued );
		$this->assertContains( 'postbox', $registered['lp-admin-interactive']['deps'] );
		$this->assertStringContainsString(
			'assets/dist/js/admin/lp-admin-interactive.min.js',
			$registered['lp-admin-interactive']['src']
		);
		$this->assertTrue( $registered['lp-admin-interactive']['in_footer'] );
		$this->assertContains( 'lp-admin-interactive', $style_enqueued, 'admin CSS bundle must be enqueued' );
		$this->assertTrue( $media_enqueued, 'wp_enqueue_media() must be called so SlideEditor wp.media picker works' );
	}

	public function test_register_admin_handles_falls_back_safely_when_asset_manifest_missing(): void {
		$_GET = array( 'page' => 'lp-interactive' );

		Functions\when( 'plugin_dir_path' )->alias(
			static fn( $file ) => '/fake/wp/wp-content/plugins/nonexistent-' . uniqid() . '/'
		);

		$captured_deps    = null;
		$captured_version = 'sentinel';
		Functions\when( 'wp_register_script' )->alias(
			static function ( $handle, $src, $deps, $ver ) use ( &$captured_deps, &$captured_version ) {
				$captured_deps    = $deps;
				$captured_version = $ver;
				return true;
			}
		);
		Functions\when( 'wp_register_style' )->justReturn( null );
		Functions\when( 'wp_enqueue_script' )->justReturn( null );
		Functions\when( 'wp_enqueue_style' )->justReturn( null );

		AssetRegistrar::register_admin_handles();

		$this->assertSame( array( 'postbox' ), $captured_deps, 'fallback dependencies must include postbox for builder metabox toggles' );
		$this->assertNull( $captured_version, 'fallback version must be null' );
	}

	public function test_register_admin_handles_uses_non_min_when_lp_debug_is_active(): void {
		$_GET = array( 'page' => 'lp-interactive' );
		\LP_Debug::set_is_debug( true );

		$registered = array();
		Functions\when( 'wp_register_script' )->alias(
			static function ( $handle, $src, $deps, $ver, $in_footer ) use ( &$registered ) {
				$registered[ $handle ] = $src;
				return true;
			}
		);
		Functions\when( 'wp_register_style' )->justReturn( null );
		Functions\when( 'wp_enqueue_script' )->justReturn( null );
		Functions\when( 'wp_enqueue_style' )->justReturn( null );

		AssetRegistrar::register_admin_handles();

		\LP_Debug::set_is_debug( false );

		$this->assertArrayHasKey( 'lp-admin-interactive', $registered );
		$this->assertStringContainsString(
			'lp-admin-interactive.js',
			$registered['lp-admin-interactive'],
			'LP_Debug::is_debug() = true must prefer the non-minified bundle'
		);
		$this->assertStringNotContainsString(
			'.min.js',
			$registered['lp-admin-interactive'],
			'minified bundle must not load when LP debug mode is active'
		);
	}

	public function test_register_handles_registers_css_for_all_types(): void {
		$styles = array();
		Functions\when( 'wp_register_style' )->alias(
			static function ( $handle, $src ) use ( &$styles ) {
				$styles[ $handle ] = $src;
				return true;
			}
		);
		Functions\when( 'wp_register_script' )->justReturn( true );

		AssetRegistrar::register_handles();

		$this->assertArrayHasKey( 'lp-interactive-flash-card', $styles );
		$this->assertArrayNotHasKey( 'lp-interactive-slide', $styles );
		$this->assertStringContainsString( 'js/frontend/types/flash-card', $styles['lp-interactive-flash-card'] );
		$this->assertStringContainsString( '.css', $styles['lp-interactive-flash-card'] );
	}

	public function test_register_handles_registers_js_for_types_with_js(): void {
		Functions\when( 'wp_register_style' )->justReturn( true );
		$scripts = array();
		Functions\when( 'wp_register_script' )->alias(
			static function ( $handle, $src ) use ( &$scripts ) {
				$scripts[ $handle ] = $src;
				return true;
			}
		);

		AssetRegistrar::register_handles();

		$this->assertArrayHasKey( 'lp-interactive-flash-card', $scripts );
		$this->assertArrayNotHasKey( 'lp-interactive-slide', $scripts );
		$this->assertStringContainsString( 'js/frontend/types/flash-card', $scripts['lp-interactive-flash-card'] );
		$this->assertStringContainsString( '.js', $scripts['lp-interactive-flash-card'] );
	}

	public function test_enqueue_for_type_skips_unregistered_handles_silently(): void {
		Functions\when( 'wp_style_is' )->justReturn( false );
		Functions\when( 'wp_script_is' )->justReturn( false );

		$enqueued_styles  = 0;
		$enqueued_scripts = 0;
		Functions\when( 'wp_enqueue_style' )->alias( static function () use ( &$enqueued_styles ) {
			$enqueued_styles++;
		} );
		Functions\when( 'wp_enqueue_script' )->alias( static function () use ( &$enqueued_scripts ) {
			$enqueued_scripts++;
		} );

		AssetRegistrar::enqueue_for_type( array( 'lp-interactive-flash-card' ) );

		$this->assertSame( 0, $enqueued_styles );
		$this->assertSame( 0, $enqueued_scripts );
	}

	public function test_enqueue_for_type_enqueues_only_registered_handles(): void {
		Functions\when( 'wp_style_is' )->alias( static fn( $h, $list ) => 'registered' === $list );
		Functions\when( 'wp_script_is' )->justReturn( false );

		$style_calls  = array();
		$script_calls = array();
		Functions\when( 'wp_enqueue_style' )->alias( static function ( $h ) use ( &$style_calls ) {
			$style_calls[] = $h;
		} );
		Functions\when( 'wp_enqueue_script' )->alias( static function ( $h ) use ( &$script_calls ) {
			$script_calls[] = $h;
		} );

		AssetRegistrar::enqueue_for_type( array( 'lp-interactive-flash-card' ) );

		$this->assertSame( array( 'lp-interactive-flash-card' ), $style_calls );
		$this->assertSame( array(), $script_calls );
	}

	public function test_enqueue_for_type_skips_empty_or_non_string_handles(): void {
		Functions\when( 'wp_style_is' )->justReturn( true );
		Functions\when( 'wp_script_is' )->justReturn( true );

		$style_calls = 0;
		Functions\when( 'wp_enqueue_style' )->alias( static function () use ( &$style_calls ) {
			$style_calls++;
		} );
		Functions\when( 'wp_enqueue_script' )->justReturn( null );

		AssetRegistrar::enqueue_for_type( array( '', 0, null, 'valid-handle' ) );

		$this->assertSame( 1, $style_calls, 'only the one valid string handle should attempt enqueue' );
	}

	private function stub_handle_lookup_calls( array &$enqueued ): void {
		Functions\when( 'wp_style_is' )->justReturn( true );
		Functions\when( 'wp_script_is' )->justReturn( true );
		Functions\when( 'wp_enqueue_style' )->alias( static function ( $h ) use ( &$enqueued ) {
			$enqueued[] = $h;
		} );
		Functions\when( 'wp_enqueue_script' )->alias( static function ( $h ) use ( &$enqueued ) {
			$enqueued[] = $h;
		} );
	}

	public function test_eager_enqueue_short_circuits_in_admin(): void {
		Functions\when( 'is_admin' )->justReturn( true );
		$enqueued = array();
		$this->stub_handle_lookup_calls( $enqueued );

		AssetRegistrar::eager_enqueue_when_shortcode_present();

		$this->assertSame( array(), $enqueued, 'no frontend handle should be enqueued in admin context' );
	}

	public function test_eager_enqueue_does_nothing_when_no_shortcode_or_block_in_post(): void {
		Functions\when( 'is_admin' )->justReturn( false );
		Functions\when( 'has_shortcode' )->justReturn( false );
		Functions\when( 'has_block' )->justReturn( false );
		Functions\when( 'apply_filters' )->returnArg( 2 );
		$GLOBALS['post'] = (object) array( 'post_content' => 'plain post body, no interactive markup' );

		$enqueued = array();
		$this->stub_handle_lookup_calls( $enqueued );

		AssetRegistrar::eager_enqueue_when_shortcode_present();

		$this->assertSame( array(), $enqueued );
	}

	public function test_eager_enqueue_fires_on_lp_course_page_even_without_post_shortcode(): void {
		Functions\when( 'is_admin' )->justReturn( false );
		Functions\when( 'learn_press_is_course' )->justReturn( true );
		Functions\when( 'has_shortcode' )->justReturn( false );
		Functions\when( 'has_block' )->justReturn( false );
		Functions\when( 'apply_filters' )->returnArg( 2 );
		$GLOBALS['post'] = (object) array( 'post_content' => 'course description with no shortcode' );

		$enqueued = array();
		$this->stub_handle_lookup_calls( $enqueued );

		AssetRegistrar::eager_enqueue_when_shortcode_present();

		$this->assertContains( 'lp-interactive-flash-card', $enqueued );
	}

	public function test_eager_enqueue_fires_when_post_contains_single_interactive_shortcode(): void {
		Functions\when( 'is_admin' )->justReturn( false );
		Functions\when( 'has_shortcode' )->alias(
			static fn( $content, $tag ) => 'learnpress_single_interactive' === $tag
		);
		Functions\when( 'has_block' )->justReturn( false );
		Functions\when( 'apply_filters' )->returnArg( 2 );
		$GLOBALS['post'] = (object) array( 'post_content' => '[learnpress_single_interactive id="1"]' );

		$enqueued = array();
		$this->stub_handle_lookup_calls( $enqueued );

		AssetRegistrar::eager_enqueue_when_shortcode_present();

		$this->assertContains( 'lp-interactive-flash-card', $enqueued );
	}

	public function test_eager_enqueue_fires_when_post_contains_list_shortcode(): void {
		Functions\when( 'is_admin' )->justReturn( false );
		Functions\when( 'has_shortcode' )->alias(
			static fn( $content, $tag ) => 'learnpress_interactives' === $tag
		);
		Functions\when( 'has_block' )->justReturn( false );
		Functions\when( 'apply_filters' )->returnArg( 2 );
		$GLOBALS['post'] = (object) array( 'post_content' => '[learnpress_interactives]' );

		$enqueued = array();
		$this->stub_handle_lookup_calls( $enqueued );

		AssetRegistrar::eager_enqueue_when_shortcode_present();

		$this->assertContains( 'lp-interactive-flash-card', $enqueued );
	}

	public function test_eager_enqueue_fires_when_post_contains_flashcard_block(): void {
		Functions\when( 'is_admin' )->justReturn( false );
		Functions\when( 'has_shortcode' )->justReturn( false );
		Functions\when( 'has_block' )->justReturn( true );
		Functions\when( 'apply_filters' )->returnArg( 2 );
		$GLOBALS['post'] = (object) array( 'post_content' => '<!-- wp:learnpress/flashcard {"id":1} /-->' );

		$enqueued = array();
		$this->stub_handle_lookup_calls( $enqueued );

		AssetRegistrar::eager_enqueue_when_shortcode_present();

		$this->assertContains( 'lp-interactive-flash-card', $enqueued );
	}

	public function test_eager_enqueue_filter_can_force_disable(): void {
		Functions\when( 'is_admin' )->justReturn( false );
		Functions\when( 'has_shortcode' )->justReturn( true );
		Functions\when( 'has_block' )->justReturn( true );
		// Filter forces the decision to false regardless of detected content.
		Functions\when( 'apply_filters' )->alias(
			static function ( $hook, $should ) {
				if ( 'learn-press-interactive/assets/eager-enqueue' === $hook ) {
					return false;
				}
				return $should;
			}
		);
		$GLOBALS['post'] = (object) array( 'post_content' => '[learnpress_single_interactive id=1]' );

		$enqueued = array();
		$this->stub_handle_lookup_calls( $enqueued );

		AssetRegistrar::eager_enqueue_when_shortcode_present();

		$this->assertSame( array(), $enqueued, 'filter must be able to veto enqueue' );
	}

	public function test_eager_enqueue_filter_can_force_enable_even_without_match(): void {
		Functions\when( 'is_admin' )->justReturn( false );
		Functions\when( 'has_shortcode' )->justReturn( false );
		Functions\when( 'has_block' )->justReturn( false );
		Functions\when( 'apply_filters' )->alias(
			static function ( $hook, $should ) {
				if ( 'learn-press-interactive/assets/eager-enqueue' === $hook ) {
					return true;
				}
				return $should;
			}
		);
		$GLOBALS['post'] = (object) array( 'post_content' => 'nothing here' );

		$enqueued = array();
		$this->stub_handle_lookup_calls( $enqueued );

		AssetRegistrar::eager_enqueue_when_shortcode_present();

		$this->assertContains( 'lp-interactive-flash-card', $enqueued, 'filter must be able to force enqueue' );
	}
}
