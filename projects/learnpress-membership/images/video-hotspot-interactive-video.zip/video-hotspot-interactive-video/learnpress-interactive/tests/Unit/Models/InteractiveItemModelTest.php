<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Models;

use Brain\Monkey\Functions;
use LearnPress\Interactive\Models\InteractiveItemModel;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use Mockery;

/**
 * @covers \LearnPress\Interactive\Models\InteractiveItemModel
 */
class InteractiveItemModelTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();

		Functions\when( 'wp_json_encode' )->alias(
			static fn( $data, $flags = 0 ) => json_encode( $data, (int) $flags )
		);

		$wpdb            = Mockery::mock();
		$wpdb->prefix    = 'wp_';
		$wpdb->insert_id = 0;
		$GLOBALS['wpdb'] = $wpdb;
	}

	public function test_construct_populates_and_casts_int_keys(): void {
		$model = new InteractiveItemModel(
			(object) [
				'ID'             => '12',
				'interactive_id' => '5',
				'content'        => '<p>Body</p>',
				'sort_order'     => '2',
				'extra_data'     => '{"title":"Q1"}',
			]
		);

		$this->assertSame( 12, $model->ID );
		$this->assertSame( 5, $model->interactive_id );
		$this->assertSame( 2, $model->sort_order );
		$this->assertSame( '<p>Body</p>', $model->content );
		$this->assertSame( [ 'title' => 'Q1' ], $model->extra_data );
	}

	public function test_save_inserts_new_item(): void {
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'insert' )
			->once()
			->with(
				'wp_learnpress_interactive_items',
				Mockery::on(
					static function ( $row ) {
						return 5 === $row['interactive_id']
							&& '<p>A</p>' === $row['content']
							&& 0 === $row['sort_order']
							&& '{"title":"Q"}' === $row['extra_data'];
					}
				)
			)
			->andReturn( true );
		$wpdb->insert_id = 100;

		$model                 = new InteractiveItemModel();
		$model->interactive_id = 5;
		$model->content        = '<p>A</p>';
		$model->sort_order     = 0;
		$model->extra_data     = [ 'title' => 'Q' ];

		$this->assertSame( 100, $model->save() );
	}

	public function test_save_updates_when_id_positive(): void {
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldNotReceive( 'insert' );
		$wpdb->shouldReceive( 'update' )
			->once()
			->with( 'wp_learnpress_interactive_items', Mockery::any(), [ 'ID' => 11 ] )
			->andReturn( 1 );

		$model     = new InteractiveItemModel();
		$model->ID = 11;

		$this->assertSame( 11, $model->save() );
	}

	public function test_delete_by_parent_calls_wpdb_delete_with_correct_where(): void {
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'delete' )
			->once()
			->with( 'wp_learnpress_interactive_items', [ 'interactive_id' => 8 ] )
			->andReturn( 3 );

		$this->assertSame( 3, InteractiveItemModel::delete_by_parent( 8 ) );
	}

	public function test_delete_by_parent_returns_zero_when_id_zero(): void {
		$this->assertSame( 0, InteractiveItemModel::delete_by_parent( 0 ) );
	}

	public function test_bulk_replace_wraps_in_transaction_and_inserts_with_sort_order_index(): void {
		$wpdb = $GLOBALS['wpdb'];

		$queries = [];
		$wpdb->shouldReceive( 'query' )->andReturnUsing(
			static function ( $sql ) use ( &$queries ) {
				$queries[] = $sql;
				return true;
			}
		);
		$wpdb->shouldReceive( 'delete' )
			->once()
			->with( 'wp_learnpress_interactive_items', [ 'interactive_id' => 5 ] )
			->andReturn( 0 );

		$inserted = [];
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( &$inserted ) {
				$inserted[]      = $row;
				$GLOBALS['wpdb']->insert_id = count( $inserted );
				return true;
			}
		);

		$ok = InteractiveItemModel::bulk_replace(
			5,
			[
				[ 'content' => 'A', 'extra_data' => [ 'title' => 'Q1' ] ],
				[ 'content' => 'B', 'extra_data' => [ 'title' => 'Q2' ] ],
			]
		);

		$this->assertTrue( $ok );
		$this->assertSame( [ 'START TRANSACTION', 'COMMIT' ], $queries );
		$this->assertCount( 2, $inserted );
		$this->assertSame( 0, $inserted[0]['sort_order'] );
		$this->assertSame( 1, $inserted[1]['sort_order'] );
		$this->assertSame( 5, $inserted[0]['interactive_id'] );
		$this->assertSame( 'A', $inserted[0]['content'] );
	}

	public function test_bulk_replace_rolls_back_on_insert_failure(): void {
		$wpdb = $GLOBALS['wpdb'];

		$queries = [];
		$wpdb->shouldReceive( 'query' )->andReturnUsing(
			static function ( $sql ) use ( &$queries ) {
				$queries[] = $sql;
				return true;
			}
		);
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );
		$wpdb->shouldReceive( 'insert' )->andReturn( false ); // Simulate insert failure.

		$ok = InteractiveItemModel::bulk_replace(
			5,
			[ [ 'content' => 'X', 'extra_data' => [] ] ]
		);

		$this->assertFalse( $ok );
		$this->assertContains( 'ROLLBACK', $queries );
		$this->assertNotContains( 'COMMIT', $queries );
	}

	public function test_bulk_replace_returns_false_when_parent_id_zero(): void {
		$this->assertFalse( InteractiveItemModel::bulk_replace( 0, [] ) );
	}

	// count_by_parent_ids

	public function test_count_by_parent_ids_returns_empty_map_for_empty_input(): void {
		$this->assertSame( array(), InteractiveItemModel::count_by_parent_ids( array() ) );
	}

	public function test_count_by_parent_ids_returns_zero_for_unknown_parents(): void {
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'prepare' )->andReturn( 'SELECT_STUB' );
		$wpdb->shouldReceive( 'get_results' )->andReturn( array() );

		$counts = InteractiveItemModel::count_by_parent_ids( array( 7, 8, 9 ) );

		$this->assertSame( array( 7 => 0, 8 => 0, 9 => 0 ), $counts );
	}

	public function test_count_by_parent_ids_fills_counts_and_keeps_zeroes(): void {
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'prepare' )->andReturn( 'SELECT_STUB' );
		$wpdb->shouldReceive( 'get_results' )->andReturn(
			array(
				(object) array( 'interactive_id' => 1, 'cnt' => 3 ),
				(object) array( 'interactive_id' => 3, 'cnt' => 5 ),
			)
		);

		$counts = InteractiveItemModel::count_by_parent_ids( array( 1, 2, 3 ) );

		$this->assertSame( 3, $counts[1] );
		$this->assertSame( 0, $counts[2], 'Parents with no items keep zero count' );
		$this->assertSame( 5, $counts[3] );
	}

	public function test_count_by_parent_ids_filters_non_positive_and_dupes(): void {
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'prepare' )->andReturn( 'SELECT_STUB' );
		$wpdb->shouldReceive( 'get_results' )->andReturn( array() );

		$counts = InteractiveItemModel::count_by_parent_ids( array( 0, -1, 4, 4, '5' ) );

		$this->assertSame( array( 4 => 0, 5 => 0 ), $counts );
	}

	// find_by_parent_ids

	public function test_find_by_parent_ids_returns_empty_map_for_empty_input(): void {
		$this->assertSame( array(), InteractiveItemModel::find_by_parent_ids( array() ) );
	}

	public function test_find_by_parent_ids_groups_models_by_parent_and_preserves_order(): void {
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'prepare' )->andReturn( 'SELECT_STUB' );
		$wpdb->shouldReceive( 'get_results' )->andReturn(
			array(
				(object) array( 'ID' => 11, 'interactive_id' => 1, 'content' => 'A', 'sort_order' => 1, 'extra_data' => '' ),
				(object) array( 'ID' => 12, 'interactive_id' => 1, 'content' => 'B', 'sort_order' => 2, 'extra_data' => '' ),
				(object) array( 'ID' => 21, 'interactive_id' => 2, 'content' => 'C', 'sort_order' => 1, 'extra_data' => '' ),
			)
		);

		$map = InteractiveItemModel::find_by_parent_ids( array( 1, 2, 3 ) );

		$this->assertCount( 2, $map[1] );
		$this->assertSame( 'A', $map[1][0]->content );
		$this->assertSame( 'B', $map[1][1]->content );
		$this->assertCount( 1, $map[2] );
		$this->assertSame( 'C', $map[2][0]->content );
		$this->assertSame( array(), $map[3], 'Parent with no rows stays empty array' );
	}

	public function test_find_by_parent_ids_handles_array_rows_too(): void {
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'prepare' )->andReturn( 'SELECT_STUB' );
		$wpdb->shouldReceive( 'get_results' )->andReturn(
			array(
				array( 'ID' => 99, 'interactive_id' => 7, 'content' => 'Z', 'sort_order' => 1, 'extra_data' => '' ),
			)
		);

		$map = InteractiveItemModel::find_by_parent_ids( array( 7 ) );

		$this->assertCount( 1, $map[7] );
		$this->assertSame( 99, $map[7][0]->ID );
	}

	public function test_find_by_parent_ids_decodes_extra_data_json_from_db(): void {
		// DB returns extra_data as raw JSON string (longtext column). The model
		// must hydrate it back into an array via map_to_object().
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'prepare' )->andReturn( 'SELECT_STUB' );
		$wpdb->shouldReceive( 'get_results' )->andReturn(
			array(
				(object) array(
					'ID'             => 1,
					'interactive_id' => 5,
					'content'        => 'body',
					'sort_order'     => 1,
					'extra_data'     => '{"theme":"dark","badge":42}',
				),
			)
		);

		$map = InteractiveItemModel::find_by_parent_ids( array( 5 ) );

		$this->assertIsArray( $map[5][0]->extra_data );
		$this->assertSame( 'dark', $map[5][0]->extra_data['theme'] );
		$this->assertSame( 42, $map[5][0]->extra_data['badge'] );
	}

	public function test_find_by_parent_ids_preserves_vietnamese_unicode_in_extra_data(): void {
		// JSON_UNESCAPED_UNICODE on the write side stores literal UTF-8 bytes
		// (e.g. 'à', 'ạ', 'ấ'). Decoded payload must come back byte-identical.
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'prepare' )->andReturn( 'SELECT_STUB' );
		$wpdb->shouldReceive( 'get_results' )->andReturn(
			array(
				(object) array(
					'ID'             => 1,
					'interactive_id' => 9,
					'content'        => '',
					'sort_order'     => 1,
					'extra_data'     => '{"note":"Chào bạn — đây là thẻ flashcard tiếng Việt"}',
				),
			)
		);

		$map = InteractiveItemModel::find_by_parent_ids( array( 9 ) );

		$this->assertSame(
			'Chào bạn — đây là thẻ flashcard tiếng Việt',
			$map[9][0]->extra_data['note']
		);
	}

	public function test_find_by_parent_ids_falls_back_to_empty_array_on_malformed_json(): void {
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'prepare' )->andReturn( 'SELECT_STUB' );
		$wpdb->shouldReceive( 'get_results' )->andReturn(
			array(
				(object) array(
					'ID'             => 1,
					'interactive_id' => 2,
					'content'        => '',
					'sort_order'     => 1,
					'extra_data'     => '{not valid json',
				),
			)
		);

		$map = InteractiveItemModel::find_by_parent_ids( array( 2 ) );

		$this->assertSame( array(), $map[2][0]->extra_data, 'Bad JSON must not break the request' );
	}
}
