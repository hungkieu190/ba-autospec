<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Types;

use Brain\Monkey\Functions;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use LearnPress\Interactive\Types\SlideType;
use LearnPress\Interactive\Types\TypeInterface;

/**
 * @covers \LearnPress\Interactive\Types\SlideType
 */
class SlideTypeTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();

		Functions\when( 'wp_json_encode' )->alias(
			static fn( $data, $flags = 0 ) => json_encode( $data, $flags )
		);
		Functions\when( 'esc_url_raw' )->alias(
			static fn( $url ) => filter_var( (string) $url, FILTER_SANITIZE_URL )
		);
	}

	public function test_implements_interface_and_key_is_slide(): void {
		$t = new SlideType();
		$this->assertInstanceOf( TypeInterface::class, $t );
		$this->assertSame( 'slide', $t->key() );
		$this->assertSame( 'Slide', $t->label() );
	}

	public function test_default_settings_returns_empty_parent_extra_data(): void {
		$this->assertSame( array(), ( new SlideType() )->default_settings() );
	}

	public function test_default_title_returns_slide_fallback_title(): void {
		$this->assertSame( 'Untitled deck', ( new SlideType() )->default_title() );
	}

	public function test_sanitize_settings_keeps_parent_extra_data_empty(): void {
		$this->assertSame(
			array(),
			( new SlideType() )->sanitize_settings(
				array(
					'title'         => 'Deck title',
					'canvas_width'  => 1200,
					'canvas_height' => 720,
					'width'         => 1200,
					'height'        => 720,
				)
			)
		);
	}

	public function test_sanitize_item_stores_fabric_json_and_dimensions_in_item_extra_data(): void {
		$clean = ( new SlideType() )->sanitize_item(
			array(
				'width'   => 1200,
				'height'  => 720,
				'content' => array(
					'version' => '6.0.0',
					'objects' => array(
						array(
							'type' => 'textbox',
							'text' => 'Hello',
							'left' => 100,
							'top'  => 80,
						),
					),
				),
			)
		);

		$fabric = $this->decode_fabric_content( $clean['content'] );

		$this->assertIsArray( $fabric );
		$this->assertSame( '6.0.0', $fabric['version'] );
		$this->assertSame( 'textbox', $fabric['objects'][0]['type'] );
		$this->assertSame( 'Hello', $fabric['objects'][0]['text'] );
		$this->assertSame( 100, $fabric['objects'][0]['left'] );
		$this->assertSame(
			array(
				'width'  => 1200,
				'height' => 720,
			),
			$clean['extra_data']
		);
	}

	public function test_sanitize_item_accepts_legacy_canvas_dimension_keys(): void {
		$clean = ( new SlideType() )->sanitize_item(
			array(
				'canvas_width'  => 50,
				'canvas_height' => 9999,
				'content'       => array(),
			)
		);

		$this->assertSame(
			array(
				'width'  => 320,
				'height' => 1080,
			),
			$clean['extra_data']
		);
	}

	public function test_sanitize_item_keeps_background_out_of_item_extra_data(): void {
		$clean = ( new SlideType() )->sanitize_item(
			array(
				'background' => 'https://example.test/uploads/bg.jpg',
				'content'    => array(),
			)
		);

		$this->assertArrayNotHasKey( 'background', $clean['extra_data'] );
	}

	public function test_sanitize_item_strips_all_html_from_fabric_string_values(): void {
		$clean = ( new SlideType() )->sanitize_item(
			array(
				'background' => '#fff',
				'content'    => array(
					'version' => '6.0.0<script>alert(1)</script>',
					'objects' => array(
						array(
							'type' => 'textbox',
							'text' => '<b>Bold</b><script>alert(1)</script>',
							'left' => '20',
						),
						'bad row',
					),
				),
			)
		);

		$fabric = $this->decode_fabric_content( $clean['content'] );

		$this->assertStringNotContainsString( '<script>', $fabric['version'] );
		$this->assertStringNotContainsString( '<', $fabric['version'] );
		$this->assertCount( 1, $fabric['objects'] );
		$this->assertSame( 'Boldalert(1)', $fabric['objects'][0]['text'] );
		$this->assertSame( 20, $fabric['objects'][0]['left'] );
	}

	public function test_sanitize_item_preserves_null_fabric_values(): void {
		$clean = ( new SlideType() )->sanitize_item(
			array(
				'content' => array(
					'objects' => array(
						array(
							'type'   => 'rect',
							'stroke' => null,
							'shadow' => null,
						),
					),
				),
			)
		);

		$fabric = $this->decode_fabric_content( $clean['content'] );

		$this->assertArrayHasKey( 'stroke', $fabric['objects'][0] );
		$this->assertNull( $fabric['objects'][0]['stroke'] );
		$this->assertArrayHasKey( 'shadow', $fabric['objects'][0] );
		$this->assertNull( $fabric['objects'][0]['shadow'] );
	}

	public function test_render_returns_safe_placeholder_until_frontend_player_exists(): void {
		$html = ( new SlideType() )->render(
			array(),
			array(
				array(
					'content'    => '{"version":"","objects":[]}',
					'extra_data' => array(
						'width'  => 842,
						'height' => 595,
					),
				),
			)
		);

		$this->assertStringContainsString( 'lp-interactive-slide-deck-placeholder', $html );
		$this->assertStringContainsString( 'Slide deck', $html );
	}

	public function test_frontend_handles_returns_empty_until_slide_player_bundle_exists(): void {
		$this->assertSame( array(), ( new SlideType() )->frontend_handles() );
	}

	private function decode_fabric_content( $content ): array {
		$this->assertIsString( $content, 'Slide item content must store Fabric JSON as a string.' );

		$decoded = json_decode( $content, true );
		$this->assertIsArray( $decoded, 'Slide item content must be valid JSON.' );

		return $decoded;
	}
}
