<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Admin;

use LearnPress\Interactive\Admin\AdminInteractiveListPage;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use LearnPress\Interactive\Tests\Helpers\FakeServiceType;
use LearnPress\Interactive\Types\TypeRegistry;

/**
 * @covers \LearnPress\Interactive\Admin\AdminInteractiveListPage
 */
class AdminInteractiveListPageTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();
		TypeRegistry::reset_for_tests();
		TypeRegistry::register( new FakeServiceType() );
	}

	private function render(): string {
		ob_start();
		( new AdminInteractiveListPage() )->render();
		return (string) ob_get_clean();
	}

	public function test_renders_main_wrapper_with_nonce_and_ajax_action(): void {
		$output = $this->render();

		$this->assertStringContainsString( 'lp-interactive-list-wrap', $output );
		$this->assertStringContainsString( 'data-nonce="test-nonce"', $output );
		$this->assertStringContainsString( 'data-ajax-action="lp_interactive_list"', $output );
	}

	public function test_renders_wp_header_anchor_for_notice_relocation(): void {
		$output = $this->render();

		$this->assertStringContainsString( 'wp-heading-inline', $output );
		$this->assertStringContainsString( 'wp-header-end', $output );
	}

	public function test_wraps_in_host_scope_for_plugin_owned_css(): void {
		$output = $this->render();

		$this->assertStringContainsString( 'lp-interactive-cb-host', $output );
	}

	public function test_renders_cb_tab_header_with_title_and_add_new(): void {
		$output = $this->render();

		$this->assertStringContainsString( 'cb-tab-header', $output );
		$this->assertStringContainsString( 'cb-tab-header-actions', $output );
		$this->assertStringContainsString( 'lp-cb-tab__title', $output );
		$this->assertStringContainsString( 'Add New', $output );
		$this->assertStringContainsString( '&action=new', $output );
		$this->assertStringContainsString( 'lp-cb-btn-add-new', $output );
	}

	public function test_does_not_render_inline_styles(): void {
		$output = $this->render();

		$this->assertStringNotContainsString( ' style=', $output );
	}

	public function test_renders_cb_filter_bar_with_search_status_type_per_page(): void {
		$output = $this->render();

		$this->assertStringContainsString( 'cb-tab-filter-bar', $output );
		$this->assertStringContainsString( 'cb-filter-fields', $output );
		$this->assertStringContainsString( 'cb-filter-group', $output );
		$this->assertStringContainsString( 'cb-filter-search', $output );
		$this->assertStringContainsString( 'cb-filter-select', $output );
		$this->assertStringContainsString( 'cb-filter-actions', $output );
		$this->assertStringContainsString( 'cb-filter-btn', $output );
		$this->assertStringContainsString( 'cb-filter-reset', $output );

		$this->assertStringContainsString( 'name="c_search"', $output );
		$this->assertStringContainsString( 'name="c_status"', $output );
		$this->assertStringContainsString( 'name="c_type"', $output );
		$this->assertStringContainsString( 'name="per_page"', $output );
	}

	public function test_renders_cb_list_table_header_with_columns(): void {
		$output = $this->render();

		$this->assertStringContainsString( 'cb-list-table-header', $output );
		foreach ( array( 'Title', 'Type', 'Shortcode', 'Author', 'Date', 'Status', 'Actions' ) as $label ) {
			$this->assertStringContainsString(
				$label,
				$output,
				"Column header '$label' must be present"
			);
		}
	}

	public function test_renders_cb_list_interactive_ul_with_loading_placeholder(): void {
		$output = $this->render();

		$this->assertStringContainsString( 'cb-list-question', $output );
		$this->assertStringContainsString( 'lp-interactive-list__body', $output );
		$this->assertStringContainsString( 'cb-list-loading', $output );
		$this->assertStringContainsString( 'Loading', $output );
	}

	public function test_renders_pagination_container_for_js_to_fill(): void {
		$output = $this->render();

		$this->assertStringContainsString( 'lp-interactive-pagination', $output );
	}
}
