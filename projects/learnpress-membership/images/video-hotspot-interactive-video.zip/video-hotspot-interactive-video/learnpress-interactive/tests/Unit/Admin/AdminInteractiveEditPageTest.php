<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Admin;

use Brain\Monkey\Functions;
use LearnPress\Interactive\Admin\AdminInteractiveEditPage;
use LearnPress\Interactive\Databases\InteractiveDB;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use LearnPress\Interactive\Tests\Helpers\FakeServiceType;
use LearnPress\Interactive\Types\TypeRegistry;
use Mockery;
use ReflectionClass;

/**
 * @covers \LearnPress\Interactive\Admin\AdminInteractiveEditPage
 */
class AdminInteractiveEditPageTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();

		TypeRegistry::reset_for_tests();
		TypeRegistry::register( new FakeServiceType() );
		$this->reset_interactive_db_singleton();

		$wpdb            = Mockery::mock();
		$wpdb->prefix    = 'wp_';
		$wpdb->insert_id = 0;
		$GLOBALS['wpdb'] = $wpdb;
	}

	private function reset_interactive_db_singleton(): void {
		$ref  = new ReflectionClass( InteractiveDB::class );
		$prop = $ref->getProperty( '_instance' );
		$prop->setAccessible( true );
		$prop->setValue( null, null );
	}

	private function inject_db_returning( array $rows, array $items = array() ): void {
		$db = Mockery::mock( InteractiveDB::class );
		$db->shouldReceive( 'get_interactives' )->andReturn( $rows );
		$db->shouldReceive( 'get_interactive_items' )->andReturn( $items );

		$ref  = new ReflectionClass( InteractiveDB::class );
		$prop = $ref->getProperty( '_instance' );
		$prop->setAccessible( true );
		$prop->setValue( null, $db );
	}

	public function test_renders_create_form_when_no_id(): void {
		$_GET = array();

		ob_start();
		( new AdminInteractiveEditPage() )->render();
		$output = ob_get_clean();

		$this->assertStringContainsString( 'lp-interactive-create', $output );
		$this->assertStringContainsString( 'Create New Interactive', $output );
		$this->assertStringContainsString( 'name="title"', $output );
		$this->assertStringContainsString( 'name="type"', $output );
		// Plan §346 — create form must include the nonce field so JS can POST it.
		$this->assertStringContainsString( 'name="_lp_interactive_nonce"', $output );
	}

	public function test_renders_not_found_when_id_does_not_exist(): void {
		$_GET = array( 'id' => 999 );
		$this->inject_db_returning( array() );

		ob_start();
		( new AdminInteractiveEditPage() )->render();
		$output = ob_get_clean();

		$this->assertStringContainsString( 'Not Found', $output );
		$this->assertStringContainsString( 'Back to list', $output );
	}

	public function test_renders_editor_with_bootstrap_data_for_existing_entity(): void {
		$row = (object) array(
			'ID'         => 5,
			'title'      => 'Learn programming',
			'type'       => 'fake',
			'status'     => 'publish',
			'extra_data' => '{"flag":true}',
			'author'     => 1,
			'created_at' => '2026-05-06 10:00:00',
			'updated_at' => '2026-05-06 10:00:00',
		);
		$this->inject_db_returning( array( $row ), array() );
		$_GET = array( 'id' => 5 );

		ob_start();
		( new AdminInteractiveEditPage() )->render();
		$output = ob_get_clean();

		// Editor wrapper present.
		$this->assertStringContainsString( 'lp-interactive-builder', $output );

		// Bootstrap JSON present.
		$this->assertStringContainsString( 'data-bootstrap=', $output );
		// Title round-trips literally in data-bootstrap, while esc_attr converts " to &quot;.
		// We check the title text is in the encoded attribute value.
		$this->assertStringContainsString( 'Learn programming', $output );

		// Shortcode displayed.
		$this->assertStringContainsString( '[learnpress_single_interactive id=5]', $output );

		// New DS v2 shell: title card + editor card + head strip + tabs + panels.
		$this->assertStringContainsString( 'lp-interactive-builder__title-card', $output );
		$this->assertStringContainsString( 'lp-interactive-builder__editor', $output );
		$this->assertStringContainsString( 'lp-interactive-builder__editor-head', $output );
		$this->assertStringContainsString( 'lp-interactive-builder__tabs', $output );
		$this->assertStringContainsString( 'lp-interactive-builder__panel--cards', $output );
		$this->assertStringContainsString( 'lp-interactive-builder__panel--settings', $output );
		$this->assertStringContainsString( 'lp-interactive-builder__panel--preview', $output );

		// Status pill reflects current status.
		$this->assertStringContainsString( 'lp-interactive-builder__status-pill--publish', $output );
		$this->assertStringContainsString( 'data-status="publish"', $output );

		// Kebab menu with Move to Trash entry present.
		$this->assertStringContainsString( 'lp-interactive-builder__kebab', $output );
		$this->assertStringContainsString( 'lp-interactive-builder__trash', $output );

		// LP Core notices placeholder is omitted from the editor shell.
		// $this->assertStringNotContainsString( 'class="lp-admin-notices notice"', $output );

		// Items + settings containers present.
		$this->assertStringContainsString( 'lp-interactive-items', $output );
		$this->assertStringContainsString( 'lp-interactive-settings', $output );

		// Old WP postbox chrome MUST be gone.
		$this->assertStringNotContainsString( 'id="poststuff"', $output );
		$this->assertStringNotContainsString( 'id="submitdiv"', $output );
		$this->assertStringNotContainsString( 'metabox-holder', $output );
		$this->assertStringNotContainsString( 'misc-pub-section', $output );
	}

	public function test_editor_does_not_render_inline_script(): void {
		$row = (object) array(
			'ID'         => 5,
			'title'      => 'No inline script',
			'type'       => 'fake',
			'status'     => 'publish',
			'extra_data' => '{}',
			'author'     => 1,
			'created_at' => '2026-05-06 10:00:00',
			'updated_at' => '2026-05-06 10:00:00',
		);
		$this->inject_db_returning( array( $row ), array() );
		$_GET = array( 'id' => 5 );

		ob_start();
		( new AdminInteractiveEditPage() )->render();
		$output = ob_get_clean();

		// Inline icon <svg> markup is allowed, but NO <script> tags.
		$this->assertStringNotContainsString( '<script', $output );
		$this->assertStringNotContainsString( 'add_postbox_toggles', $output );
	}

	public function test_renders_not_found_when_type_unknown(): void {
		$row = (object) array(
			'ID'         => 5,
			'title'      => 'X',
			'type'       => 'nonexistent_type',  // not registered → not_found
			'status'     => 'publish',
			'extra_data' => '{}',
			'author'     => 1,
		);
		$this->inject_db_returning( array( $row ), array() );
		$_GET = array( 'id' => 5 );

		ob_start();
		( new AdminInteractiveEditPage() )->render();
		$output = ob_get_clean();

		$this->assertStringContainsString( 'Not Found', $output );
	}

	/**
	 * Short-circuit wp_safe_redirect by throwing an exception with the URL
	 * so we can assert the redirect target without running real redirects.
	 */
	private function setup_redirect_capture(): void {
		Functions\when( 'wp_safe_redirect' )->alias(
			static function ( $url ) {
				throw new \RuntimeException( '__REDIRECT__' . $url );
			}
		);
		Functions\when( 'add_query_arg' )->alias(
			static function ( $args, $url = '' ) {
				$base = is_string( $url ) ? $url : '';
				return $base . '?' . http_build_query( is_array( $args ) ? $args : array() );
			}
		);
		Functions\when( 'current_user_can' )->justReturn( true );
		Functions\when( 'check_admin_referer' )->justReturn( true );
		Functions\when( 'current_time' )->justReturn( '2026-05-12 12:00:00' );
		Functions\when( 'wp_json_encode' )->alias(
			static fn( $data, $flags = 0 ) => json_encode( $data, (int) $flags )
		);
		Functions\when( 'get_current_user_id' )->justReturn( 1 );
	}

	private function capture_redirect( callable $action ): string {
		try {
			$action();
		} catch ( \RuntimeException $e ) {
			$msg = $e->getMessage();
			if ( 0 === strpos( $msg, '__REDIRECT__' ) ) {
				return substr( $msg, strlen( '__REDIRECT__' ) );
			}
		}
		return '';
	}

	public function test_form_save_trash_redirects_to_list_with_trashed_flag(): void {
		$this->setup_redirect_capture();

		$row = (object) array(
			'ID'         => 5,
			'title'      => 'A',
			'type'       => 'fake',
			'status'     => 'publish',
			'extra_data' => '{}',
			'author'     => 1,
		);
		$this->inject_db_returning( array( $row ) );

		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'update' )->andReturn( 1 );

		$_POST = array( 'id' => 5, 'submit_trash' => '1' );

		$url = $this->capture_redirect(
			static fn() => AdminInteractiveEditPage::handle_form_save()
		);

		$this->assertStringContainsString( 'trashed=1', $url );
		$this->assertStringNotContainsString( 'action=edit', $url );
	}

	public function test_form_save_success_redirects_to_edit_with_message_1(): void {
		$this->setup_redirect_capture();

		$row = (object) array(
			'ID'         => 5,
			'title'      => 'A',
			'type'       => 'fake',
			'status'     => 'publish',
			'extra_data' => '{}',
			'author'     => 1,
		);
		$this->inject_db_returning( array( $row ) );

		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'update' )->andReturn( 1 );

		$_POST = array( 'id' => 5, 'title' => 'Renamed' );

		$url = $this->capture_redirect(
			static fn() => AdminInteractiveEditPage::handle_form_save()
		);

		$this->assertStringContainsString( 'action=edit', $url );
		$this->assertStringContainsString( 'id=5', $url );
		$this->assertStringContainsString( 'message=1', $url );
	}

	public function test_form_save_failure_redirects_with_message_0(): void {
		$this->setup_redirect_capture();

		$this->inject_db_returning( array() );

		$_POST = array( 'id' => 5, 'title' => 'X' );

		$wp_die_called = false;
		Functions\when( 'wp_die' )->alias(
			static function ( $msg = '', $title = '', $args = array() ) use ( &$wp_die_called ) {
				$wp_die_called = true;
				throw new \RuntimeException( '__WPDIE__' );
			}
		);

		try {
			AdminInteractiveEditPage::handle_form_save();
		} catch ( \RuntimeException $e ) {
			// expected — wp_die or redirect.
		}

		$this->assertTrue( $wp_die_called, 'Missing entry should trigger wp_die for not-found' );
	}

	public function test_form_save_missing_id_calls_wp_die(): void {
		Functions\when( 'current_user_can' )->justReturn( true );

		$called = false;
		Functions\when( 'wp_die' )->alias(
			static function ( $msg = '', $title = '', $args = array() ) use ( &$called ) {
				$called = true;
				throw new \RuntimeException( '__WPDIE__' );
			}
		);

		$_POST = array(); // no id

		try {
			AdminInteractiveEditPage::handle_form_save();
		} catch ( \RuntimeException $e ) {
			// expected
		}

		$this->assertTrue( $called );
	}

	public function test_form_save_without_capability_calls_wp_die(): void {
		Functions\when( 'current_user_can' )->justReturn( false );

		$called = false;
		Functions\when( 'wp_die' )->alias(
			static function ( $msg = '', $title = '', $args = array() ) use ( &$called ) {
				$called = true;
				throw new \RuntimeException( '__WPDIE__' );
			}
		);

		$_POST = array( 'id' => 5 );

		try {
			AdminInteractiveEditPage::handle_form_save();
		} catch ( \RuntimeException $e ) {
			// expected
		}

		$this->assertTrue( $called );
	}

	public function test_form_save_unslashes_and_decodes_unicode_json_items(): void {
		$this->setup_redirect_capture();

		$row = (object) array(
			'ID'         => 5,
			'title'      => 'A',
			'type'       => 'fake',
			'status'     => 'publish',
			'extra_data' => '{}',
			'author'     => 1,
		);
		$this->inject_db_returning( array( $row ) );

		$inserted_rows = array();
		$wpdb          = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'update' )->andReturn( 1 );
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$inserted_rows ) {
				$inserted_rows[ $table ][] = $row;
				$wpdb->insert_id           = count( $inserted_rows[ $table ] );
				return true;
			}
		);
		Functions\when( '_doing_it_wrong' )->justReturn( null );

		$expected_chr = "\u{00e0}";

		$_POST = array(
			'id'    => 5,
			'items' => addslashes( '[{"content":"' . $expected_chr . '"}]' ),
		);

		$url = $this->capture_redirect(
			static fn() => AdminInteractiveEditPage::handle_form_save()
		);

		$this->assertStringContainsString( 'message=1', $url );
		$this->assertArrayHasKey( 'wp_learnpress_interactive_items', $inserted_rows );
		$this->assertSame(
			$expected_chr,
			$inserted_rows['wp_learnpress_interactive_items'][0]['content'],
			'Literal UTF-8 JSON must round-trip through wp_magic_quotes + wp_unslash + json_decode'
		);

		$inserted_rows = array();
		$_POST         = array(
			'id'    => 5,
			'items' => addslashes( '[{"content":"\\u00e0"}]' ),
		);

		$this->capture_redirect( static fn() => AdminInteractiveEditPage::handle_form_save() );

		$this->assertSame(
			$expected_chr,
			$inserted_rows['wp_learnpress_interactive_items'][0]['content'],
			'Escaped \\u00e0 JSON must also decode to U+00E0 after wp_unslash'
		);
	}

	private function render_editor_html_for_existing_record(): string {
		$row = (object) array(
			'ID'         => 7,
			'title'      => 'Three tab fixture',
			'type'       => 'fake',
			'status'     => 'publish',
			'extra_data' => '{}',
			'author'     => 1,
			'created_at' => '2026-05-19 09:00:00',
			'updated_at' => '2026-05-19 09:00:00',
		);
		$this->inject_db_returning( array( $row ), array() );
		$_GET = array( 'id' => 7 );

		ob_start();
		( new AdminInteractiveEditPage() )->render();
		return (string) ob_get_clean();
	}

	public function test_render_editor_emits_three_tab_bar(): void {
		$html = $this->render_editor_html_for_existing_record();

		$this->assertStringContainsString( 'lp-interactive-builder__tabs', $html );
		$this->assertStringContainsString( 'data-tab="cards"',    $html );
		$this->assertStringContainsString( 'data-tab="settings"', $html );
		$this->assertStringContainsString( 'data-tab="preview"',  $html );
	}

	public function test_render_editor_emits_three_panel_containers(): void {
		$html = $this->render_editor_html_for_existing_record();

		$this->assertStringContainsString( 'lp-interactive-builder__panel--cards',    $html );
		$this->assertStringContainsString( 'lp-interactive-builder__panel--settings', $html );
		$this->assertStringContainsString( 'lp-interactive-builder__panel--preview',  $html );
	}

	public function test_render_editor_no_longer_emits_sidebar_settings_postbox(): void {
		$html = $this->render_editor_html_for_existing_record();
		$this->assertStringNotContainsString( 'lp-interactive-builder__settings-box', $html );
	}

	public function test_renders_type_radio_segments_in_create_form(): void {
		$_GET = array();

		ob_start();
		( new AdminInteractiveEditPage() )->render();
		$output = ob_get_clean();

		$this->assertStringContainsString( 'value="fake"', $output );
		$this->assertStringContainsString( 'lp-interactive-create__segment', $output );
		$this->assertSame(
			1,
			substr_count( $output, 'class="lp-interactive-create__segment"' ),
			'Should render exactly one type segment per registered type'
		);
	}
}
