<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Admin;

use Brain\Monkey\Actions;
use Brain\Monkey\Filters;
use Brain\Monkey\Functions;
use LearnPress\Interactive\Admin\WpEditorIntegration;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;

/**
 * @covers \LearnPress\Interactive\Admin\WpEditorIntegration
 */
class WpEditorIntegrationTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();

		if ( ! defined( 'LP_ADDON_INTERACTIVE_FILE' ) ) {
			define( 'LP_ADDON_INTERACTIVE_FILE', '/tmp/learnpress-interactive/learnpress-interactive.php' );
		}
		if ( ! defined( 'LP_ADDON_INTERACTIVE_VER' ) ) {
			define( 'LP_ADDON_INTERACTIVE_VER', '1.0.0' );
		}

		Functions\when( 'plugins_url' )->alias(
			static fn( $path = '', $plugin = '' ) => 'http://example.test/wp-content/plugins/learnpress-interactive/' . ltrim( (string) $path, '/' )
		);
	}

	// register() — wires init + admin_init hooks

	public function test_register_adds_init_and_admin_init_hooks(): void {
		Actions\expectAdded( 'init' )->once();
		Actions\expectAdded( 'admin_init' )->once();

		( new WpEditorIntegration() )->register();
	}

	// register_block() — Gutenberg block registration

	public function test_register_block_noop_when_register_block_type_unavailable(): void {
		( new WpEditorIntegration() )->register_block();
		$this->assertTrue( true );
	}

	public function test_register_block_registers_learnpress_flashcard_block(): void {
		$registered = array();
		Functions\when( 'register_block_type' )->alias(
			static function ( $name, $args ) use ( &$registered ) {
				$registered[ $name ] = $args;
				return true;
			}
		);

		( new WpEditorIntegration() )->register_block();

		$this->assertArrayHasKey( 'learnpress/flashcard', $registered );
		$this->assertSame(
			0,
			$registered['learnpress/flashcard']['attributes']['id']['default'],
			'id attribute default must be 0 so empty inserts render nothing'
		);
		$this->assertIsCallable( $registered['learnpress/flashcard']['render_callback'] );
	}

	// render_block() — server-side render

	public function test_render_block_returns_empty_when_id_missing(): void {
		$this->assertSame( '', ( new WpEditorIntegration() )->render_block( array() ) );
	}

	public function test_render_block_returns_empty_when_id_is_zero(): void {
		$this->assertSame( '', ( new WpEditorIntegration() )->render_block( array( 'id' => 0 ) ) );
	}

	public function test_render_block_returns_empty_when_id_is_non_numeric_string(): void {
		$this->assertSame( '', ( new WpEditorIntegration() )->render_block( array( 'id' => 'abc' ) ) );
	}

	public function test_render_block_delegates_to_single_interactive_shortcode(): void {
		Functions\when( 'do_shortcode' )->alias(
			static fn( $sc ) => '<sc>' . $sc . '</sc>'
		);

		$out = ( new WpEditorIntegration() )->render_block( array( 'id' => 42 ) );
		$this->assertSame( '<sc>[learnpress_single_interactive id="42"]</sc>', $out );
	}

	public function test_render_block_coerces_id_through_absint(): void {
		Functions\when( 'do_shortcode' )->alias(
			static fn( $sc ) => $sc
		);

		$out = ( new WpEditorIntegration() )->render_block( array( 'id' => -5 ) );
		$this->assertStringContainsString( 'id="5"', $out );
	}

	// register_tinymce() — capability gate

	public function test_register_tinymce_skips_when_user_lacks_capability(): void {
		Functions\when( 'current_user_can' )->justReturn( false );

		Filters\expectAdded( 'mce_buttons' )->never();
		Filters\expectAdded( 'mce_external_plugins' )->never();

		( new WpEditorIntegration() )->register_tinymce();
	}

	public function test_register_tinymce_adds_mce_filters_when_user_has_cap(): void {
		Functions\when( 'current_user_can' )->justReturn( true );

		Filters\expectAdded( 'mce_buttons' )->once();
		Filters\expectAdded( 'mce_external_plugins' )->once();
		Actions\expectAdded( 'admin_enqueue_scripts' )->once();

		( new WpEditorIntegration() )->register_tinymce();
	}

	// add_mce_button() / add_mce_plugin() — TinyMCE wiring

	/**
	 * Helper: stub `get_current_screen()` to return an object that mirrors
	 * how WordPress core `WP_Screen::get()` builds the screen for a
	 * single-post-edit page — both `base` and `post_type` are set. Passing
	 * `null` for either field is supported to exercise edge cases (CLI,
	 * list screen, settings page).
	 */
	private function stub_current_screen( ?string $base, ?string $post_type = null ): void {
		if ( null === $base && null === $post_type ) {
			Functions\when( 'get_current_screen' )->justReturn( null );
			return;
		}
		$screen            = new \stdClass();
		$screen->base      = (string) ( $base ?? '' );
		$screen->post_type = (string) ( $post_type ?? '' );
		Functions\when( 'get_current_screen' )->justReturn( $screen );
	}

	public function test_add_mce_button_appends_lp_flashcard_on_default_post_edit(): void {
		$this->stub_current_screen( 'post', 'post' );

		$out = ( new WpEditorIntegration() )->add_mce_button( array( 'bold', 'italic' ) );
		$this->assertSame( array( 'bold', 'italic', 'lp_flashcard' ), $out );
	}

	public function test_add_mce_button_appends_lp_flashcard_on_lp_course_edit(): void {
		$this->stub_current_screen( 'post', 'lp_course' );

		$out = ( new WpEditorIntegration() )->add_mce_button( array() );
		$this->assertSame( array( 'lp_flashcard' ), $out );
	}

	/**
	 * Regression guard: WordPress sets `$screen->base === 'post'` on EVERY
	 * single-post-edit screen and only differentiates the CPT via
	 * `$screen->post_type`. WooCommerce product edit has base='post',
	 * post_type='product' — must NOT see the lp_flashcard button. Earlier
	 * gate that only checked `base` leaked the button to every CPT.
	 */
	public function test_add_mce_button_skips_woocommerce_product_edit_screen(): void {
		$this->stub_current_screen( 'post', 'product' );

		$out = ( new WpEditorIntegration() )->add_mce_button( array( 'bold', 'italic' ) );
		$this->assertSame( array( 'bold', 'italic' ), $out, 'base=post + post_type=product must NOT pass the gate' );
	}

	public function test_add_mce_button_skips_custom_cpt_edit_screen(): void {
		$this->stub_current_screen( 'post', 'my_custom_cpt' );

		$out = ( new WpEditorIntegration() )->add_mce_button( array( 'b' ) );
		$this->assertSame( array( 'b' ), $out );
	}

	/**
	 * Listing screen (`base = 'edit'`) has no TinyMCE instance to host the
	 * button anyway, but the gate must still refuse it — otherwise any
	 * 3p screen with `base !== 'post'` would slip through.
	 */
	public function test_add_mce_button_skips_when_not_post_edit_base(): void {
		$this->stub_current_screen( 'edit', 'post' );

		$out = ( new WpEditorIntegration() )->add_mce_button( array( 'b' ) );
		$this->assertSame( array( 'b' ), $out );
	}

	public function test_add_mce_button_skips_when_no_screen_available(): void {
		$this->stub_current_screen( null );

		$out = ( new WpEditorIntegration() )->add_mce_button( array( 'bold' ) );
		$this->assertSame( array( 'bold' ), $out, 'no screen context → no button (CLI / REST / early init)' );
	}

	public function test_add_mce_button_skips_when_post_type_missing(): void {
		$this->stub_current_screen( 'post', '' );

		$out = ( new WpEditorIntegration() )->add_mce_button( array( 'b' ) );
		$this->assertSame( array( 'b' ), $out, 'edit screen without a post_type set is ambiguous → skip' );
	}

	public function test_add_mce_plugin_registers_lp_flashcard_plugin_url(): void {
		$this->stub_current_screen( 'post', 'lp_lesson' );

		$out = ( new WpEditorIntegration() )->add_mce_plugin( array() );

		$this->assertArrayHasKey( 'lp_flashcard', $out );
		$this->assertStringContainsString( 'tinymce-plugin', $out['lp_flashcard'] );
		$this->assertStringContainsString( '.js', $out['lp_flashcard'] );
	}

	public function test_add_mce_plugin_preserves_existing_plugins(): void {
		$this->stub_current_screen( 'post', 'lp_quiz' );

		$out = ( new WpEditorIntegration() )->add_mce_plugin( array( 'wpemoji' => 'http://example.test/emoji.js' ) );

		$this->assertArrayHasKey( 'wpemoji', $out );
		$this->assertArrayHasKey( 'lp_flashcard', $out );
		$this->assertSame( 'http://example.test/emoji.js', $out['wpemoji'] );
	}

	public function test_add_mce_plugin_skips_off_whitelist_cpt(): void {
		$this->stub_current_screen( 'post', 'product' );

		$out = ( new WpEditorIntegration() )->add_mce_plugin( array( 'wpemoji' => 'http://example.test/emoji.js' ) );

		$this->assertArrayNotHasKey( 'lp_flashcard', $out );
		$this->assertArrayHasKey( 'wpemoji', $out, 'other plugins must pass through untouched' );
	}

	/**
	 * The `learn-press-interactive/wp-editor/post-types` filter lets theme / 3p
	 * code opt in additional CPTs without forking the addon.
	 */
	public function test_supported_post_types_filter_allows_opt_in_for_extra_cpt(): void {
		$this->stub_current_screen( 'post', 'my_custom_cpt' );
		Filters\expectApplied( 'learn-press-interactive/wp-editor/post-types' )
			->once()
			->andReturn( array( 'post', 'page', 'my_custom_cpt' ) );

		$out = ( new WpEditorIntegration() )->add_mce_button( array() );
		$this->assertSame( array( 'lp_flashcard' ), $out );
	}

	// -------------------------------------------------------------------------
	// enqueue_wp_editor_assets() — screen gate
	// -------------------------------------------------------------------------

	public function test_enqueue_wp_editor_assets_skips_when_screen_unavailable(): void {
		Functions\when( 'get_current_screen' )->justReturn( null );

		$enqueued = 0;
		Functions\when( 'wp_enqueue_script' )->alias(
			static function () use ( &$enqueued ) {
				$enqueued++;
			}
		);

		( new WpEditorIntegration() )->enqueue_wp_editor_assets();
		$this->assertSame( 0, $enqueued, 'must not enqueue without a current screen' );
	}

	public function test_enqueue_wp_editor_assets_skips_on_non_post_screens(): void {
		$this->stub_current_screen( 'edit', 'post' );

		$enqueued = 0;
		Functions\when( 'wp_enqueue_script' )->alias(
			static function () use ( &$enqueued ) {
				$enqueued++;
			}
		);

		( new WpEditorIntegration() )->enqueue_wp_editor_assets();
		$this->assertSame( 0, $enqueued, 'must not enqueue on edit.php (list) screen' );
	}

	/**
	 * Regression guard mirroring `test_add_mce_button_skips_woocommerce_product_edit_screen`:
	 * enqueue must respect post_type, not just base.
	 */
	public function test_enqueue_wp_editor_assets_skips_off_whitelist_cpt(): void {
		$this->stub_current_screen( 'post', 'product' );

		$enqueued = 0;
		Functions\when( 'wp_enqueue_script' )->alias(
			static function () use ( &$enqueued ) {
				$enqueued++;
			}
		);

		( new WpEditorIntegration() )->enqueue_wp_editor_assets();
		$this->assertSame( 0, $enqueued, 'WC product (base=post + post_type=product) must NOT enqueue modal bundle' );
	}

	public function test_enqueue_wp_editor_assets_enqueues_on_post_screen(): void {
		$this->stub_current_screen( 'post', 'post' );

		$scripts = array();
		$styles  = array();
		Functions\when( 'wp_enqueue_script' )->alias(
			static function ( $handle ) use ( &$scripts ) {
				$scripts[] = $handle;
			}
		);
		Functions\when( 'wp_enqueue_style' )->alias(
			static function ( $handle ) use ( &$styles ) {
				$styles[] = $handle;
			}
		);
		Functions\when( 'wp_localize_script' )->justReturn( true );
		Functions\when( 'wp_enqueue_media' )->justReturn( true );

		( new WpEditorIntegration() )->enqueue_wp_editor_assets();

		// Classic-editor hook enqueues the FlashCardModal bundle only — the
		// Gutenberg block JS now ships through enqueue_block_editor_assets().
		$this->assertContains( 'lp-interactive-wp-editor', $scripts );
		$this->assertContains( 'lp-interactive-wp-editor', $styles );
		$this->assertNotContains( 'lp-interactive-gutenberg-block', $scripts );
	}

	public function test_enqueue_block_editor_assets_loads_block_js_for_any_user_on_supported_cpt(): void {
		$this->stub_current_screen( 'post', 'lp_lesson' );
		Functions\when( 'current_user_can' )->justReturn( false ); // not a deck author
		$scripts = array();
		Functions\when( 'wp_enqueue_script' )->alias(
			static function ( $handle ) use ( &$scripts ) {
				$scripts[] = $handle;
			}
		);
		Functions\when( 'wp_enqueue_style' )->justReturn( true );
		Functions\when( 'wp_localize_script' )->justReturn( true );
		Functions\when( 'wp_enqueue_media' )->justReturn( true );

		( new WpEditorIntegration() )->enqueue_block_editor_assets();

		$this->assertContains( 'lp-interactive-gutenberg-block', $scripts );
		$this->assertNotContains( 'lp-interactive-wp-editor', $scripts ); // gated by cap
	}

	public function test_enqueue_block_editor_assets_also_loads_modal_for_authors_on_supported_cpt(): void {
		$this->stub_current_screen( 'post', 'lp_course' );
		Functions\when( 'current_user_can' )->justReturn( true );
		$scripts = array();
		$styles  = array();
		Functions\when( 'wp_enqueue_script' )->alias(
			static function ( $handle ) use ( &$scripts ) {
				$scripts[] = $handle;
			}
		);
		Functions\when( 'wp_enqueue_style' )->alias(
			static function ( $handle ) use ( &$styles ) {
				$styles[] = $handle;
			}
		);
		Functions\when( 'wp_localize_script' )->justReturn( true );
		Functions\when( 'wp_enqueue_media' )->justReturn( true );

		( new WpEditorIntegration() )->enqueue_block_editor_assets();

		$this->assertContains( 'lp-interactive-gutenberg-block', $scripts );
		$this->assertContains( 'lp-interactive-wp-editor', $scripts );
		$this->assertContains( 'lp-interactive-wp-editor', $styles );
	}

	/**
	 * Regression guard: block editor on WooCommerce product / custom CPT
	 * must NOT load the Flashcard block JS. Previously the block was
	 * enqueued on every block-editor screen, so the Flashcard would
	 * appear in the inserter of unrelated CPTs.
	 */
	public function test_enqueue_block_editor_assets_skips_woocommerce_product(): void {
		$this->stub_current_screen( 'post', 'product' );
		Functions\when( 'current_user_can' )->justReturn( true );

		$scripts = array();
		Functions\when( 'wp_enqueue_script' )->alias(
			static function ( $handle ) use ( &$scripts ) {
				$scripts[] = $handle;
			}
		);
		Functions\when( 'wp_enqueue_style' )->justReturn( true );
		Functions\when( 'wp_localize_script' )->justReturn( true );
		Functions\when( 'wp_enqueue_media' )->justReturn( true );

		( new WpEditorIntegration() )->enqueue_block_editor_assets();

		$this->assertNotContains( 'lp-interactive-gutenberg-block', $scripts );
		$this->assertNotContains( 'lp-interactive-wp-editor', $scripts );
	}

	public function test_enqueue_block_editor_assets_skips_custom_cpt(): void {
		$this->stub_current_screen( 'post', 'my_custom_cpt' );
		Functions\when( 'current_user_can' )->justReturn( true );

		$scripts = array();
		Functions\when( 'wp_enqueue_script' )->alias(
			static function ( $handle ) use ( &$scripts ) {
				$scripts[] = $handle;
			}
		);
		Functions\when( 'wp_enqueue_style' )->justReturn( true );
		Functions\when( 'wp_localize_script' )->justReturn( true );
		Functions\when( 'wp_enqueue_media' )->justReturn( true );

		( new WpEditorIntegration() )->enqueue_block_editor_assets();

		$this->assertNotContains( 'lp-interactive-gutenberg-block', $scripts );
	}

	public function test_enqueue_block_editor_assets_skips_without_screen(): void {
		$this->stub_current_screen( null );
		Functions\when( 'current_user_can' )->justReturn( true );

		$scripts = array();
		Functions\when( 'wp_enqueue_script' )->alias(
			static function ( $handle ) use ( &$scripts ) {
				$scripts[] = $handle;
			}
		);
		Functions\when( 'wp_enqueue_style' )->justReturn( true );
		Functions\when( 'wp_localize_script' )->justReturn( true );
		Functions\when( 'wp_enqueue_media' )->justReturn( true );

		( new WpEditorIntegration() )->enqueue_block_editor_assets();

		$this->assertNotContains( 'lp-interactive-gutenberg-block', $scripts );
	}

	public function test_enqueue_wp_editor_assets_enqueues_on_lp_lesson_screen(): void {
		$this->stub_current_screen( 'post', 'lp_lesson' );

		$scripts = array();
		Functions\when( 'wp_enqueue_script' )->alias(
			static function ( $handle ) use ( &$scripts ) {
				$scripts[] = $handle;
			}
		);
		Functions\when( 'wp_enqueue_style' )->justReturn( true );
		Functions\when( 'wp_localize_script' )->justReturn( true );
		Functions\when( 'wp_enqueue_media' )->justReturn( true );

		( new WpEditorIntegration() )->enqueue_wp_editor_assets();

		$this->assertContains( 'lp-interactive-wp-editor', $scripts );
	}

	public function test_enqueue_block_editor_assets_localizes_can_create_flag(): void {
		$this->stub_current_screen( 'post', 'lp_lesson' );
		Functions\when( 'current_user_can' )->justReturn( true );
		Functions\when( 'wp_enqueue_script' )->justReturn( true );
		Functions\when( 'wp_enqueue_style' )->justReturn( true );
		Functions\when( 'wp_enqueue_media' )->justReturn( true );

		$localized = array();
		Functions\when( 'wp_localize_script' )->alias(
			static function ( $handle, $obj_name, $data ) use ( &$localized ) {
				$localized[ $obj_name ] = array(
					'handle' => $handle,
					'data'   => $data,
				);
			}
		);

		( new WpEditorIntegration() )->enqueue_block_editor_assets();

		$this->assertArrayHasKey( 'lpInteractiveBlock', $localized );
		$this->assertSame( 'lp-interactive-gutenberg-block', $localized['lpInteractiveBlock']['handle'] );
		$this->assertTrue( $localized['lpInteractiveBlock']['data']['canCreate'] );
	}

	public function test_enqueue_block_editor_assets_localizes_can_create_false_when_user_lacks_cap(): void {
		$this->stub_current_screen( 'post', 'lp_lesson' );
		Functions\when( 'current_user_can' )->justReturn( false );
		Functions\when( 'wp_enqueue_script' )->justReturn( true );
		Functions\when( 'wp_enqueue_style' )->justReturn( true );
		Functions\when( 'wp_enqueue_media' )->justReturn( true );

		$localized = array();
		Functions\when( 'wp_localize_script' )->alias(
			static function ( $handle, $obj_name, $data ) use ( &$localized ) {
				$localized[ $obj_name ] = $data;
			}
		);

		( new WpEditorIntegration() )->enqueue_block_editor_assets();

		$this->assertArrayHasKey( 'lpInteractiveBlock', $localized );
		$this->assertFalse( $localized['lpInteractiveBlock']['canCreate'] );
	}
}
