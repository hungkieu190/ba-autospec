<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Types;

use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use LearnPress\Interactive\Types\AbstractType;
use LearnPress\Interactive\Types\TypeInterface;
use LearnPress\Interactive\Types\TypeRegistry;

/**
 * Anonymous concrete type for registry tests (avoids depending on real types).
 */
final class FakeType extends AbstractType {
	public function key(): string                                         { return 'fake'; }
	public function label(): string                                       { return 'Fake'; }
	public function sanitize_item( array $raw ): array                    { return [ 'content' => '', 'extra_data' => [] ]; }
	public function render( array $parent, array $items ): string         { return 'fake-html'; }
}

/**
 * @covers \LearnPress\Interactive\Types\TypeRegistry
 * @covers \LearnPress\Interactive\Types\AbstractType
 */
class TypeRegistryTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();
		TypeRegistry::reset_for_tests();
	}

	public function test_register_then_get_returns_same_instance(): void {
		$type = new FakeType();
		TypeRegistry::register( $type );

		$this->assertSame( $type, TypeRegistry::get( 'fake' ) );
	}

	public function test_get_unknown_key_returns_null(): void {
		$this->assertNull( TypeRegistry::get( 'nonexistent' ) );
	}

	public function test_all_returns_keyed_array(): void {
		TypeRegistry::register( new FakeType() );
		$all = TypeRegistry::all();

		$this->assertArrayHasKey( 'fake', $all );
		$this->assertCount( 1, $all );
	}

	public function test_reset_for_tests_empties_registry(): void {
		TypeRegistry::register( new FakeType() );
		TypeRegistry::reset_for_tests();

		$this->assertSame( [], TypeRegistry::all() );
	}

	public function test_register_overwrites_same_key(): void {
		$first  = new FakeType();
		$second = new FakeType();
		TypeRegistry::register( $first );
		TypeRegistry::register( $second );

		$this->assertSame( $second, TypeRegistry::get( 'fake' ) );
		$this->assertCount( 1, TypeRegistry::all() );
	}

	public function test_abstract_type_default_settings_returns_empty(): void {
		$type = new FakeType();
		$this->assertSame( [], $type->default_settings() );
		$this->assertSame( [], $type->sanitize_settings( [ 'foo' => 'bar' ] ) );
		$this->assertSame( [], $type->frontend_handles() );
	}

	public function test_fake_type_implements_interface(): void {
		$this->assertInstanceOf( TypeInterface::class, new FakeType() );
	}

	public function test_boot_registers_all_built_in_types(): void {
		\Brain\Monkey\Functions\when( 'do_action' )->justReturn( null );

		TypeRegistry::boot();
		$all = TypeRegistry::all();

		$this->assertCount( 2, $all );
		$this->assertArrayHasKey( 'flash_card', $all );
		$this->assertArrayHasKey( 'slide', $all );
	}

	public function test_boot_is_idempotent_when_called_twice(): void {
		$called = 0;
		\Brain\Monkey\Functions\when( 'do_action' )->alias(
			static function () use ( &$called ) {
				$called++;
			}
		);

		TypeRegistry::boot();
		TypeRegistry::boot();

		$this->assertCount( 2, TypeRegistry::all() );
		$this->assertSame( 1, $called, 'do_action should fire only on first boot()' );
	}
}
