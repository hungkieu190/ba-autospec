<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Ajax;

use Brain\Monkey\Functions;
use LearnPress\Interactive\Ajax\InteractiveAjax;
use LearnPress\Interactive\Databases\InteractiveDB;
use LearnPress\Interactive\Services\InteractiveService;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use LearnPress\Interactive\Tests\Helpers\FakeServiceType;
use LearnPress\Interactive\Types\SlideType;
use LearnPress\Interactive\Types\TypeRegistry;
use Mockery;
use ReflectionClass;

/**
 * Custom exit signal — raised by stubbed wp_send_json so tests can intercept
 * the response payload without actually exiting the PHP process.
 */
final class AjaxResponseSignal extends \Exception {
	public array $payload;
	public int $http;
	public function __construct( array $payload, int $http ) {
		parent::__construct( 'wp_send_json' );
		$this->payload = $payload;
		$this->http    = $http;
	}
}

/**
 * @covers \LearnPress\Interactive\Ajax\InteractiveAjax
 */
class InteractiveAjaxTest extends BrainMonkeyTestCase {

	private ?string $font_upload_base = null;

	protected function setUp(): void {
		parent::setUp();

		InteractiveAjax::reset_for_tests();
		InteractiveService::reset_for_tests();
		TypeRegistry::reset_for_tests();
		TypeRegistry::register( new FakeServiceType() );
		$this->reset_interactive_db_singleton();

		Functions\when( 'current_time' )->justReturn( '2026-05-06 10:00:00' );
		Functions\when( 'wp_json_encode' )->alias(
			static fn( $data, $flags = 0 ) => json_encode( $data, (int) $flags )
		);
		Functions\when( 'sanitize_key' )->alias(
			static fn( $s ) => preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $s ) )
		);
		Functions\when( 'absint' )->alias(
			static fn( $v ) => abs( (int) $v )
		);
		Functions\when( 'get_current_user_id' )->justReturn( 1 );
		Functions\when( 'admin_url' )->alias(
			static fn( $path = '' ) => 'http://example.test/wp-admin/' . ltrim( $path, '/' )
		);

		// wp_send_json: capture payload + http status, throw signal so test can assert.
		Functions\when( 'wp_send_json' )->alias(
			static function ( $data, $http = 200, $flags = 0 ) {
				throw new AjaxResponseSignal( (array) $data, (int) $http );
			}
		);

		// $wpdb baseline.
		$wpdb            = Mockery::mock();
		$wpdb->prefix    = 'wp_';
		$wpdb->insert_id = 0;
		$GLOBALS['wpdb'] = $wpdb;
	}

	protected function tearDown(): void {
		if ( $this->font_upload_base ) {
			$this->remove_dir( $this->font_upload_base );
			$this->font_upload_base = null;
		}

		parent::tearDown();
	}

	private function reset_interactive_db_singleton(): void {
		$ref  = new ReflectionClass( InteractiveDB::class );
		$prop = $ref->getProperty( '_instance' );
		$prop->setAccessible( true );
		$prop->setValue( null, null );
	}

	private function inject_db_returning( array $rows, array $items = array() ): void {
		$db = Mockery::mock( InteractiveDB::class );
		$db->shouldReceive( 'get_interactives' )->andReturn( $rows );
		$db->shouldReceive( 'get_interactive_items' )->andReturn( $items );

		$ref  = new ReflectionClass( InteractiveDB::class );
		$prop = $ref->getProperty( '_instance' );
		$prop->setAccessible( true );
		$prop->setValue( null, $db );
	}

	/**
	 * Stub $wpdb->prepare() + ->get_results() so InteractiveItemModel::count_by_parent_ids
	 * returns the supplied id→count map. handle_list uses this for `item_count`.
	 *
	 * @param array<int,int> $counts
	 */
	private function stub_item_count_query( array $counts ): void {
		$wpdb = $GLOBALS['wpdb'];
		$rows = array();
		foreach ( $counts as $id => $cnt ) {
			$rows[] = array( 'interactive_id' => (int) $id, 'cnt' => (int) $cnt );
		}
		$wpdb->shouldReceive( 'prepare' )->andReturn( 'SELECT_STUB' );
		$wpdb->shouldReceive( 'get_results' )->andReturn( $rows );
	}

	/** Pass valid nonce + capability so handler proceeds past gate(). */
	private function pass_gate(): void {
		Functions\when( 'check_ajax_referer' )->justReturn( 1 );
		Functions\when( 'current_user_can' )->justReturn( true );
	}

	/** Run a handler and return the captured response array. */
	private function run_handler( string $handler ): array {
		try {
			InteractiveAjax::instance()->{$handler}();
			$this->fail( "$handler did not call wp_send_json" );
		} catch ( AjaxResponseSignal $signal ) {
			return array( 'http' => $signal->http, 'payload' => $signal->payload );
		}
	}

	/*  Gate tests  */

	public function test_gate_rejects_invalid_nonce_with_403(): void {
		Functions\when( 'check_ajax_referer' )->justReturn( false );
		Functions\when( 'current_user_can' )->justReturn( true );

		$resp = $this->run_handler( 'handle_create' );

		$this->assertSame( 403, $resp['http'] );
		$this->assertFalse( $resp['payload']['success'] );
		$this->assertSame( 'invalid_nonce', $resp['payload']['data']['code'] );
	}

	public function test_gate_rejects_user_without_capability_with_403(): void {
		Functions\when( 'check_ajax_referer' )->justReturn( 1 );
		Functions\when( 'current_user_can' )->justReturn( false );

		$resp = $this->run_handler( 'handle_create' );

		$this->assertSame( 403, $resp['http'] );
		$this->assertSame( 'forbidden', $resp['payload']['data']['code'] );
	}

	/* handle_create  */

	public function test_create_rejects_empty_title(): void {
		$this->pass_gate();
		$_POST = array( 'type' => 'fake' );

		$resp = $this->run_handler( 'handle_create' );

		$this->assertSame( 400, $resp['http'] );
		$this->assertSame( 'title_required', $resp['payload']['data']['code'] );
	}

	public function test_create_slide_without_title_uses_default_title(): void {
		$this->pass_gate();
		TypeRegistry::register( new SlideType() );

		$inserted_parent = null;
		$inserted_items  = array();
		$wpdb            = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$inserted_parent, &$inserted_items ) {
				if ( 'wp_learnpress_interactive' === $table ) {
					$inserted_parent = $row;
					$wpdb->insert_id = 19;
				} elseif ( 'wp_learnpress_interactive_items' === $table ) {
					$inserted_items[] = $row;
					$wpdb->insert_id  = count( $inserted_items );
				}
				return true;
			}
		);
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );

		$_POST = array( 'type' => 'slide' );
		$resp  = $this->run_handler( 'handle_create' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertSame( 19, $resp['payload']['data']['id'] );
		$this->assertSame( 'Untitled deck', $inserted_parent['title'] );
		$this->assertSame( '{}', $inserted_parent['extra_data'] );
		$this->assertCount( 1, $inserted_items );
		$this->assertSame( '{"version":"","objects":[]}', $inserted_items[0]['content'] );
		$this->assertSame( '{"width":842,"height":595}', $inserted_items[0]['extra_data'] );
	}

	public function test_save_slide_content_updates_only_one_slide_row(): void {
		$this->pass_gate();
		TypeRegistry::register( new SlideType() );
		$this->inject_db_returning(
			array(
				(object) array(
					'ID'         => 5,
					'title'      => 'Slide deck',
					'type'       => 'slide',
					'status'     => 'publish',
					'extra_data' => '{}',
					'author'     => 1,
					'created_at' => '2026-05-06 10:00:00',
					'updated_at' => '2026-05-06 10:00:00',
				),
			),
			array(
				(object) array(
					'ID'             => 12,
					'interactive_id' => 5,
					'content'        => '{"version":"","objects":[]}',
					'sort_order'     => 1,
					'extra_data'     => '{"width":842,"height":595}',
				),
			)
		);

		$wpdb         = $GLOBALS['wpdb'];
		$update_calls = array();
		$wpdb->shouldReceive( 'update' )->andReturnUsing(
			static function ( $table, $row, $where ) use ( &$update_calls ) {
				$update_calls[] = compact( 'table', 'row', 'where' );
				return 1;
			}
		);

		$_POST = array(
			'id'      => 5,
			'slide_id' => 12,
			'slide'    => wp_json_encode(
				array(
					'content'    => array(
						'version' => '7.0.0',
						'objects' => array(),
					),
					'extra_data' => array(
						'width'  => 900,
						'height' => 600,
					),
				)
			),
		);
		$resp  = $this->run_handler( 'handle_save_slide_content' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertSame( 5, $resp['payload']['data']['id'] );
		$this->assertSame( 12, $resp['payload']['data']['slide_id'] );
		$this->assertCount( 1, $update_calls );
		$this->assertSame( 'wp_learnpress_interactive_items', $update_calls[0]['table'] );
		$this->assertSame( array( 'ID' => 12 ), $update_calls[0]['where'] );
	}

	public function test_create_slide_inserts_one_slide_row_and_returns_slide_id(): void {
		$this->pass_gate();
		TypeRegistry::register( new SlideType() );
		$this->inject_db_returning(
			array( $this->row_with_type_and_status( 'slide', 'publish' ) )
		);

		$wpdb        = $GLOBALS['wpdb'];
		$insert_call = null;
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$insert_call ) {
				$insert_call     = compact( 'table', 'row' );
				$wpdb->insert_id = 44;
				return true;
			}
		);

		$_POST = array(
			'id'         => 5,
			'sort_order' => 1,
			'slide'    => wp_json_encode(
				array(
					'content'    => array(
						'version' => '7.0.0',
						'objects' => array(),
					),
					'extra_data' => array(
						'width'  => 842,
						'height' => 595,
					),
				)
			),
		);
		$resp  = $this->run_handler( 'handle_create_slide' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertSame( 5, $resp['payload']['data']['id'] );
		$this->assertSame( 44, $resp['payload']['data']['slide_id'] );
		$this->assertSame( 44, $resp['payload']['data']['slide']['ID'] );
		$this->assertSame( 1, $resp['payload']['data']['slide']['sort_order'] );
		$this->assertSame( 'wp_learnpress_interactive_items', $insert_call['table'] );
		$this->assertSame( '{"width":842,"height":595}', $insert_call['row']['extra_data'] );
	}

	public function test_delete_slide_removes_one_slide_row(): void {
		$this->pass_gate();
		TypeRegistry::register( new SlideType() );
		$this->inject_db_returning(
			array( $this->row_with_type_and_status( 'slide', 'publish' ) ),
			array(
				(object) array(
					'ID'             => 12,
					'interactive_id' => 5,
					'content'        => '{"version":"","objects":[]}',
					'sort_order'     => 0,
					'extra_data'     => '{}',
				),
			)
		);

		$wpdb        = $GLOBALS['wpdb'];
		$delete_call = null;
		$wpdb->shouldReceive( 'delete' )->andReturnUsing(
			static function ( $table, $where ) use ( &$delete_call ) {
				$delete_call = compact( 'table', 'where' );
				return 1;
			}
		);

		$_POST = array(
			'id'      => 5,
			'slide_id' => 12,
		);
		$resp  = $this->run_handler( 'handle_delete_slide' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertSame( 5, $resp['payload']['data']['id'] );
		$this->assertSame( 12, $resp['payload']['data']['slide_id'] );
		$this->assertSame( 'wp_learnpress_interactive_items', $delete_call['table'] );
		$this->assertSame( array( 'ID' => 12 ), $delete_call['where'] );
	}

	public function test_reorder_slides_updates_slide_row_order_without_items_payload(): void {
		$this->pass_gate();
		TypeRegistry::register( new SlideType() );
		$this->inject_db_returning(
			array( $this->row_with_type_and_status( 'slide', 'publish' ) ),
			array(
				(object) array(
					'ID'             => 11,
					'interactive_id' => 5,
					'content'        => '{"version":"","objects":[]}',
					'sort_order'     => 0,
					'extra_data'     => '{"width":842,"height":595}',
				),
				(object) array(
					'ID'             => 12,
					'interactive_id' => 5,
					'content'        => '{"version":"7.0.0","objects":[]}',
					'sort_order'     => 1,
					'extra_data'     => '{"width":842,"height":595}',
				),
			)
		);

		$wpdb        = $GLOBALS['wpdb'];
		$update_calls = array();
		$wpdb->shouldReceive( 'update' )->andReturnUsing(
			static function ( $table, $row, $where ) use ( &$update_calls ) {
				$update_calls[] = compact( 'table', 'row', 'where' );
				return 1;
			}
		);

		$_POST = array(
			'id'       => 5,
			'slide_ids' => wp_json_encode( array( 12, 11 ) ),
		);
		$resp  = $this->run_handler( 'handle_reorder_slides' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertSame( 5, $resp['payload']['data']['id'] );
		$this->assertSame( array( 12, 11 ), $resp['payload']['data']['slide_ids'] );
		$this->assertCount( 2, $update_calls );
		$this->assertSame( array( 'ID' => 12 ), $update_calls[0]['where'] );
		$this->assertSame( 0, $update_calls[0]['row']['sort_order'] );
		$this->assertSame( array( 'ID' => 11 ), $update_calls[1]['where'] );
		$this->assertSame( 1, $update_calls[1]['row']['sort_order'] );
	}

	public function test_cache_google_font_rejects_empty_family(): void {
		$this->pass_gate();

		$_POST = array( 'family' => '' );
		$resp  = $this->run_handler( 'handle_cache_google_font' );

		$this->assertSame( 400, $resp['http'] );
		$this->assertFalse( $resp['payload']['success'] );
		$this->assertSame( 'invalid_font', $resp['payload']['data']['code'] );
	}

	public function test_cache_google_font_downloads_font_and_returns_payload(): void {
		$this->pass_gate();
		$requests = array();
		$this->stub_font_cache_environment( $requests );

		$_POST = array(
			'family'   => 'Noto Sans',
			'variant'  => 'regular',
			'variants' => addslashes( wp_json_encode( array( 'regular', '700' ) ) ),
			'files'    => addslashes( wp_json_encode(
				array(
					'regular' => 'https://fonts.gstatic.com/s/notosans/v1/regular.woff2',
				)
			) ),
		);
		$resp  = $this->run_handler( 'handle_cache_google_font' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertTrue( $resp['payload']['success'] );
		$this->assertSame( 'Noto Sans', $resp['payload']['data']['family'] );
		$this->assertSame( 'noto-sans', $resp['payload']['data']['slug'] );
		$this->assertTrue( $resp['payload']['data']['cached'] );
		$this->assertSame(
			array(
				'https://fonts.googleapis.com/css2?family=Noto+Sans&display=swap',
				'https://fonts.gstatic.com/s/notosans/v1/regular.woff2',
			),
			$requests
		);
		$this->assertSame( 'ajax-font-binary', file_get_contents( $this->font_upload_base . '/interactive-fonts/noto-sans/regular.woff2' ) );
	}

	public function test_list_cached_google_fonts_returns_manifest_fonts(): void {
		$this->pass_gate();
		$requests = array();
		$this->stub_font_cache_environment( $requests );

		$font_dir = $this->font_upload_base . '/interactive-fonts/inter';
		mkdir( $font_dir, 0777, true );
		file_put_contents( $font_dir . '/regular.woff2', 'regular-font' );
		file_put_contents(
			$font_dir . '/font.json',
			wp_json_encode(
				array(
					'family'   => 'Inter',
					'slug'     => 'inter',
					'variants' => array( 'regular' ),
					'fonts'    => array(),
				)
			)
		);

		$_POST = array();
		$resp  = $this->run_handler( 'handle_list_cached_google_fonts' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertTrue( $resp['payload']['success'] );
		$this->assertCount( 1, $resp['payload']['data']['fonts'] );
		$this->assertSame( 'Inter', $resp['payload']['data']['fonts'][0]['family'] );
		$this->assertSame( 'http://example.test/uploads/interactive-fonts/inter/regular.woff2', $resp['payload']['data']['fonts'][0]['fonts']['regular']['url'] );
		$this->assertSame( array(), $requests );
	}

	public function test_create_rejects_unknown_type(): void {
		$this->pass_gate();
		$_POST = array( 'title' => 'X', 'type' => 'nope' );

		$resp = $this->run_handler( 'handle_create' );

		$this->assertSame( 'invalid_type', $resp['payload']['data']['code'] );
	}

	public function test_create_succeeds_and_returns_id_and_edit_url(): void {
		$this->pass_gate();

		// Setup $wpdb to accept parent insert.
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb ) {
				if ( 'wp_learnpress_interactive' === $table ) {
					$wpdb->insert_id = 7;
				}
				return true;
			}
		);
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );

		$_POST = array(
			'title' => 'Learn programming',
			'type'  => 'fake',
		);

		$resp = $this->run_handler( 'handle_create' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertTrue( $resp['payload']['success'] );
		$this->assertSame( 7, $resp['payload']['data']['id'] );
		$this->assertStringContainsString( 'page=lp-interactive&action=edit&id=7', $resp['payload']['data']['edit_url'] );
	}

	/**
	 * Regression: wp_magic_quotes() addslashes() $_POST before AJAX handlers
	 * see it. decode_json_field() must wp_unslash() before json_decode or the
	 * backslashed quotes break decoding and seeded items silently vanish.
	 */
	public function test_create_decodes_magic_quoted_json_items_payload(): void {
		$this->pass_gate();

		$wpdb           = $GLOBALS['wpdb'];
		$item_rows      = array();
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$item_rows ) {
				if ( 'wp_learnpress_interactive' === $table ) {
					$wpdb->insert_id = 11;
				}
				if ( 'wp_learnpress_interactive_items' === $table ) {
					$item_rows[] = $row;
				}
				return true;
			}
		);
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );

		$items_json = json_encode(
			array(
				array( 'content' => "Xin chào \u{00e0}" ),
			),
			JSON_UNESCAPED_UNICODE
		);

		// Simulate wp_magic_quotes() — every $_POST string is addslashes()'d.
		$_POST = array(
			'title' => 'Greeting',
			'type'  => 'fake',
			'items' => addslashes( $items_json ),
		);

		$resp = $this->run_handler( 'handle_create' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertCount( 1, $item_rows, 'Items must reach DB after wp_unslash + json_decode' );
		$this->assertSame( "Xin chào \u{00e0}", $item_rows[0]['content'] );
	}

	/*  handle_save  */

	public function test_save_rejects_invalid_id(): void {
		$this->pass_gate();
		$_POST = array( 'id' => 0 );

		$resp = $this->run_handler( 'handle_save' );

		$this->assertSame( 'invalid_id', $resp['payload']['data']['code'] );
	}

	public function test_save_rejects_invalid_status_value(): void {
		$this->pass_gate();
		$_POST = array( 'id' => 5, 'status' => 'malicious' );

		$resp = $this->run_handler( 'handle_save' );

		$this->assertSame( 'invalid_status', $resp['payload']['data']['code'] );
	}

	public function test_save_returns_500_when_service_save_returns_false(): void {
		$this->pass_gate();
		$this->inject_db_returning( array() );

		$_POST = array( 'id' => 5, 'title' => 'X' );

		$resp = $this->run_handler( 'handle_save' );

		$this->assertSame( 500, $resp['http'] );
		$this->assertSame( 'save_failed', $resp['payload']['data']['code'] );
	}

	/*  handle_get  */

	public function test_get_returns_404_when_entry_not_found(): void {
		$this->pass_gate();
		$this->inject_db_returning( array() );
		$_POST = array( 'id' => 5 );

		$resp = $this->run_handler( 'handle_get' );

		$this->assertSame( 404, $resp['http'] );
		$this->assertSame( 'not_found', $resp['payload']['data']['code'] );
	}

	public function test_get_returns_parent_and_items_when_found(): void {
		$this->pass_gate();
		$row = (object) array(
			'ID'         => 5,
			'title'      => 'Question',
			'type'       => 'fake',
			'status'     => 'publish',
			'extra_data' => '{}',
			'author'     => 1,
			'created_at' => '2026-05-06 10:00:00',
			'updated_at' => '2026-05-06 10:00:00',
		);
		$item_row = (object) array(
			'ID'             => 1,
			'interactive_id' => 5,
			'content'        => 'A',
			'sort_order'     => 0,
			'extra_data'     => '{}',
		);
		$this->inject_db_returning( array( $row ), array( $item_row ) );
		$_POST = array( 'id' => 5 );

		$resp = $this->run_handler( 'handle_get' );

		$this->assertTrue( $resp['payload']['success'] );
		$this->assertSame( 'Question', $resp['payload']['data']['parent']['title'] );
		$this->assertCount( 1, $resp['payload']['data']['items'] );
		$this->assertSame( 'A', $resp['payload']['data']['items'][0]['content'] );
	}

	public function test_get_enriches_flash_card_items_with_decoded_card_and_image_urls(): void {
		$this->pass_gate();

		Functions\when( 'wp_get_attachment_image_url' )->alias(
			static fn( $id, $size = 'medium' ) => $id > 0
				? "http://example.test/img/{$id}-{$size}.jpg"
				: false
		);

		$row = (object) array(
			'ID'         => 7,
			'title'      => 'Deck',
			'type'       => 'flash_card',
			'status'     => 'publish',
			'extra_data' => '{}',
			'author'     => 1,
			'created_at' => '',
			'updated_at' => '',
		);
		$item_row = (object) array(
			'ID'             => 11,
			'interactive_id' => 7,
			'content'        => '{"front":{"title":"<p>F</p>","image_id":42,"subtitle":"<p>FS</p>"},"back":{"title":"<p>B</p>","image_id":99,"subtitle":"<p>BS</p>"}}',
			'sort_order'     => 0,
			'extra_data'     => '{}',
		);
		$this->inject_db_returning( array( $row ), array( $item_row ) );
		$_POST = array( 'id' => 7 );

		$resp = $this->run_handler( 'handle_get' );
		$card = $resp['payload']['data']['items'][0]['card'];

		$this->assertSame( '<p>F</p>', $card['front']['title'] );
		$this->assertSame( 42, (int) $card['front']['image_id'] );
		$this->assertSame( 'http://example.test/img/42-medium.jpg', $card['front']['image_url'] );
		$this->assertSame( '<p>FS</p>', $card['front']['subtitle'] );
		$this->assertSame( '<p>B</p>', $card['back']['title'] );
		$this->assertSame( 99, (int) $card['back']['image_id'] );
		$this->assertSame( 'http://example.test/img/99-medium.jpg', $card['back']['image_url'] );
		$this->assertSame( '<p>BS</p>', $card['back']['subtitle'] );
	}

	public function test_get_emits_empty_image_url_when_no_attachment_set(): void {
		$this->pass_gate();

		Functions\when( 'wp_get_attachment_image_url' )->alias(
			static fn( $id ) => $id > 0 ? 'should-not-be-called' : false
		);

		$row = (object) array(
			'ID'         => 8,
			'title'      => 'Deck',
			'type'       => 'flash_card',
			'status'     => 'publish',
			'extra_data' => '{}',
			'author'     => 1,
			'created_at' => '',
			'updated_at' => '',
		);
		$item_row = (object) array(
			'ID'             => 12,
			'interactive_id' => 8,
			'content'        => '{"front":{"title":"","image_id":0,"subtitle":""},"back":{"title":"","image_id":0,"subtitle":""}}',
			'sort_order'     => 0,
			'extra_data'     => '{}',
		);
		$this->inject_db_returning( array( $row ), array( $item_row ) );
		$_POST = array( 'id' => 8 );

		$resp = $this->run_handler( 'handle_get' );
		$card = $resp['payload']['data']['items'][0]['card'];

		$this->assertSame( '', $card['front']['image_url'] );
		$this->assertSame( '', $card['back']['image_url'] );
	}

	/*  handle_list  */

	public function test_list_returns_pagination_meta_with_shortcode_per_row(): void {
		$this->pass_gate();
		$rows = array(
			(object) array( 'ID' => 1, 'title' => 'A', 'type' => 'fake', 'status' => 'publish', 'author' => 1, 'created_at' => '', 'updated_at' => '' ),
			(object) array( 'ID' => 2, 'title' => 'B', 'type' => 'fake', 'status' => 'publish', 'author' => 1, 'created_at' => '', 'updated_at' => '' ),
		);
		// Set $total via reference inside mock.
		$db = Mockery::mock( InteractiveDB::class );
		$db->shouldReceive( 'get_interactives' )->andReturnUsing(
			static function ( $filter, &$total ) use ( $rows ) {
				$total = 25;
				return $rows;
			}
		);
		$ref  = new ReflectionClass( InteractiveDB::class );
		$prop = $ref->getProperty( '_instance' );
		$prop->setAccessible( true );
		$prop->setValue( null, $db );

		$this->stub_item_count_query( array( 1 => 0, 2 => 0 ) );

		$_POST = array( 'paged' => 1, 'per_page' => 10 );

		$resp = $this->run_handler( 'handle_list' );

		$this->assertTrue( $resp['payload']['success'] );
		$this->assertCount( 2, $resp['payload']['data']['items'] );
		$this->assertSame( 25, $resp['payload']['data']['total'] );
		$this->assertSame( 3, $resp['payload']['data']['total_pages'] );
		$this->assertSame( 1, $resp['payload']['data']['paged'] );
		$this->assertSame( '[learnpress_single_interactive id=1]', $resp['payload']['data']['items'][0]['shortcode'] );
	}

	public function test_list_includes_item_count_per_row(): void {
		$this->pass_gate();
		$rows = array(
			(object) array( 'ID' => 11, 'title' => 'Deck A', 'type' => 'flash_card', 'status' => 'publish', 'author' => 1, 'created_at' => '', 'updated_at' => '' ),
			(object) array( 'ID' => 12, 'title' => 'Deck B', 'type' => 'flash_card', 'status' => 'publish', 'author' => 1, 'created_at' => '', 'updated_at' => '' ),
		);
		$db = Mockery::mock( InteractiveDB::class );
		$db->shouldReceive( 'get_interactives' )->andReturnUsing(
			static function ( $filter, &$total ) use ( $rows ) {
				$total = 2;
				return $rows;
			}
		);
		$ref  = new ReflectionClass( InteractiveDB::class );
		$prop = $ref->getProperty( '_instance' );
		$prop->setAccessible( true );
		$prop->setValue( null, $db );

		$this->stub_item_count_query( array( 11 => 5, 12 => 2 ) );

		$_POST = array();

		$resp = $this->run_handler( 'handle_list' );

		$this->assertTrue( $resp['payload']['success'] );
		$items = $resp['payload']['data']['items'];
		$this->assertCount( 2, $items );
		$this->assertSame( 5, $items[0]['item_count'], 'Deck A should report 5 items' );
		$this->assertSame( 2, $items[1]['item_count'], 'Deck B should report 2 items' );
	}

	public function test_list_default_includes_all_statuses_in_all_view(): void {
		$this->pass_gate();
		$captured = null;
		$db       = Mockery::mock( InteractiveDB::class );
		$db->shouldReceive( 'get_interactives' )->andReturnUsing(
			static function ( $filter, &$total ) use ( &$captured ) {
				if ( null === $captured ) {
					$captured = clone $filter;
				}
				$total = 0;
				return array();
			}
		);
		$ref  = new ReflectionClass( InteractiveDB::class );
		$prop = $ref->getProperty( '_instance' );
		$prop->setAccessible( true );
		$prop->setValue( null, $db );

		// No status submitted → default "All" view.
		$_POST = array();

		$this->run_handler( 'handle_list' );

		$this->assertEmpty( $captured->status, 'No single status when "All" is selected' );
		$this->assertSame(
			array( 'publish', 'draft', 'trash' ),
			$captured->status_in,
			'"All Status" filter must include trash so user sees every entry'
		);
	}

	public function test_list_invalid_status_falls_back_to_all_statuses_default(): void {
		$this->pass_gate();
		$captured = null;
		$db       = Mockery::mock( InteractiveDB::class );
		$db->shouldReceive( 'get_interactives' )->andReturnUsing(
			static function ( $filter, &$total ) use ( &$captured ) {
				if ( null === $captured ) {
					$captured = clone $filter;
				}
				$total = 0;
				return array();
			}
		);
		$ref  = new ReflectionClass( InteractiveDB::class );
		$prop = $ref->getProperty( '_instance' );
		$prop->setAccessible( true );
		$prop->setValue( null, $db );

		$_POST = array( 'status' => 'garbage_status' );

		$this->run_handler( 'handle_list' );

		$this->assertEmpty( $captured->status );
		$this->assertSame( array( 'publish', 'draft', 'trash' ), $captured->status_in );
	}

	public function test_list_explicit_trash_status_is_respected(): void {
		$this->pass_gate();
		$captured = null;
		$db       = Mockery::mock( InteractiveDB::class );
		$db->shouldReceive( 'get_interactives' )->andReturnUsing(
			static function ( $filter, &$total ) use ( &$captured ) {
				if ( null === $captured ) {
					$captured = clone $filter;
				}
				$total = 0;
				return array();
			}
		);
		$ref  = new ReflectionClass( InteractiveDB::class );
		$prop = $ref->getProperty( '_instance' );
		$prop->setAccessible( true );
		$prop->setValue( null, $db );

		$_POST = array( 'status' => 'trash' );

		$this->run_handler( 'handle_list' );

		$this->assertSame( 'trash', $captured->status );
		$this->assertSame( array(), $captured->status_in, 'Explicit status must not enable status_in fallback' );
	}

	public function test_list_rejects_unsafe_orderby_falls_back_to_created_at(): void {
		$this->pass_gate();
		$captured_orderby = null;
		$db = Mockery::mock( InteractiveDB::class );
		$db->shouldReceive( 'get_interactives' )->andReturnUsing(
			static function ( $filter, &$total ) use ( &$captured_orderby ) {
				if ( null === $captured_orderby ) {
					$captured_orderby = $filter->order_by;
				}
				$total = 0;
				return array();
			}
		);
		$ref  = new ReflectionClass( InteractiveDB::class );
		$prop = $ref->getProperty( '_instance' );
		$prop->setAccessible( true );
		$prop->setValue( null, $db );

		$_POST = array( 'orderby' => 'evil_column; DROP TABLE' );

		$this->run_handler( 'handle_list' );

		$this->assertSame( 'created_at', $captured_orderby, 'Unsafe orderby must fall back to whitelist default' );
	}

	/*  handle_delete / restore / force_delete  */

	public function test_delete_rejects_invalid_id(): void {
		$this->pass_gate();
		$_POST = array();
		$resp  = $this->run_handler( 'handle_delete' );
		$this->assertSame( 'invalid_id', $resp['payload']['data']['code'] );
	}

	public function test_force_delete_blocks_when_status_not_trash(): void {
		$this->pass_gate();
		$row = (object) array(
			'ID'         => 5,
			'title'      => 'A',
			'type'       => 'fake',
			'status'     => 'publish',
			'extra_data' => '{}',
			'author'     => 1,
		);
		$this->inject_db_returning( array( $row ) );

		$_POST = array( 'id' => 5 );
		$resp  = $this->run_handler( 'handle_force_delete' );

		$this->assertSame( 400, $resp['http'] );
		$this->assertFalse( $resp['payload']['success'] );
		$this->assertSame( 'not_in_trash', $resp['payload']['data']['code'] );
	}

	public function test_force_delete_returns_404_when_entry_missing(): void {
		$this->pass_gate();
		$this->inject_db_returning( array() );
		$_POST = array( 'id' => 999 );

		$resp = $this->run_handler( 'handle_force_delete' );

		$this->assertSame( 404, $resp['http'] );
		$this->assertSame( 'not_found', $resp['payload']['data']['code'] );
	}

	public function test_delete_happy_path_returns_id(): void {
		$this->pass_gate();
		$this->inject_db_returning( array( $this->row_with_status( 'publish' ) ) );

		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'update' )->andReturn( 1 );
		$_POST = array( 'id' => 5 );
		$resp  = $this->run_handler( 'handle_delete' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertTrue( $resp['payload']['success'] );
		$this->assertSame( 5, $resp['payload']['data']['id'] );
	}

	public function test_restore_happy_path_returns_id(): void {
		$this->pass_gate();
		$this->inject_db_returning( array( $this->row_with_status( 'trash' ) ) );

		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'update' )->andReturn( 1 );
		$_POST = array( 'id' => 5 );
		$resp  = $this->run_handler( 'handle_restore' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertTrue( $resp['payload']['success'] );
		$this->assertSame( 5, $resp['payload']['data']['id'] );
	}

	public function test_force_delete_happy_path_when_in_trash(): void {
		$this->pass_gate();
		$this->inject_db_returning( array( $this->row_with_status( 'trash' ) ) );

		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'delete' )->andReturn( 1 );

		$_POST = array( 'id' => 5 );
		$resp  = $this->run_handler( 'handle_force_delete' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertTrue( $resp['payload']['success'] );
		$this->assertSame( 5, $resp['payload']['data']['id'] );
	}

	public function test_save_happy_path_returns_id(): void {
		$this->pass_gate();
		$this->inject_db_returning( array( $this->row_with_status( 'publish' ) ) );

		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'update' )->andReturn( 1 );

		$_POST = array( 'id' => 5, 'title' => 'Renamed' );
		$resp  = $this->run_handler( 'handle_save' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertTrue( $resp['payload']['success'] );
		$this->assertSame( 5, $resp['payload']['data']['id'] );
	}

	public function test_save_round_trips_slide_fabric_content_and_slide_dimensions(): void {
		$this->pass_gate();
		TypeRegistry::register( new SlideType() );
		$this->inject_db_returning( array( $this->row_with_type_and_status( 'slide', 'publish' ) ) );

		$item_rows = array();
		$wpdb      = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'update' )->andReturn( 1 );
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$item_rows ) {
				if ( 'wp_learnpress_interactive_items' === $table ) {
					$item_rows[] = $row;
					$wpdb->insert_id = count( $item_rows );
				}
				return true;
			}
		);

		$items = array(
			array(
				'width'   => 1024,
				'height'  => 768,
				'content' => array(
					'version' => '6.0.0',
					'objects' => array(
						array(
							'type' => 'textbox',
							'text' => 'Hello',
							'left' => 100,
						),
					),
				),
			),
		);

		$_POST = array(
			'id'    => 5,
			'title' => 'Slide deck',
			'items' => addslashes( json_encode( $items, JSON_UNESCAPED_UNICODE ) ),
		);
		$resp  = $this->run_handler( 'handle_save' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertTrue( $resp['payload']['success'] );
		$this->assertCount( 1, $item_rows );
		$this->assertSame( 0, $item_rows[0]['sort_order'] );

		$content = json_decode( $item_rows[0]['content'], true );
		$extra   = json_decode( $item_rows[0]['extra_data'], true );

		$this->assertSame( '6.0.0', $content['version'] );
		$this->assertSame( 'textbox', $content['objects'][0]['type'] );
		$this->assertSame( 'Hello', $content['objects'][0]['text'] );
		$this->assertSame(
			array(
				'width'  => 1024,
				'height' => 768,
			),
			$extra
		);
	}

	public function test_duplicate_returns_new_id_on_success(): void {
		$this->pass_gate();
		$this->inject_db_returning( array( $this->row_with_status( 'publish' ) ) );
		\Brain\Monkey\Functions\when( 'get_current_user_id' )->justReturn( 1 );

		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb ) {
				$wpdb->insert_id = 'wp_learnpress_interactive' === $table ? 100 : 1;
				return true;
			}
		);
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );

		$_POST = array( 'id' => 5 );
		$resp  = $this->run_handler( 'handle_duplicate' );

		$this->assertSame( 200, $resp['http'] );
		$this->assertTrue( $resp['payload']['success'] );
		$this->assertSame( 100, $resp['payload']['data']['id'] );
	}

	public function test_duplicate_returns_404_when_entry_missing(): void {
		$this->pass_gate();
		$this->inject_db_returning( array() );

		$_POST = array( 'id' => 999 );
		$resp  = $this->run_handler( 'handle_duplicate' );

		$this->assertSame( 404, $resp['http'] );
		$this->assertFalse( $resp['payload']['success'] );
		$this->assertSame( 'not_found', $resp['payload']['data']['code'] );
	}

	public function test_duplicate_rejects_missing_id(): void {
		$this->pass_gate();

		$_POST = array();
		$resp  = $this->run_handler( 'handle_duplicate' );

		$this->assertSame( 400, $resp['http'] );
		$this->assertFalse( $resp['payload']['success'] );
		$this->assertSame( 'invalid_id', $resp['payload']['data']['code'] );
	}

	/*  Security: no exception leak  */

	public function test_create_does_not_leak_exception_message_to_client(): void {
		$this->pass_gate();
		$_POST = array( 'title' => 'X', 'type' => 'fake' );

		// Make Service throw with a sensitive-looking message.
		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'insert' )->andThrow( new \RuntimeException( 'SQL: SELECT * FROM secret_table WHERE password=...' ) );
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );

		$resp = $this->run_handler( 'handle_create' );

		$this->assertSame( 500, $resp['http'] );
		$this->assertSame( 'create_failed', $resp['payload']['data']['code'] );
		// Must NOT echo the original exception message to client.
		$this->assertSame( '', $resp['payload']['data']['message'] );
		$payload_str = json_encode( $resp['payload'] );
		$this->assertStringNotContainsString( 'SELECT * FROM secret_table', $payload_str );
		$this->assertStringNotContainsString( 'password=', $payload_str );
	}

	/*  Pre-flight 404 checks  */

	public function test_delete_returns_404_when_entry_missing(): void {
		$this->pass_gate();
		$this->inject_db_returning( array() );
		$_POST = array( 'id' => 999 );

		$resp = $this->run_handler( 'handle_delete' );

		$this->assertSame( 404, $resp['http'] );
		$this->assertSame( 'not_found', $resp['payload']['data']['code'] );
	}

	public function test_restore_returns_404_when_entry_missing(): void {
		$this->pass_gate();
		$this->inject_db_returning( array() );
		$_POST = array( 'id' => 999 );

		$resp = $this->run_handler( 'handle_restore' );

		$this->assertSame( 404, $resp['http'] );
		$this->assertSame( 'not_found', $resp['payload']['data']['code'] );
	}

	/*  Save response shape  */

	public function test_save_response_includes_updated_at(): void {
		$this->pass_gate();
		$this->inject_db_returning( array( $this->row_with_status( 'publish' ) ) );

		$wpdb = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'update' )->andReturn( 1 );

		$_POST = array( 'id' => 5, 'title' => 'Renamed' );
		$resp  = $this->run_handler( 'handle_save' );

		$this->assertTrue( $resp['payload']['success'] );
		$this->assertArrayHasKey( 'updated_at', $resp['payload']['data'] );
		$this->assertSame( '2026-05-06 10:00:00', $resp['payload']['data']['updated_at'] );
	}

	/*  Title max length 255  */

	public function test_create_truncates_title_to_255_chars(): void {
		$this->pass_gate();

		$captured_title = '';
		$wpdb           = $GLOBALS['wpdb'];
		$wpdb->shouldReceive( 'insert' )->andReturnUsing(
			static function ( $table, $row ) use ( $wpdb, &$captured_title ) {
				if ( 'wp_learnpress_interactive' === $table ) {
					$captured_title  = $row['title'];
					$wpdb->insert_id = 1;
				}
				return true;
			}
		);
		$wpdb->shouldReceive( 'query' )->andReturn( true );
		$wpdb->shouldReceive( 'delete' )->andReturn( 0 );

		$_POST = array(
			'title' => str_repeat( 'a', 300 ),
			'type'  => 'fake',
		);

		$this->run_handler( 'handle_create' );

		$this->assertSame( 255, mb_strlen( $captured_title ), 'Title must be truncated to 255 chars (varchar limit)' );
	}

	/** Build a parent row stdClass with chosen status for delete/restore tests. */
	private function row_with_status( string $status ): object {
		return $this->row_with_type_and_status( 'fake', $status );
	}

	private function row_with_type_and_status( string $type, string $status ): object {
		return (object) array(
			'ID'         => 5,
			'title'      => 'Existing',
			'type'       => $type,
			'status'     => $status,
			'extra_data' => '{}',
			'author'     => 1,
			'created_at' => '2026-05-06 10:00:00',
			'updated_at' => '2026-05-06 10:00:00',
		);
	}

	private function stub_font_cache_environment( array &$requests ): void {
		$this->font_upload_base = sys_get_temp_dir() . '/lp-interactive-ajax-fonts-' . uniqid( '', true );
		mkdir( $this->font_upload_base, 0777, true );

		Functions\when( 'wp_upload_dir' )->alias(
			fn() => array(
				'basedir' => $this->font_upload_base,
				'baseurl' => 'http://example.test/uploads',
				'error'   => false,
			)
		);
		Functions\when( 'trailingslashit' )->alias(
			static fn( $path ) => rtrim( (string) $path, '/\\' ) . '/'
		);
		Functions\when( 'wp_mkdir_p' )->alias(
			static fn( $path ) => is_dir( (string) $path ) || mkdir( (string) $path, 0777, true )
		);
		Functions\when( 'sanitize_title' )->alias(
			static function ( $value ) {
				$value = strtolower( trim( (string) $value ) );
				$value = preg_replace( '/[^a-z0-9]+/', '-', $value );
				return trim( (string) $value, '-' );
			}
		);
		Functions\when( 'sanitize_file_name' )->alias(
			static fn( $value ) => preg_replace( '/[^a-z0-9._-]+/', '-', strtolower( (string) $value ) )
		);
		Functions\when( 'esc_url_raw' )->returnArg();
		Functions\when( 'add_query_arg' )->alias(
			static function ( array $args, string $url ): string {
				return $url . '?' . http_build_query( $args );
			}
		);
		Functions\when( 'is_wp_error' )->justReturn( false );
		Functions\when( 'wp_remote_get' )->alias(
			static function ( $url, $args = array() ) use ( &$requests ) {
				$requests[] = (string) $url;
				return array(
					'response' => array( 'code' => 200 ),
					'body'     => 'ajax-font-binary',
				);
			}
		);
		Functions\when( 'wp_remote_retrieve_response_code' )->alias(
			static fn( $response ) => (int) ( $response['response']['code'] ?? 0 )
		);
		Functions\when( 'wp_remote_retrieve_body' )->alias(
			static fn( $response ) => (string) ( $response['body'] ?? '' )
		);
	}

	private function remove_dir( string $path ): void {
		if ( ! is_dir( $path ) ) {
			return;
		}

		$items = scandir( $path );
		foreach ( false === $items ? array() : $items as $item ) {
			if ( '.' === $item || '..' === $item ) {
				continue;
			}

			$child = $path . '/' . $item;
			if ( is_dir( $child ) ) {
				$this->remove_dir( $child );
				continue;
			}

			unlink( $child );
		}

		rmdir( $path );
	}
}
