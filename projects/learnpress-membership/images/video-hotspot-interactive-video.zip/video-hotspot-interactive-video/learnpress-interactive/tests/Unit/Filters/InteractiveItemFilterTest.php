<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Filters;

use LearnPress\Interactive\Filters\InteractiveItemFilter;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use stdClass;

/**
 * @covers \LearnPress\Interactive\Filters\InteractiveItemFilter
 */
class InteractiveItemFilterTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();
		$wpdb            = new stdClass();
		$wpdb->prefix    = 'wp_';
		$GLOBALS['wpdb'] = $wpdb;
	}

	public function test_constructor_targets_items_table_with_alias_ii(): void {
		$filter = new InteractiveItemFilter();
		$this->assertSame( 'wp_learnpress_interactive_items', $filter->collection );
		$this->assertSame( 'ii', $filter->collection_alias );
	}

	public function test_default_sort_is_sort_order_ascending(): void {
		$filter = new InteractiveItemFilter();
		$this->assertSame( 'sort_order', $filter->order_by );
		$this->assertSame( 'ASC', $filter->order );
	}

	public function test_all_fields_contains_five_columns(): void {
		$filter = new InteractiveItemFilter();
		$this->assertSame(
			[ 'ID', 'interactive_id', 'content', 'sort_order', 'extra_data' ],
			$filter->all_fields
		);
	}

	public function test_domain_properties_are_nullable(): void {
		$filter = new InteractiveItemFilter();
		$this->assertNull( $filter->ID );
		$this->assertNull( $filter->interactive_id );
	}
}
