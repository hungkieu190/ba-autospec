<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Filters;

use LearnPress\Interactive\Filters\InteractiveFilter;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use Mockery;
use stdClass;

/**
 * @covers \LearnPress\Interactive\Filters\InteractiveFilter
 */
class InteractiveFilterTest extends BrainMonkeyTestCase {

	protected function setUp(): void {
		parent::setUp();
		$wpdb         = new stdClass();
		$wpdb->prefix = 'wp_';
		$GLOBALS['wpdb'] = $wpdb;
	}

	public function test_constructor_sets_collection_and_alias(): void {
		$filter = new InteractiveFilter();
		$this->assertSame( 'wp_learnpress_interactive', $filter->collection );
		$this->assertSame( 'i', $filter->collection_alias );
	}

	public function test_inherits_filter_base_pagination_defaults(): void {
		$filter = new InteractiveFilter();
		$this->assertSame( 1, $filter->page );
		$this->assertSame( 10, $filter->limit );
	}

	public function test_all_fields_contains_eight_columns(): void {
		$filter = new InteractiveFilter();
		$this->assertCount( 8, $filter->all_fields );
		$this->assertContains( 'ID',         $filter->all_fields );
		$this->assertContains( 'title',      $filter->all_fields );
		$this->assertContains( 'type',       $filter->all_fields );
		$this->assertContains( 'status',     $filter->all_fields );
		$this->assertContains( 'extra_data', $filter->all_fields );
		$this->assertContains( 'author',     $filter->all_fields );
		$this->assertContains( 'created_at', $filter->all_fields );
		$this->assertContains( 'updated_at', $filter->all_fields );
	}

	public function test_does_not_include_dropped_lang_column(): void {
		$filter = new InteractiveFilter();
		$this->assertNotContains( 'lang', $filter->all_fields );
		$this->assertFalse( property_exists( $filter, 'lang' ) );
	}

	public function test_domain_properties_are_nullable(): void {
		$filter = new InteractiveFilter();
		$this->assertNull( $filter->ID );
		$this->assertNull( $filter->title );
		$this->assertNull( $filter->type );
		$this->assertNull( $filter->status );
		$this->assertNull( $filter->author );
	}

	public function test_no_typo_property_tilte(): void {
		$filter = new InteractiveFilter();
		$this->assertFalse( property_exists( $filter, 'tilte' ) );
		$this->assertTrue( property_exists( $filter, 'title' ) );
	}
}
