<?php

declare( strict_types=1 );

namespace LearnPress\Interactive\Tests\Unit\Services;

use Brain\Monkey\Functions;
use LearnPress\Interactive\Services\GoogleFontCacheService;
use LearnPress\Interactive\Tests\Helpers\BrainMonkeyTestCase;
use RuntimeException;

/**
 * @covers \LearnPress\Interactive\Services\GoogleFontCacheService
 */
class GoogleFontCacheServiceTest extends BrainMonkeyTestCase {

	private string $upload_base;

	protected function setUp(): void {
		parent::setUp();

		$this->upload_base = sys_get_temp_dir() . '/lp-interactive-fonts-' . uniqid( '', true );
		mkdir( $this->upload_base, 0777, true );
		$this->stub_wordpress_file_helpers();
	}

	protected function tearDown(): void {
		$this->remove_dir( $this->upload_base );
		parent::tearDown();
	}

	public function test_cache_writes_gstatic_font_file_and_manifest(): void {
		$requests = array();
		$this->stub_http(
			static function ( string $url ) use ( &$requests ): array {
				$requests[] = $url;
				return array(
					'response' => array( 'code' => 200 ),
					'body'     => 'woff2-binary',
				);
			}
		);

		$result = ( new GoogleFontCacheService() )->cache(
			'Noto Sans',
			array( 'regular' => 'https://fonts.gstatic.com/s/notosans/v1/regular.woff2' ),
			'regular',
			array( 'regular', '700' )
		);

		$font_dir = $this->upload_base . '/interactive-fonts/noto-sans';
		$this->assertSame(
			array(
				'https://fonts.googleapis.com/css2?family=Noto+Sans&display=swap',
				'https://fonts.gstatic.com/s/notosans/v1/regular.woff2',
			),
			$requests
		);
		$this->assertSame( 'woff2-binary', file_get_contents( $font_dir . '/regular.woff2' ) );
		$this->assertSame( 'Noto Sans', $result['family'] );
		$this->assertSame( 'noto-sans', $result['slug'] );
		$this->assertTrue( $result['cached'] );
		$this->assertSame( 'http://example.test/uploads/interactive-fonts/noto-sans/regular.woff2', $result['fonts']['regular']['url'] );

		$manifest = json_decode( (string) file_get_contents( $font_dir . '/font.json' ), true );
		$this->assertSame( 'Noto Sans', $manifest['family'] );
		$this->assertSame( array( 'regular', '700' ), $manifest['variants'] );
		$this->assertArrayHasKey( 'regular', $manifest['fonts'] );
	}

	public function test_cache_accepts_google_api_ttf_file_and_records_truetype_format(): void {
		$requests = array();
		$this->stub_http(
			static function ( string $url ) use ( &$requests ): array {
				$requests[] = $url;
				return array(
					'response' => array( 'code' => 200 ),
					'body'     => 'ttf-binary',
				);
			}
		);

		$result = ( new GoogleFontCacheService() )->cache(
			'Italianno',
			array( 'regular' => 'https://fonts.gstatic.com/s/italianno/v18/italianno-regular.ttf' ),
			'regular',
			array( 'regular' )
		);

		$font_dir = $this->upload_base . '/interactive-fonts/italianno';
		$this->assertSame(
			array(
				'https://fonts.googleapis.com/css2?family=Italianno&display=swap',
				'https://fonts.gstatic.com/s/italianno/v18/italianno-regular.ttf',
			),
			$requests
		);
		$this->assertSame( 'ttf-binary', file_get_contents( $font_dir . '/regular.ttf' ) );
		$this->assertFileDoesNotExist( $font_dir . '/regular.woff2' );
		$this->assertSame( 'http://example.test/uploads/interactive-fonts/italianno/regular.ttf', $result['fonts']['regular']['url'] );
		$this->assertSame( 'truetype', $result['fonts']['regular']['format'] );

		$manifest = json_decode( (string) file_get_contents( $font_dir . '/font.json' ), true );
		$this->assertSame( 'truetype', $manifest['fonts']['regular']['format'] );
	}

	public function test_cache_falls_back_to_direct_variant_when_css_variant_is_missing(): void {
		$requests = array();
		$this->stub_http(
			static function ( string $url ) use ( &$requests ): array {
				$requests[] = $url;
				return array(
					'response' => array( 'code' => 200 ),
					'body'     => false !== strpos( $url, 'fonts.googleapis.com/css2' ) ? 'missing-css' : 'bold-binary',
				);
			}
		);

		$result = ( new GoogleFontCacheService() )->cache(
			'Noto Sans',
			array( '700' => 'https://fonts.gstatic.com/s/notosans/v1/700.woff2' ),
			'700',
			array( 'regular', '700' )
		);

		$font_dir = $this->upload_base . '/interactive-fonts/noto-sans';
		$this->assertSame(
			array(
				'https://fonts.googleapis.com/css2?family=Noto+Sans%3Awght%40700&display=swap',
				'https://fonts.gstatic.com/s/notosans/v1/700.woff2',
			),
			$requests
		);
		$this->assertSame( 'bold-binary', file_get_contents( $font_dir . '/700.woff2' ) );
		$this->assertArrayNotHasKey( 'cssUrl', $result );
		$this->assertFileDoesNotExist( $font_dir . '/font.css' );
	}

	public function test_cache_rejects_invalid_font_family(): void {
		$this->expectException( RuntimeException::class );
		$this->expectExceptionMessage( 'Invalid font family.' );

		( new GoogleFontCacheService() )->cache( 'Bad/Font' );
	}

	public function test_cache_ignores_non_gstatic_file_url_and_uses_google_css_source(): void {
		$requests = array();
		$this->stub_http(
			static function ( string $url ) use ( &$requests ): array {
				$requests[] = $url;
				if ( false !== strpos( $url, 'fonts.googleapis.com/css2' ) ) {
					return array(
						'response' => array( 'code' => 200 ),
						'body'     => '@font-face{font-family:"Noto Sans";font-style:normal;font-weight:400;src:url(https://fonts.gstatic.com/s/notosans/v1/from-css.woff2) format("woff2");}',
					);
				}

				return array(
					'response' => array( 'code' => 200 ),
					'body'     => 'css-font-binary',
				);
			}
		);

		( new GoogleFontCacheService() )->cache(
			'Noto Sans',
			array( 'regular' => 'https://example.test/not-allowed.woff2' )
		);

		$this->assertStringContainsString( 'fonts.googleapis.com/css2', $requests[0] );
		$this->assertSame( 'https://fonts.gstatic.com/s/notosans/v1/from-css.woff2', $requests[1] );
		$this->assertStringNotContainsString( 'example.test/not-allowed', implode( "\n", $requests ) );
		$this->assertSame( 'css-font-binary', file_get_contents( $this->upload_base . '/interactive-fonts/noto-sans/regular-' . substr( md5( 'https://fonts.gstatic.com/s/notosans/v1/from-css.woff2' ), 0, 12 ) . '.woff2' ) );
		$this->assertStringContainsString(
			'regular-',
			(string) file_get_contents( $this->upload_base . '/interactive-fonts/noto-sans/font.css' )
		);
	}

	public function test_cache_css_fallback_downloads_each_subset_in_google_css_order(): void {
		$requests = array();
		$this->stub_http(
			static function ( string $url ) use ( &$requests ): array {
				$requests[] = $url;
				if ( false !== strpos( $url, 'fonts.googleapis.com/css2' ) ) {
					return array(
						'response' => array( 'code' => 200 ),
						'body'     => implode(
							"\n",
							array(
								'/* vietnamese */',
								'@font-face{font-family:"Italianno";font-style:normal;font-weight:400;src:url(https://fonts.gstatic.com/s/italianno/v18/vietnamese.woff2) format("woff2");}',
								'/* latin-ext */',
								'@font-face{font-family:"Italianno";font-style:normal;font-weight:400;src:url(https://fonts.gstatic.com/s/italianno/v18/latin-ext.woff2) format("woff2");}',
								'/* latin */',
								'@font-face{font-family:"Italianno";font-style:normal;font-weight:400;src:url(https://fonts.gstatic.com/s/italianno/v18/latin.woff2) format("woff2");}',
							)
						),
					);
				}

				return array(
					'response' => array( 'code' => 200 ),
					'body'     => 'latin-font-binary',
				);
			}
		);

		( new GoogleFontCacheService() )->cache( 'Italianno' );

		$this->assertSame(
			array(
				'https://fonts.googleapis.com/css2?family=Italianno&display=swap',
				'https://fonts.gstatic.com/s/italianno/v18/vietnamese.woff2',
				'https://fonts.gstatic.com/s/italianno/v18/latin-ext.woff2',
				'https://fonts.gstatic.com/s/italianno/v18/latin.woff2',
			),
			$requests
		);
		$this->assertSame(
			3,
			substr_count(
				(string) file_get_contents( $this->upload_base . '/interactive-fonts/italianno/font.css' ),
				'regular-'
			)
		);
	}

	public function test_cache_css_fallback_preserves_all_subset_faces_in_local_css(): void {
		$requests = array();
		$this->stub_http(
			static function ( string $url ) use ( &$requests ): array {
				$requests[] = $url;
				if ( false !== strpos( $url, 'fonts.googleapis.com/css2' ) ) {
					return array(
						'response' => array( 'code' => 200 ),
						'body'     => implode(
							"\n",
							array(
								'/* vietnamese */',
								'@font-face{font-family:"Italianno";font-style:normal;font-weight:400;font-display:swap;src:url(https://fonts.gstatic.com/s/italianno/v18/vietnamese.woff2) format("woff2");unicode-range:U+0102-0103;}',
								'/* latin */',
								'@font-face{font-family:"Italianno";font-style:normal;font-weight:400;font-display:swap;src:url(https://fonts.gstatic.com/s/italianno/v18/latin.woff2) format("woff2");unicode-range:U+0000-00FF;}',
							)
						),
					);
				}

				return array(
					'response' => array( 'code' => 200 ),
					'body'     => basename( parse_url( $url, PHP_URL_PATH ) ?: '' ) . '-binary',
				);
			}
		);

		$result = ( new GoogleFontCacheService() )->cache( 'Italianno' );

		$font_dir = $this->upload_base . '/interactive-fonts/italianno';
		$css      = (string) file_get_contents( $font_dir . '/font.css' );
		$this->assertSame(
			array(
				'https://fonts.googleapis.com/css2?family=Italianno&display=swap',
				'https://fonts.gstatic.com/s/italianno/v18/vietnamese.woff2',
				'https://fonts.gstatic.com/s/italianno/v18/latin.woff2',
			),
			$requests
		);
		$this->assertSame( 'http://example.test/uploads/interactive-fonts/italianno/font.css', $result['cssUrl'] );
		$this->assertSame( 2, substr_count( $css, 'regular-' ) );
		$this->assertStringNotContainsString( 'http://example.test/uploads', $css );
		$this->assertStringNotContainsString( 'https://fonts.gstatic.com', $css );
		$this->assertStringContainsString( 'unicode-range:U+0102-0103', $css );
		$this->assertStringContainsString( 'unicode-range:U+0000-00FF', $css );
	}

	public function test_cached_fonts_lists_manifest_and_font_files(): void {
		$font_dir = $this->upload_base . '/interactive-fonts/inter';
		mkdir( $font_dir, 0777, true );
		file_put_contents( $font_dir . '/regular.woff2', 'regular-font' );
		file_put_contents( $font_dir . '/regular-abc123def456.woff2', 'subset-font' );
		file_put_contents( $font_dir . '/font.css', '@font-face{src:url(regular-abc123def456.woff2) format("woff2");}' );
		file_put_contents(
			$font_dir . '/font.json',
			json_encode(
				array(
					'family'   => 'Inter',
					'slug'     => 'inter',
					'variants' => array( 'regular' ),
					'fonts'    => array(
						'regular' => array(
							'url'     => 'http://example.test/uploads/interactive-fonts/inter/regular.woff2',
							'weight'  => 400,
							'style'   => 'normal',
							'variant' => 'regular',
							'label'   => 'Regular',
							'format'  => 'woff2',
						),
					),
				)
			)
		);

		$fonts = ( new GoogleFontCacheService() )->cached_fonts();

		$this->assertCount( 1, $fonts );
		$this->assertSame( 'Inter', $fonts[0]['family'] );
		$this->assertSame( 'inter', $fonts[0]['slug'] );
		$this->assertSame( 'http://example.test/uploads/interactive-fonts/inter/regular.woff2', $fonts[0]['fonts']['regular']['url'] );
		$this->assertSame( array( 'regular' ), array_keys( $fonts[0]['fonts'] ) );
		$this->assertSame( array( 'regular' ), $fonts[0]['variants'] );
		$this->assertSame( 'http://example.test/uploads/interactive-fonts/inter/font.css', $fonts[0]['cssUrl'] );
	}

	private function stub_wordpress_file_helpers(): void {
		Functions\when( 'wp_upload_dir' )->alias(
			fn() => array(
				'basedir' => $this->upload_base,
				'baseurl' => 'http://example.test/uploads',
				'error'   => false,
			)
		);
		Functions\when( 'trailingslashit' )->alias(
			static fn( $path ) => rtrim( (string) $path, '/\\' ) . '/'
		);
		Functions\when( 'wp_mkdir_p' )->alias(
			static fn( $path ) => is_dir( (string) $path ) || mkdir( (string) $path, 0777, true )
		);
		Functions\when( 'sanitize_title' )->alias(
			static function ( $value ) {
				$value = strtolower( trim( (string) $value ) );
				$value = preg_replace( '/[^a-z0-9]+/', '-', $value );
				return trim( (string) $value, '-' );
			}
		);
		Functions\when( 'sanitize_file_name' )->alias(
			static fn( $value ) => preg_replace( '/[^a-z0-9._-]+/', '-', strtolower( (string) $value ) )
		);
		Functions\when( 'esc_url_raw' )->returnArg();
		Functions\when( 'add_query_arg' )->alias(
			static function ( array $args, string $url ): string {
				return $url . '?' . http_build_query( $args );
			}
		);
		Functions\when( 'is_wp_error' )->justReturn( false );
		Functions\when( 'wp_json_encode' )->alias(
			static fn( $data, $flags = 0 ) => json_encode( $data, (int) $flags )
		);
	}

	private function stub_http( callable $handler ): void {
		Functions\when( 'wp_remote_get' )->alias(
			static fn( $url, $args = array() ) => $handler( (string) $url, (array) $args )
		);
		Functions\when( 'wp_remote_retrieve_response_code' )->alias(
			static fn( $response ) => (int) ( $response['response']['code'] ?? 0 )
		);
		Functions\when( 'wp_remote_retrieve_body' )->alias(
			static fn( $response ) => (string) ( $response['body'] ?? '' )
		);
	}

	private function remove_dir( string $path ): void {
		if ( ! is_dir( $path ) ) {
			return;
		}

		$items = scandir( $path );
		foreach ( false === $items ? array() : $items as $item ) {
			if ( '.' === $item || '..' === $item ) {
				continue;
			}

			$child = $path . '/' . $item;
			if ( is_dir( $child ) ) {
				$this->remove_dir( $child );
				continue;
			}

			unlink( $child );
		}

		rmdir( $path );
	}
}
