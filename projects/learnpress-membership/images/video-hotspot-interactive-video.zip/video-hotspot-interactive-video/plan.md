# Interactive Video Hotspot – LearnPress Interactive Add-on

## Ideas

- Thêm loại nội dung tương tác mới **"Interactive Video"** vào plugin LearnPress Interactive (hiện có Flash Card và Slide).
- Giáo viên gắn các widget (nhãn, nút, ảnh, quiz…) trực tiếp lên video theo thời gian & vị trí.
- Học viên xem video → widget hiện/ẩn theo timeline → tương tác ngay trên video mà không rời khỏi bài học.
- Quiz trên video: video tạm dừng, học viên trả lời, video tiếp tục. Không ghi điểm vào LearnPress progress — chỉ là tương tác cục bộ.

---

## Requirements

### Functional

| # | Yêu cầu | Ưu tiên |
|---|---------|---------|
| R1 | Admin tạo mới Interactive Video từ trang LearnPress > Interactive > New | Must |
| R2 | Admin dán URL video (trực tiếp, YouTube, Vimeo) — video hiển thị ngay trong editor | Must |
| R3 | Admin thêm widget overlay lên video: Text Label, Click Button, Image Card, Pulsing Target, Pop Quiz | Must |
| R4 | Mỗi widget có thời gian hiện/ẩn (start time – end time) trên timeline | Must |
| R5 | Mỗi widget có vị trí (x%, y%) và kích thước trên canvas video | Must |
| R6 | Admin kéo-thả widget trực tiếp trên canvas để đặt vị trí | Must |
| R7 | Admin chỉnh sửa nội dung widget qua sidebar panel (properties) | Must |
| R8 | Timeline bar phía dưới video hiển thị các widget theo thời gian, phân biệt bằng màu sắc | Must |
| R9 | Auto-save overlay sau mỗi thay đổi (debounce 1.5s) | Must |
| R10 | Frontend: video phát → widget hiện/ẩn theo thời gian → học viên tương tác | Must |
| R11 | Pop Quiz: video tạm dừng khi quiz xuất hiện, resume sau khi trả lời | Must |
| R12 | Upload ảnh cho Image Card qua WordPress Media Library | Must |
| R13 | Shortcode `[learnpress_single_interactive id=X]` render video + overlay trên frontend | Must |
| R14 | Nhúng vào bài học LearnPress qua WP Editor integration (nút Insert Interactive) | Should |
| R15 | Responsive: overlay giữ tỷ lệ vị trí khi video resize | Should |

### Non-functional

| # | Yêu cầu | Ưu tiên |
|---|---------|---------|
| NR1 | Editor load < 3s trên video YouTube trung bình | Should |
| NR2 | Frontend JS bundle tách riêng, chỉ load khi có shortcode | Must |
| NR3 | Tương thích PHP 7.4+, WordPress 6.3+, LearnPress 4.3.2.7+ | Must |

---

## Business Flows

### Flow 1: Tạo Interactive Video mới

```
Admin → LearnPress > Interactive → "New"
  → Nhập tiêu đề
  → Chọn type "Interactive Video"
  → Click "Save & Continue"
  → Redirect sang trang Editor
```

### Flow 2: Biên soạn Video Hotspot (Editor)

```
Admin vào trang Editor
  → Dán URL video (YouTube/Vimeo/direct)
  → Video load trong canvas
  → Click "Add Overlay" → chọn loại widget
  → Widget xuất hiện trên canvas (vị trí mặc định giữa màn hình)
  → Kéo-thả widget đến vị trí mong muốn
  → Sidebar bên phải hiện properties của widget đang chọn
  → Chỉnh nội dung, thời gian start/end, kích thước, kiểu hiển thị
  → Timeline bar cập nhật real-time
  → Auto-save sau 1.5s không thao tác
  → Click "Update" để force save
  → Copy shortcode từ header → dán vào bài học
```

### Flow 3: Học viên xem video trên frontend

```
Học viên mở bài học có shortcode Interactive Video
  → Video player hiển thị
  → Video phát → widget hiện khi đến start time
  → Widget ẩn khi qua end time
  → Học viên click vào widget (nếu là button → mở link, quiz → hiện câu hỏi)
  → Pop Quiz: video tạm dừng → hiện câu hỏi + đáp án
    → Chọn đáp án → hiện đúng/sai → video resume tự động
  → Video tiếp tục cho đến hết
```

### Flow 4: Sửa / Xóa widget

```
Admin vào Editor → click widget trên canvas hoặc trên timeline
  → Widget được highlight, sidebar hiện properties
  → Sửa nội dung → auto-save
  → Hoặc click "Delete" trong sidebar → confirm → widget bị xóa
```

---

## Screens

### S1: Create Page (đã có sẵn, thêm option type mới)

- Giữ nguyên UI hiện tại của `AdminInteractiveEditPage::render_create()`
- Thêm 1 radio segment: **Interactive Video** với icon + hint "Teach · Engage"

### S2: Editor Page — Video Canvas

- **Topbar**: Breadcrumb (Library / Edit), shortcode chip, nút Copy, Status pill, nút Update, menu kebab
- **Video area**: Canvas chứa video player, các overlay widget hiện trên canvas
- **Toolbar bên trái**: Các nút thêm widget (Text Label, Click Button, Image Card, Pulsing Target, Pop Quiz)
- **Sidebar bên phải**: Properties panel của widget đang chọn
  - Common: vị trí (x, y), kích thước, thời gian (start, end), visible toggle
  - Riêng theo loại:
    - Text Label: text, font size, color, background
    - Click Button: label, URL, target, style
    - Image Card: image (WP Media upload), caption, link
    - Pulsing Target: color, size, tooltip text
    - Pop Quiz: câu hỏi, danh sách đáp án, đáp án đúng, inline edit
- **Timeline bar phía dưới**: Thanh ngang theo thời lượng video, mỗi widget = 1 bar nhỏ có màu riêng, kéo để chỉnh start/end

### S3: Frontend Viewer

- Video player (native `<video>` hoặc YouTube/Vimeo iframe)
- Overlay container phủ lên video, chứa các widget hiện theo thời gian
- Pop Quiz modal overlay khi quiz active

---

## Features

### F1: Widget — Text Label
- Hiển thị đoạn text tĩnh trên video
- Configurable: nội dung, font size, color, background color, opacity
- Có thể dùng làm tiêu đề, chú thích, subtitle tùy chỉnh

### F2: Widget — Click Button
- Nút bấm trên video
- Configurable: label, URL đích, mở tab mới hay không, style (filled/outlined), color
- Dùng cho CTA, link tài liệu bổ sung

### F3: Widget — Image Card
- Hiển thị ảnh overlay trên video
- Ảnh upload qua WordPress Media Library (trả về attachment ID)
- Configurable: image, caption, link, border radius, shadow

### F4: Widget — Pulsing Target
- Điểm nhấp nháy (pulse animation) thu hút chú ý
- Khi hover hoặc click: hiện tooltip
- Configurable: color, size, tooltip text, pulse speed

### F5: Widget — Pop Quiz
- Video tạm dừng → hiện câu hỏi + các đáp án
- Học viên chọn → hiện feedback đúng/sai → video resume
- Configurable: câu hỏi, danh sách đáp án (text), đánh dấu đáp án đúng
- Không ghi điểm, không lưu kết quả vào DB
- Chỉnh sửa quiz inline trong sidebar (không cần popup riêng)

### F6: Timeline Bar
- Thanh ngang theo thời lượng video
- Mỗi widget = 1 segment bar, màu sắc theo loại widget
- Kéo 2 đầu segment để chỉnh start/end time
- Click segment → chọn widget tương ứng trên canvas + mở sidebar

### F7: Auto-save
- Debounce 1.5s sau mỗi thay đổi property
- Gọi AJAX save overlay data
- Hiện indicator "Saving…" / "Saved ✓" trên topbar

### F8: Video Source
- Phase 1: URL trực tiếp (.mp4/.webm), YouTube, Vimeo
- Detect loại source tự động từ URL nhập vào
- YouTube/Vimeo: dùng API player để đồng bộ `timeupdate`

---

## Rules

### Data Rules

| Rule | Mô tả |
|------|-------|
| DR1 | Mỗi Interactive Video = 1 row trong `wp_learnpress_interactive` với `type = 'video_hotspot'` |
| DR2 | Mỗi overlay widget = 1 row trong `wp_learnpress_interactive_items` |
| DR3 | Cấu hình widget lưu trong cột `extra_data` (JSON), bao gồm: type, position, size, timing, custom properties |
| DR4 | Video URL và settings chung lưu trong `extra_data` của parent row |
| DR5 | Vị trí widget lưu dạng phần trăm (%) để responsive |
| DR6 | Thời gian widget lưu dạng giây (seconds, float) |
| DR7 | Image trong Image Card lưu `attachment_id` (int), resolve URL khi render |

### Business Rules

| Rule | Mô tả |
|------|-------|
| BR1 | Chỉ user có capability `edit_lp_courses` mới tạo/sửa Interactive Video |
| BR2 | Widget không được có start time > end time |
| BR3 | Widget không được có end time > thời lượng video |
| BR4 | Pop Quiz phải có ít nhất 1 đáp án đúng |
| BR5 | Pop Quiz phải có ít nhất 2 đáp án |
| BR6 | Khi xóa Interactive Video (trash), các overlay items giữ nguyên (soft delete) |
| BR7 | Khi xóa vĩnh viễn (force delete), cascade xóa tất cả overlay items |
| BR8 | Frontend chỉ render Interactive Video có status = `publish` |
| BR9 | Auto-save chỉ lưu data, không thay đổi status (publish/draft) |

### UI Rules

| Rule | Mô tả |
|------|-------|
| UR1 | Chỉ 1 widget được chọn (selected) tại 1 thời điểm trên canvas |
| UR2 | Widget đang chọn có viền highlight và hiện resize handles |
| UR3 | Sidebar chỉ hiện properties của widget đang chọn; ẩn nếu không chọn gì |
| UR4 | Timeline bar luôn hiển thị, scroll horizontal nếu video dài |
| UR5 | Mỗi loại widget có màu riêng trên timeline (Text=blue, Button=green, Image=purple, Pulse=orange, Quiz=red) |
| UR6 | Video phải load thành công trước khi cho phép thêm widget |

---

## Edge Cases

| # | Tình huống | Xử lý |
|---|-----------|-------|
| EC1 | URL video không hợp lệ hoặc không load được | Hiện thông báo lỗi trong canvas, không cho thêm widget |
| EC2 | Video YouTube bị restricted (private/region lock) | Hiện thông báo "Video không khả dụng", cho phép đổi URL |
| EC3 | Widget có start time = end time | Không cho phép, hiện warning, auto-adjust end = start + 1s |
| EC4 | Nhiều widget chồng lên nhau trên canvas | Cho phép, widget sau đè lên widget trước (z-index theo thứ tự tạo) |
| EC5 | Nhiều Pop Quiz cùng thời điểm | Chỉ hiện quiz đầu tiên, queue quiz tiếp theo sau khi trả lời xong |
| EC6 | Học viên seek video qua vùng có quiz | Cho skip — quiz chỉ tạm dừng video khi play tự nhiên đến thời điểm đó, seek qua thì bỏ qua |
| EC7 | Video ngắn (< 5s) | Cho phép nhưng hiện warning "Video quá ngắn" |
| EC8 | Browser không hỗ trợ autoplay | Không ảnh hưởng — video cần user click play |
| EC9 | Admin xóa ảnh trong Media Library mà Image Card đang dùng | Frontend hiện placeholder "Image not found" |
| EC10 | Mất kết nối khi auto-save | Hiện thông báo "Save failed, retrying…", retry 3 lần, sau đó hiện nút manual save |
| EC11 | Admin mở editor trên mobile | Editor không hỗ trợ mobile — hiện thông báo "Vui lòng dùng desktop" |
| EC12 | Widget bị kéo ra ngoài vùng canvas video | Clamp vị trí widget về trong biên canvas (0–100%) |
