=== LearnPress - Gradebook ===
Contributors: thimpress, phonglq, tunnhn, tutv95
Donate link:
Tags: lms, elearning, e-learning, learning management system, education, course, courses, quiz, quizzes, questions, training, guru, sell courses
Requires at least: 6.3
Tested up to: 7.0
Stable tag: trunk
License: Split License
License URI: https://help.market.envato.com/hc/en-us/articles/202501064-What-is-Split-Licensing-and-the-GPL-

== Description ==

Gradebook add-on for LearnPress.

== Installation ==

**From your WordPress dashboard**
1. Visit 'Plugin > Add new'.
2. Search for 'LearnPress - Gradebook'.
3. Activate LearnPress - Gradebook Pro from your Plugins page.

== Frequently Asked Questions ==

= Can I create an add-on for LearnPress like LearnPress - Gradebook by myself? =
Yes, you can. Please find the documentation for writing an add-on for LearnPress in our <a href="https://github.com/LearnPress/LearnPress/wiki" target>LearnPress github repo.</a>

== Screenshots ==

== Changelog ==

= 4.1.0 (2026-05-25) =
~ Fixed: minor bugs.

= 4.0.9 (2026-04-11) =
~ Fixed: minor bugs.

= 4.0.8 (2025-10-28) =
~ Added: new UI/UX for Recent Activity screen, Student Overview, Student details.
~ Added: view chart, export CSV for Student detail attended courses.

= 4.0.7 (2024-05-13) =
~ Fixed: title GradeBook page.

= 4.0.6 (2024-04-02) =
~ Fixed: error library chart.js

= 4.0.5 (2024-04-02) =
~ Fixed: show wrong value of "Correct" and "Retake detail" column.
~ Added: hook apply_filters( 'learnpress/gradebook/rest-api/permission' )
~ Set default title for page, if not error strip_tags(): Passing null on WP.

= 4.0.4 =
~ Fixed: errors blank page Student.
~ Compatible with LP v4.1.6.9 fixed show wrong Average.

= 4.0.3 =
~ Update Average Error in Gradebook.
~ Update pot file compatible with Loco translate plugin.
~ Change type chart list question on the Quiz page.
~ Fixed: Export CSV on the list student.
~ Fixed: error End time with Assignment.

= 4.0.2 =
~ Apply React js
~ Write new Interface

= 4.0.1 =
~ Fix Export CSV on Profile page

= 4.0.0 =
~ Fixed compatible LP4

= 3.0.11 =
~ Fixed check get items of course return false

= 3.0.10 =
~ Fixed pagination not show in user profile courses.

= 3.0.9 =
~ Added filter hook for getting Assignment items status when exporting.

= 3.0.8 =
~ Fixed: jquery ui style blocked

= 3.0.7 =
~ Fixed: show incorrect quiz result in admin.

= 3.0.6 =
~ Fixed: show not enrolled student in student list in admin.

= 3.0.5 =
~ Fixed: export file is without enrolled date.
~ Fixed: profile of instructor without Gradebook tab
~ Add filter gradebook by username, email, enroll date

= 3.0.4 =
~ Update admin gradebook view
~ Update profile gradebook template

= 3.0.3 =
~ Fixed gradebook list not have paging navigation

= 3.0.2 =
~ Fixed status of quiz and lesson not show in Gradebook details of Course
~ Fixed cannot export gradebook in admin


== Upgrade Notice ==

== Other note ==
<a href="http://docs.thimpress.com/learnpress" target="_blank">Documentation</a> is available in ThimPress site.
<a href="https://github.com/LearnPress/LearnPress/" target="_blank">LearnPress github repo.</a>
